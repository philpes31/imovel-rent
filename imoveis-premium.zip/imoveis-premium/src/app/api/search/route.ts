import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const q = searchParams.get('q')?.trim()
  const limit = Math.min(Number(searchParams.get('limit') || 10), 20)

  if (!q || q.length < 2) {
    return NextResponse.json([])
  }

  const supabase = await createClient()

  const { data, error } = await supabase
    .from('properties')
    .select(`
      id, title, slug, price, purpose, type, bedrooms, private_area,
      city:cities(name),
      images:property_images(url, is_cover)
    `)
    .eq('status', 'ativo')
    .textSearch('search_vector', q, { type: 'websearch', config: 'portuguese' })
    .limit(limit)

  if (error) {
    // Fallback to ilike if full-text not available
    const { data: fallback } = await supabase
      .from('properties')
      .select(`id, title, slug, price, purpose, type, bedrooms, private_area, city:cities(name), images:property_images(url, is_cover)`)
      .eq('status', 'ativo')
      .ilike('title', `%${q}%`)
      .limit(limit)
    return NextResponse.json(fallback || [])
  }

  return NextResponse.json(data || [], {
    headers: { 'Cache-Control': 'public, max-age=60' },
  })
}
