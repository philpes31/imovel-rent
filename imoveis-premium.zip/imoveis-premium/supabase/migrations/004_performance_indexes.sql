-- ============================================================
-- Migration 004: Performance & full-text search improvements
-- ============================================================

-- Compound indexes for common filter combinations
CREATE INDEX IF NOT EXISTS idx_properties_purpose_status
  ON properties(purpose, status);

CREATE INDEX IF NOT EXISTS idx_properties_city_purpose_status
  ON properties(city_id, purpose, status);

CREATE INDEX IF NOT EXISTS idx_properties_featured_published
  ON properties(featured, published_at DESC)
  WHERE status = 'ativo';

CREATE INDEX IF NOT EXISTS idx_properties_launch_published
  ON properties(launch, published_at DESC)
  WHERE status = 'ativo';

CREATE INDEX IF NOT EXISTS idx_properties_price_purpose
  ON properties(price, purpose)
  WHERE status = 'ativo';

-- Views count index for "most viewed" sort
CREATE INDEX IF NOT EXISTS idx_properties_views
  ON properties(views_count DESC)
  WHERE status = 'ativo';

-- Leads index by creation date
CREATE INDEX IF NOT EXISTS idx_leads_created_at
  ON leads(created_at DESC);

-- Blog posts index
CREATE INDEX IF NOT EXISTS idx_blog_posts_published
  ON blog_posts(published, published_at DESC)
  WHERE published = true;

-- Neighborhoods slug+city composite
CREATE INDEX IF NOT EXISTS idx_neighborhoods_city_slug
  ON neighborhoods(city_id, slug);

-- Function to get properties count by city (used in city pages)
CREATE OR REPLACE FUNCTION get_city_property_counts()
RETURNS TABLE(city_id uuid, count bigint) AS $$
  SELECT city_id, COUNT(*) as count
  FROM properties
  WHERE status = 'ativo'
  GROUP BY city_id;
$$ LANGUAGE SQL STABLE;

-- Refresh city property counts
CREATE OR REPLACE FUNCTION refresh_city_counts()
RETURNS void AS $$
BEGIN
  UPDATE cities c
  SET property_count = (
    SELECT COUNT(*) FROM properties p
    WHERE p.city_id = c.id AND p.status = 'ativo'
  );
END;
$$ LANGUAGE plpgsql;

-- Materialized view for homepage stats (refresh periodically)
CREATE MATERIALIZED VIEW IF NOT EXISTS homepage_stats AS
  SELECT
    (SELECT COUNT(*) FROM properties WHERE status = 'ativo') AS active_properties,
    (SELECT COUNT(*) FROM properties WHERE status IN ('vendido', 'alugado')) AS sold_properties,
    (SELECT COUNT(*) FROM leads) AS total_leads,
    (SELECT COUNT(*) FROM agents WHERE active = true) AS active_agents,
    (SELECT COALESCE(SUM(views_count), 0) FROM properties) AS total_views;

CREATE UNIQUE INDEX IF NOT EXISTS homepage_stats_idx ON homepage_stats((true));

-- Refresh command: REFRESH MATERIALIZED VIEW CONCURRENTLY homepage_stats;
