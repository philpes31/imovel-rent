import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import HeroSearch from '@/components/home/HeroSearch'
import PropertyCard from '@/components/property/PropertyCard'
import { getFeaturedProperties, getCities } from '@/lib/queries'
import { CITIES_FEATURED } from '@/lib/utils'

export const metadata: Metadata = {
  title: 'Imóveis Premium SC | Venda e Aluguel em Santa Catarina',
  description: 'Encontre apartamentos, casas e coberturas de alto padrão em Balneário Camboriú, Itapema, Blumenau, Itajaí e Florianópolis.',
}

export const revalidate = 300

export default async function HomePage() {
  const [featuredProperties, cities] = await Promise.all([
    getFeaturedProperties(6),
    getCities(),
  ])

  return (
    <>
      <Header />

      <main>
        {/* Hero */}
        <HeroSearch cities={cities} />

        {/* Featured Properties */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="section-heading">Imóveis em Destaque</h2>
                <div className="gold-line" />
                <p className="section-subheading -mt-2">Seleção exclusiva dos melhores imóveis</p>
              </div>
              <Link href="/imoveis" className="hidden sm:flex items-center gap-2 text-sm font-medium text-[#0A1628] hover:text-[#C9A84C] transition-colors">
                Ver todos
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </div>

            {featuredProperties.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredProperties.map(property => (
                  <PropertyCard key={property.id} property={property} featured />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-neutral-400">
                Nenhum imóvel em destaque no momento.
              </div>
            )}

            <div className="mt-10 text-center sm:hidden">
              <Link href="/imoveis" className="btn-outline">
                Ver todos os imóveis
              </Link>
            </div>
          </div>
        </section>

        {/* Cities */}
        <section className="py-20 bg-neutral-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="section-heading">Explore por Cidade</h2>
              <div className="gold-line mx-auto" />
              <p className="section-subheading">
                Imóveis nos principais destinos de Santa Catarina
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {CITIES_FEATURED.map(city => (
                <Link
                  key={city.slug}
                  href={`/cidade/${city.slug}`}
                  className="group relative overflow-hidden aspect-[3/4] block"
                >
                  <div className="absolute inset-0 bg-[#0A1628]">
                    <div
                      className="absolute inset-0 opacity-60 group-hover:opacity-40 transition-all duration-500 scale-100 group-hover:scale-105"
                      style={{
                        backgroundImage: `url(/cities/${city.slug}.jpg)`,
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        transition: 'transform 0.5s ease, opacity 0.5s ease',
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A1628] via-transparent to-transparent" />
                  </div>
                  <div className="relative h-full flex flex-col justify-end p-4">
                    <h3 className="font-serif text-white font-bold text-base leading-tight">
                      {city.name}
                    </h3>
                    <p className="text-white/60 text-xs mt-1">{city.subtitle}</p>
                    <div className="mt-2 w-6 h-px bg-[#C9A84C] group-hover:w-full transition-all duration-500" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Institutional */}
        <section className="py-20 bg-[#0A1628]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <p className="text-[#C9A84C] text-sm font-medium tracking-widest uppercase mb-4">
                  Sobre nós
                </p>
                <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white leading-tight mb-4">
                  Especialistas em imóveis premium em Santa Catarina
                </h2>
                <div className="w-16 h-0.5 bg-[#C9A84C] mb-6" />
                <p className="text-neutral-400 leading-relaxed mb-6">
                  Há mais de 15 anos conectamos pessoas e famílias aos melhores imóveis de Santa Catarina.
                  Nossa missão é oferecer uma experiência de compra e aluguel transparente, segura e personalizada.
                </p>
                <p className="text-neutral-400 leading-relaxed mb-8">
                  Contamos com uma equipe de corretores experientes e apaixonados pelo mercado imobiliário,
                  prontos para ajudá-lo a encontrar o imóvel ideal.
                </p>

                <div className="grid grid-cols-2 gap-6 mb-8">
                  {[
                    ['Confiança', 'Ética e transparência em cada negociação'],
                    ['Expertise', 'Profundo conhecimento do mercado catarinense'],
                    ['Agilidade', 'Processos simplificados e eficientes'],
                    ['Suporte', 'Acompanhamento completo do início ao fim'],
                  ].map(([title, desc]) => (
                    <div key={title} className="flex gap-3">
                      <div className="w-1 h-full bg-[#C9A84C] flex-shrink-0 mt-1" />
                      <div>
                        <h4 className="text-white font-medium text-sm">{title}</h4>
                        <p className="text-neutral-500 text-xs mt-1 leading-relaxed">{desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <Link href="/sobre" className="btn-accent inline-block">
                  Conheça nossa história
                </Link>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4">
                {[
                  ['1.200+', 'Imóveis cadastrados', ''],
                  ['3.500+', 'Clientes atendidos', ''],
                  ['15 anos', 'de experiência no mercado', ''],
                  ['98%', 'de satisfação dos clientes', ''],
                  ['5 cidades', 'de atuação em SC', ''],
                  ['50+', 'corretores especializados', ''],
                ].map(([num, label]) => (
                  <div
                    key={num}
                    className="border border-neutral-800 p-6 hover:border-[#C9A84C] transition-colors"
                  >
                    <div className="font-serif text-3xl font-bold text-[#C9A84C] mb-1">{num}</div>
                    <div className="text-neutral-500 text-xs leading-relaxed">{label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-[#C9A84C]">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#0A1628] mb-4">
              Quer vender seu imóvel?
            </h2>
            <p className="text-[#0A1628]/70 text-lg mb-8 max-w-xl mx-auto">
              Anuncie com a Premium SC e alcance milhares de compradores qualificados em Santa Catarina.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Link href="/anunciar" className="bg-[#0A1628] text-white px-8 py-4 font-medium hover:bg-[#1a2d4a] transition-colors">
                Anunciar meu imóvel
              </Link>
              <Link href="/contato" className="border-2 border-[#0A1628] text-[#0A1628] px-8 py-4 font-medium hover:bg-[#0A1628] hover:text-white transition-all">
                Falar com corretor
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppFloat />
    </>
  )
}
