import type { Metadata } from 'next'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import PropertyFilters from '@/components/property/PropertyFilters'
import { getProperties, getCities } from '@/lib/queries'
import { SearchFilters } from '@/types'

export const metadata: Metadata = {
  title: 'Imóveis à Venda em Santa Catarina | PremiumSC',
  description:
    'Compre apartamentos, casas e coberturas de alto padrão em Balneário Camboriú, Itapema, Blumenau e mais cidades de SC.',
}

interface PageProps {
  searchParams: Promise<Record<string, string>>
}

export default async function ComprarPage({ searchParams }: PageProps) {
  const params = await searchParams
  const filters: SearchFilters = {
    purpose: 'venda',
    type: params.type as any,
    city_id: params.city_id,
    neighborhood_id: params.neighborhood_id,
    min_price: params.min_price ? Number(params.min_price) : undefined,
    max_price: params.max_price ? Number(params.max_price) : undefined,
    bedrooms: params.bedrooms ? Number(params.bedrooms) : undefined,
    suites: params.suites ? Number(params.suites) : undefined,
    parking_spots: params.parking_spots ? Number(params.parking_spots) : undefined,
    min_area: params.min_area ? Number(params.min_area) : undefined,
    max_area: params.max_area ? Number(params.max_area) : undefined,
    furnished: params.furnished === 'true' ? true : undefined,
    pet_friendly: params.pet_friendly === 'true' ? true : undefined,
    gated_community: params.gated_community === 'true' ? true : undefined,
    page: params.page ? Number(params.page) : 1,
    per_page: 12,
    sort: params.sort as any,
  }

  const [{ data: properties, total, total_pages, page }, cities] = await Promise.all([
    getProperties(filters),
    getCities(),
  ])

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="bg-[#0A1628] py-10 px-4">
          <div className="max-w-7xl mx-auto">
            <p className="text-[#C9A84C] text-xs font-medium tracking-widest uppercase mb-2">Venda</p>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-white">
              Imóveis à Venda
            </h1>
            <div className="w-12 h-0.5 bg-[#C9A84C] mt-3" />
            <p className="text-neutral-400 text-sm mt-3">{total} imóveis disponíveis para compra</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            <aside className="w-full lg:w-72 flex-shrink-0">
              <PropertyFilters cities={cities} currentFilters={filters} />
            </aside>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-6">
                <p className="text-sm text-neutral-500">Página {page} de {total_pages || 1}</p>
                <select
                  className="border border-neutral-200 text-sm px-3 py-2 focus:outline-none focus:border-[#C9A84C] bg-white"
                  onChange={e => {
                    const url = new URL(window.location.href)
                    url.searchParams.set('sort', e.target.value)
                    window.location.href = url.toString()
                  }}
                  defaultValue={params.sort || 'newest'}
                >
                  <option value="newest">Mais recentes</option>
                  <option value="price_asc">Menor preço</option>
                  <option value="price_desc">Maior preço</option>
                  <option value="most_viewed">Mais vistos</option>
                </select>
              </div>

              {properties.length > 0 ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                    {properties.map(p => <PropertyCard key={p.id} property={p} />)}
                  </div>
                  {total_pages > 1 && (
                    <div className="flex items-center justify-center gap-2 mt-10">
                      {Array.from({ length: total_pages }, (_, i) => i + 1).map(p => (
                        <a
                          key={p}
                          href={`/comprar?page=${p}${params.type ? `&type=${params.type}` : ''}`}
                          className={`w-9 h-9 flex items-center justify-center text-sm transition-colors ${
                            p === page ? 'bg-[#0A1628] text-white' : 'border border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
                          }`}
                        >{p}</a>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-20 bg-white border border-neutral-200">
                  <p className="font-serif text-xl text-neutral-500">Nenhum imóvel encontrado</p>
                  <p className="text-sm text-neutral-400 mt-2">Ajuste os filtros para ampliar a busca</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
