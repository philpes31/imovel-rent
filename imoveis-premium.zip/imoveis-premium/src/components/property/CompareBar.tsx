'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useCompare } from '@/hooks/useCompare'
import { formatPrice } from '@/lib/utils'

export default function CompareBar() {
  const { items, remove, clear } = useCompare()
  if (items.length === 0) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#0A1628] border-t border-[#C9A84C]/30 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center gap-4">
          <div className="flex-shrink-0">
            <p className="text-white text-xs font-medium">Comparar</p>
            <p className="text-neutral-500 text-xs">{items.length}/3 imóveis</p>
          </div>

          <div className="flex-1 flex gap-3 overflow-x-auto">
            {items.map(item => (
              <div key={item.id} className="flex items-center gap-2 bg-white/10 px-3 py-2 flex-shrink-0">
                <div className="w-10 h-10 bg-neutral-700 overflow-hidden flex-shrink-0">
                  {item.coverImage ? (
                    <Image src={item.coverImage} alt={item.title} width={40} height={40} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-lg">🏠</div>
                  )}
                </div>
                <div className="min-w-0">
                  <p className="text-white text-xs font-medium truncate max-w-[120px]">{item.title}</p>
                  <p className="text-[#C9A84C] text-xs">{formatPrice(item.price, item.purpose)}</p>
                </div>
                <button
                  onClick={() => remove(item.id)}
                  className="text-neutral-500 hover:text-white transition-colors ml-1 flex-shrink-0"
                  aria-label="Remover"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}

            {/* Empty slots */}
            {Array.from({ length: 3 - items.length }).map((_, i) => (
              <div key={i} className="w-32 h-14 border border-dashed border-neutral-700 flex items-center justify-center flex-shrink-0">
                <span className="text-neutral-600 text-xs">+ Adicionar</span>
              </div>
            ))}
          </div>

          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={clear}
              className="text-neutral-500 hover:text-white text-xs transition-colors"
            >
              Limpar
            </button>
            {items.length >= 2 && (
              <Link
                href={`/site/comparar?ids=${items.map(i => i.id).join(',')}`}
                className="bg-[#C9A84C] hover:bg-[#b8963e] text-white text-xs font-medium px-4 py-2 transition-colors"
              >
                Comparar →
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
