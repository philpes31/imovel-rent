import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import LeadForm from '@/components/property/LeadForm'
import ImageGallery from '@/components/property/ImageGallery'
import FavoriteButton from '@/components/property/FavoriteButton'
import ShareButton from '@/components/ui/ShareButton'
import { RecentlyViewedTracker, RecentlyViewedStrip } from '@/components/property/RecentlyViewed'
import { getPropertyBySlug, getSimilarProperties } from '@/lib/queries'
import { formatPrice, formatArea, generatePropertyWhatsApp, generatePropertySchema, getPropertyCover } from '@/lib/utils'

interface PageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params
  const property = await getPropertyBySlug(slug)
  if (!property) return { title: 'Imóvel não encontrado' }
  return {
    title: property.seo_title || property.title,
    description: property.seo_description || property.description?.slice(0, 160),
    openGraph: {
      title: property.title,
      description: property.description?.slice(0, 160),
      images: property.images?.filter((i: any) => i.is_cover).map((i: any) => i.url),
    },
  }
}

export default async function PropertyPage({ params }: PageProps) {
  const { slug } = await params
  const property = await getPropertyBySlug(slug)
  if (!property) notFound()

  const similar = await getSimilarProperties(property)
  const whatsapp = generatePropertyWhatsApp(property, property.agent?.whatsapp)
  const schema = generatePropertySchema(property)
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || ''

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">
        <RecentlyViewedTracker item={{
          id: property.id, slug: property.slug, title: property.title,
          price: property.price, purpose: property.purpose,
          coverImage: getPropertyCover(property), city: property.city?.name,
          bedrooms: property.bedrooms, private_area: property.private_area,
        }} />

        <ImageGallery images={property.images || []} title={property.title} />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              {/* Breadcrumb */}
              <nav className="flex items-center gap-2 text-xs text-neutral-400 mb-5 flex-wrap">
                <Link href="/site" className="hover:text-[#0A1628]">Home</Link>
                <span>›</span>
                <Link href="/site/imoveis" className="hover:text-[#0A1628]">Imóveis</Link>
                {property.city && (<><span>›</span><Link href={`/site/cidade/${property.city.slug}`} className="hover:text-[#0A1628]">{property.city.name}</Link></>)}
                <span>›</span>
                <span className="text-neutral-600 line-clamp-1">{property.title}</span>
              </nav>

              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className="bg-[#0A1628] text-white text-xs px-3 py-1 capitalize">{property.type}</span>
                <span className="border border-neutral-300 text-neutral-600 text-xs px-3 py-1">Cód: {property.code}</span>
                {property.furnished && <span className="bg-blue-50 text-blue-700 text-xs px-3 py-1">Mobiliado</span>}
                {property.pet_friendly && <span className="bg-green-50 text-green-700 text-xs px-3 py-1">Pet Friendly</span>}
                {property.launch && <span className="bg-[#C9A84C] text-white text-xs px-3 py-1">Lançamento</span>}
              </div>

              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#0A1628] mb-2">{property.title}</h1>

              <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
                <p className="text-neutral-500 flex items-center gap-1 text-sm">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg>
                  {property.address && `${property.address} — `}{property.neighborhood?.name && `${property.neighborhood.name}, `}{property.city?.name} - SC
                </p>
                <div className="flex items-center gap-2">
                  <FavoriteButton propertyId={property.id} />
                  <ShareButton title={property.title} url={`${siteUrl}/site/imovel/${property.slug}`} />
                </div>
              </div>

              {/* Price bar */}
              <div className="bg-[#0A1628] text-white p-5 mb-8">
                <div className="flex items-end justify-between flex-wrap gap-4">
                  <div>
                    <p className="text-neutral-400 text-xs mb-1">{property.purpose === 'aluguel' ? 'Valor do aluguel' : 'Valor de venda'}</p>
                    <p className="font-serif text-3xl font-bold text-[#C9A84C]">{formatPrice(property.price, property.purpose)}</p>
                  </div>
                  {(property.condo_fee || property.iptu) && (
                    <div className="text-right text-sm text-neutral-400">
                      {property.condo_fee && <p>Condomínio: {formatPrice(property.condo_fee)}/mês</p>}
                      {property.iptu && <p>IPTU: {formatPrice(property.iptu)}/ano</p>}
                    </div>
                  )}
                </div>
              </div>

              {/* Specs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
                {[
                  { icon: '🛏', label: 'Quartos', value: property.bedrooms || '—' },
                  { icon: '🛁', label: 'Banheiros', value: property.bathrooms || '—' },
                  { icon: '🚗', label: 'Vagas', value: property.parking_spots || '—' },
                  { icon: '📐', label: 'Área privativa', value: formatArea(property.private_area) },
                  { icon: '🏠', label: 'Suítes', value: property.suites || '—' },
                  { icon: '📏', label: 'Área total', value: formatArea(property.total_area) },
                  { icon: '🏢', label: 'Andar', value: property.floor ? `${property.floor}º` : '—' },
                  { icon: '📅', label: 'Ano construção', value: property.year_built || '—' },
                ].map(({ icon, label, value }) => (
                  <div key={label} className="border border-neutral-200 p-4 text-center hover:border-[#C9A84C] transition-colors">
                    <div className="text-xl mb-1">{icon}</div>
                    <div className="font-medium text-[#0A1628]">{value}</div>
                    <div className="text-neutral-500 text-xs mt-0.5">{label}</div>
                  </div>
                ))}
              </div>

              {property.description && (
                <div className="mb-8">
                  <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-2">Descrição</h2>
                  <div className="w-8 h-0.5 bg-[#C9A84C] mb-4" />
                  <div className="text-neutral-700 leading-relaxed whitespace-pre-line text-sm">{property.description}</div>
                </div>
              )}

              {property.amenities && property.amenities.length > 0 && (
                <div className="mb-8">
                  <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-2">Comodidades</h2>
                  <div className="w-8 h-0.5 bg-[#C9A84C] mb-4" />
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-2">
                    {property.amenities.map((item: any) => (
                      <div key={item.amenity?.id} className="flex items-center gap-2 text-sm text-neutral-700">
                        <svg className="w-4 h-4 text-[#C9A84C] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>
                        {item.amenity?.name || item.name}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {property.latitude && property.longitude && (
                <div className="mb-8">
                  <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-2">Localização</h2>
                  <div className="w-8 h-0.5 bg-[#C9A84C] mb-4" />
                  <div className="aspect-video bg-neutral-100 overflow-hidden">
                    <iframe
                      src={`https://www.google.com/maps/embed/v1/place?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY}&q=${property.latitude},${property.longitude}&zoom=15`}
                      className="w-full h-full border-0" loading="lazy" allowFullScreen
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-5">
              {property.agent && (
                <div className="border border-neutral-200 p-5 sticky top-24">
                  <p className="text-xs text-neutral-500 uppercase tracking-wide mb-3">Corretor responsável</p>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-neutral-200 rounded-full overflow-hidden flex-shrink-0">
                      {property.agent.photo_url ? (
                        <Image src={property.agent.photo_url} alt={property.agent.name} width={48} height={48} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center font-serif text-xl text-neutral-500">{property.agent.name.charAt(0)}</div>
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-[#0A1628] text-sm">{property.agent.name}</p>
                      {property.agent.creci && <p className="text-neutral-400 text-xs">CRECI {property.agent.creci}</p>}
                    </div>
                  </div>
                  <a href={whatsapp} target="_blank" rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white py-3 text-sm font-medium transition-colors">
                    💬 Tenho interesse neste imóvel
                  </a>
                </div>
              )}
              <LeadForm propertyId={property.id} propertyTitle={property.title} />
            </div>
          </div>

          {similar.length > 0 && (
            <div className="mt-16 pt-10 border-t border-neutral-200">
              <h2 className="font-serif text-2xl font-bold text-[#0A1628] mb-1">Imóveis Similares</h2>
              <div className="w-8 h-0.5 bg-[#C9A84C] mb-8" />
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {similar.map((p: any) => <PropertyCard key={p.id} property={p} />)}
              </div>
            </div>
          )}
        </div>

        <RecentlyViewedStrip excludeId={property.id} />
      </main>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
