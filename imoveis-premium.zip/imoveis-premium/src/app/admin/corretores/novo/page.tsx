import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import AgentForm from '@/components/admin/AgentForm'

export default async function NovoCorretorPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Novo Corretor</h1>
        <p className="text-neutral-500 text-sm mt-0.5">Cadastre um novo corretor na plataforma</p>
      </div>
      <AgentForm />
    </div>
  )
}
