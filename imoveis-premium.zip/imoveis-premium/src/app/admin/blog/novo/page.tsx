import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import BlogPostForm from '@/components/admin/BlogPostForm'

export default async function NovoBlogPostPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: agents } = await supabase
    .from('agents')
    .select('id, name')
    .eq('active', true)
    .order('name')

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Novo Artigo</h1>
        <p className="text-neutral-500 text-sm mt-0.5">Escreva um novo post para o blog</p>
      </div>
      <BlogPostForm agents={agents || []} />
    </div>
  )
}
