-- ============================================================
-- SEED: Demo data for development
-- Run AFTER 001_initial_schema.sql
-- ============================================================

-- Seed neighborhoods
DO $$
DECLARE
  bc_id uuid;
  it_id uuid;
  bl_id uuid;
  ij_id uuid;
  fp_id uuid;
BEGIN
  SELECT id INTO bc_id FROM cities WHERE slug = 'balneario-camboriu';
  SELECT id INTO it_id FROM cities WHERE slug = 'itapema';
  SELECT id INTO bl_id FROM cities WHERE slug = 'blumenau';
  SELECT id INTO ij_id FROM cities WHERE slug = 'itajai';
  SELECT id INTO fp_id FROM cities WHERE slug = 'florianopolis';

  INSERT INTO neighborhoods (name, slug, city_id) VALUES
    ('Centro', 'centro', bc_id),
    ('Barra Sul', 'barra-sul', bc_id),
    ('Barra Norte', 'barra-norte', bc_id),
    ('Taquaras', 'taquaras', bc_id),
    ('Meia Praia', 'meia-praia', it_id),
    ('Centro', 'centro-itapema', it_id),
    ('Centro', 'centro-blumenau', bl_id),
    ('Velha', 'velha', bl_id),
    ('Victor Konder', 'victor-konder', bl_id),
    ('Centro', 'centro-itajai', ij_id),
    ('São João', 'sao-joao', ij_id),
    ('Agronômica', 'agronomica', fp_id),
    ('Campeche', 'campeche', fp_id),
    ('Jurerê Internacional', 'jurere-internacional', fp_id)
  ON CONFLICT DO NOTHING;
END $$;

-- Seed a demo agent
INSERT INTO agents (name, email, phone, whatsapp, creci, bio, active) VALUES
  ('Carlos Rodrigues', 'carlos@premiumsc.com.br', '47991234567', '47991234567', '54321', 'Corretor especializado em alto padrão com 10 anos de experiência.', true),
  ('Ana Lima', 'ana@premiumsc.com.br', '47987654321', '47987654321', '67890', 'Especialista em lançamentos e imóveis de luxo.', true),
  ('Marcos Silva', 'marcos@premiumsc.com.br', '47911112222', '47911112222', '11223', 'Focado em imóveis para investimento e renda.', true)
ON CONFLICT DO NOTHING;

-- Seed demo properties
DO $$
DECLARE
  bc_id uuid; it_id uuid; bl_id uuid;
  n_centro uuid; n_meia_praia uuid; n_barra_sul uuid; n_centro_bl uuid;
  agent1_id uuid;
  p1_id uuid; p2_id uuid; p3_id uuid; p4_id uuid; p5_id uuid; p6_id uuid;
  am_piscina uuid; am_academia uuid; am_churras uuid; am_elevador uuid;
BEGIN
  SELECT id INTO bc_id FROM cities WHERE slug = 'balneario-camboriu';
  SELECT id INTO it_id FROM cities WHERE slug = 'itapema';
  SELECT id INTO bl_id FROM cities WHERE slug = 'blumenau';
  SELECT id INTO n_centro FROM neighborhoods WHERE slug = 'centro' AND city_id = bc_id;
  SELECT id INTO n_meia_praia FROM neighborhoods WHERE slug = 'meia-praia';
  SELECT id INTO n_barra_sul FROM neighborhoods WHERE slug = 'barra-sul';
  SELECT id INTO n_centro_bl FROM neighborhoods WHERE slug = 'centro-blumenau';
  SELECT id INTO agent1_id FROM agents WHERE email = 'carlos@premiumsc.com.br';
  SELECT id INTO am_piscina FROM amenities WHERE name = 'Piscina';
  SELECT id INTO am_academia FROM amenities WHERE name = 'Academia';
  SELECT id INTO am_churras FROM amenities WHERE name = 'Churrasqueira';
  SELECT id INTO am_elevador FROM amenities WHERE name = 'Elevador';

  -- Property 1
  INSERT INTO properties (
    code, title, slug, description, type, purpose, status,
    price, condo_fee, iptu, city_id, neighborhood_id,
    address, address_number, latitude, longitude,
    bedrooms, suites, bathrooms, parking_spots,
    private_area, total_area, floor, total_floors, year_built,
    furnished, pet_friendly, gated_community, featured, launch,
    agent_id, published_at
  ) VALUES (
    'BC0001', 'Cobertura Duplex com Vista Mar 360°', 'cobertura-duplex-vista-mar-bc0001',
    'Cobertura dúplex com terraço privativo e vista panorâmica para o mar. Acabamento premium, cozinha gourmet integrada, suítes com closet e banheira de hidromassagem. Condomínio com piscina, academia e salão de festas.',
    'cobertura', 'venda', 'ativo',
    1850000, 1200, 8400, bc_id, n_centro,
    'Av. Atlântica', '1000', -26.9906, -48.6348,
    4, 4, 5, 3, 280, 320, 22, 25, 2022,
    true, false, true, true, false,
    agent1_id, now()
  ) RETURNING id INTO p1_id;

  -- Property 2
  INSERT INTO properties (
    code, title, slug, description, type, purpose, status,
    price, condo_fee, city_id, neighborhood_id,
    address, latitude, longitude,
    bedrooms, suites, bathrooms, parking_spots,
    private_area, total_area, floor, year_built,
    furnished, pet_friendly, gated_community, featured, launch,
    agent_id, published_at
  ) VALUES (
    'IT0001', 'Apartamento Alto Padrão Frente Mar', 'apartamento-alto-padrao-frente-mar-it0001',
    'Lindo apartamento com vista mar direta. 3 suítes com closet, varanda gourmet, cozinha planejada. Condomínio completo com piscina aquecida e spa.',
    'apartamento', 'venda', 'ativo',
    920000, 800, it_id, n_meia_praia,
    'Av. Costa Verde', -27.0862, -48.6167,
    3, 3, 3, 2, 130, 155, 10, 20, 2023,
    true, true, true, true, true,
    agent1_id, now()
  ) RETURNING id INTO p2_id;

  -- Property 3
  INSERT INTO properties (
    code, title, slug, description, type, purpose, status,
    price, condo_fee, city_id, neighborhood_id,
    latitude, longitude,
    bedrooms, suites, bathrooms, parking_spots,
    private_area, year_built,
    furnished, pet_friendly, gated_community, featured,
    agent_id, published_at
  ) VALUES (
    'BC0002', 'Apartamento 2 Dormitórios no Centro', 'apartamento-2-dorms-centro-bc0002',
    'Ótima localização, pertinho da praia. Apartamento reformado, cozinha planejada, varanda com churrasqueira.',
    'apartamento', 'venda', 'ativo',
    480000, 600, bc_id, n_centro,
    -26.9950, -48.6380,
    2, 1, 2, 1, 78, 2018,
    false, true, false, false,
    agent1_id, now()
  ) RETURNING id INTO p3_id;

  -- Property 4 (rental)
  INSERT INTO properties (
    code, title, slug, description, type, purpose, status,
    price, condo_fee, city_id, neighborhood_id,
    latitude, longitude,
    bedrooms, suites, bathrooms, parking_spots,
    private_area, year_built, furnished, pet_friendly,
    featured, agent_id, published_at
  ) VALUES (
    'BL0001', 'Studio Moderno para Alugar no Centro', 'studio-moderno-alugar-centro-bl0001',
    'Studio totalmente mobiliado e equipado. Excelente localização, próximo ao centro comercial. Ideal para solteiros e casais.',
    'studio', 'aluguel', 'ativo',
    2800, 450, bl_id, n_centro_bl,
    -26.9022, -49.0700,
    1, 0, 1, 1, 45, 2021, true, true,
    false, agent1_id, now()
  ) RETURNING id INTO p4_id;

  -- Property 5
  INSERT INTO properties (
    code, title, slug, description, type, purpose, status,
    price, city_id, neighborhood_id,
    latitude, longitude,
    bedrooms, suites, bathrooms, parking_spots,
    private_area, total_area, year_built,
    furnished, pet_friendly, gated_community, featured,
    agent_id, published_at
  ) VALUES (
    'BC0003', 'Casa em Condomínio Fechado - Barra Sul', 'casa-condominio-fechado-barra-sul-bc0003',
    'Casa em condomínio de alto padrão com 4 dormitórios, área de lazer completa, piscina privativa e churrasqueira. Segurança 24h.',
    'casa', 'venda', 'ativo',
    1200000, bc_id, n_barra_sul,
    -26.9800, -48.6200,
    4, 2, 4, 4, 250, 350, 2020,
    false, false, true, true,
    agent1_id, now()
  ) RETURNING id INTO p5_id;

  -- Property 6 (launch)
  INSERT INTO properties (
    code, title, slug, description, type, purpose, status,
    price, condo_fee, city_id, neighborhood_id,
    latitude, longitude,
    bedrooms, suites, bathrooms, parking_spots,
    private_area, total_area, floor, total_floors,
    furnished, pet_friendly, gated_community, featured, launch,
    agent_id, published_at
  ) VALUES (
    'IT0002', 'Lançamento - Residencial Oceano - Meia Praia', 'lancamento-residencial-oceano-meia-praia-it0002',
    'Lançamento exclusivo em Meia Praia. Torre única com apenas 2 apartamentos por andar. Vista total para o mar. Previsão de entrega: dezembro/2026.',
    'apartamento', 'lancamento', 'ativo',
    750000, 700, it_id, n_meia_praia,
    -27.0900, -48.6150,
    2, 2, 2, 2, 95, 110, 8, 18,
    false, false, true, true, true,
    agent1_id, now()
  ) RETURNING id INTO p6_id;

  -- Link amenities
  INSERT INTO property_amenities (property_id, amenity_id) VALUES
    (p1_id, am_piscina), (p1_id, am_academia), (p1_id, am_churras), (p1_id, am_elevador),
    (p2_id, am_piscina), (p2_id, am_academia), (p2_id, am_elevador),
    (p5_id, am_piscina), (p5_id, am_churras)
  ON CONFLICT DO NOTHING;

END $$;
