import { createClient } from '@/lib/supabase/server'
import { SearchFilters, PaginatedResponse, Property } from '@/types'

const PROPERTY_SELECT = `
  id, code, title, slug, description, type, purpose, status,
  price, condo_fee, iptu, address, address_number, zip_code,
  latitude, longitude, bedrooms, suites, bathrooms, parking_spots,
  private_area, total_area, floor, total_floors, year_built,
  furnished, pet_friendly, gated_community, featured, launch,
  views_count, video_url, virtual_tour_url, seo_title, seo_description,
  published_at, created_at, updated_at,
  city:cities(id, name, slug, state),
  neighborhood:neighborhoods(id, name, slug),
  agent:agents(id, name, phone, whatsapp, photo_url, creci),
  images:property_images(id, url, alt, position, is_cover),
  amenities:property_amenities(amenity:amenities(id, name, icon, category))
`

export async function getProperties(filters: SearchFilters = {}): Promise<PaginatedResponse<Property>> {
  const supabase = await createClient()
  const { page = 1, per_page = 12, sort = 'newest', ...rest } = filters

  let query = supabase
    .from('properties')
    .select(PROPERTY_SELECT, { count: 'exact' })
    .eq('status', 'ativo')

  if (rest.purpose) query = query.eq('purpose', rest.purpose)
  if (rest.type) query = query.eq('type', rest.type)
  if (rest.city_id) query = query.eq('city_id', rest.city_id)
  if (rest.neighborhood_id) query = query.eq('neighborhood_id', rest.neighborhood_id)
  if (rest.min_price) query = query.gte('price', rest.min_price)
  if (rest.max_price) query = query.lte('price', rest.max_price)
  if (rest.bedrooms) query = query.gte('bedrooms', rest.bedrooms)
  if (rest.suites) query = query.gte('suites', rest.suites)
  if (rest.parking_spots) query = query.gte('parking_spots', rest.parking_spots)
  if (rest.min_area) query = query.gte('private_area', rest.min_area)
  if (rest.max_area) query = query.lte('private_area', rest.max_area)
  if (rest.furnished !== undefined) query = query.eq('furnished', rest.furnished)
  if (rest.pet_friendly !== undefined) query = query.eq('pet_friendly', rest.pet_friendly)
  if (rest.gated_community !== undefined) query = query.eq('gated_community', rest.gated_community)

  switch (sort) {
    case 'price_asc': query = query.order('price', { ascending: true }); break
    case 'price_desc': query = query.order('price', { ascending: false }); break
    case 'most_viewed': query = query.order('views_count', { ascending: false }); break
    default: query = query.order('published_at', { ascending: false })
  }

  const from = (page - 1) * per_page
  query = query.range(from, from + per_page - 1)

  const { data, error, count } = await query

  if (error) throw error

  return {
    data: (data || []) as unknown as Property[],
    total: count || 0,
    page,
    per_page,
    total_pages: Math.ceil((count || 0) / per_page),
  }
}

export async function getPropertyBySlug(slug: string): Promise<Property | null> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('properties')
    .select(PROPERTY_SELECT)
    .eq('slug', slug)
    .single()

  if (error) return null

  // Increment views
  await supabase.rpc('increment_views', { property_id: data.id })

  return data as unknown as Property
}

export async function getFeaturedProperties(limit = 6): Promise<Property[]> {
  const supabase = await createClient()
  const { data } = await supabase
    .from('properties')
    .select(PROPERTY_SELECT)
    .eq('status', 'ativo')
    .eq('featured', true)
    .order('published_at', { ascending: false })
    .limit(limit)

  return (data || []) as unknown as Property[]
}

export async function getLaunchProperties(limit = 6): Promise<Property[]> {
  const supabase = await createClient()
  const { data } = await supabase
    .from('properties')
    .select(PROPERTY_SELECT)
    .eq('status', 'ativo')
    .eq('launch', true)
    .order('published_at', { ascending: false })
    .limit(limit)

  return (data || []) as unknown as Property[]
}

export async function getSimilarProperties(property: Property, limit = 4): Promise<Property[]> {
  const supabase = await createClient()
  const { data } = await supabase
    .from('properties')
    .select(PROPERTY_SELECT)
    .eq('status', 'ativo')
    .eq('type', property.type)
    .eq('purpose', property.purpose)
    .eq('city_id', property.city_id)
    .neq('id', property.id)
    .limit(limit)

  return (data || []) as unknown as Property[]
}

export async function getCities() {
  const supabase = await createClient()
  const { data } = await supabase
    .from('cities')
    .select('*')
    .order('name')

  return data || []
}

export async function getNeighborhoodsByCity(cityId: string) {
  const supabase = await createClient()
  const { data } = await supabase
    .from('neighborhoods')
    .select('*')
    .eq('city_id', cityId)
    .order('name')

  return data || []
}

export async function createLead(lead: {
  property_id?: string
  name: string
  email?: string
  phone: string
  message?: string
  source?: string
}) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('leads')
    .insert({ ...lead, source: lead.source || 'site' })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getDashboardStats() {
  const supabase = await createClient()

  const [
    { count: total },
    { count: active },
    { count: sold },
    { count: totalLeads },
    { count: newLeads },
  ] = await Promise.all([
    supabase.from('properties').select('*', { count: 'exact', head: true }),
    supabase.from('properties').select('*', { count: 'exact', head: true }).eq('status', 'ativo'),
    supabase.from('properties').select('*', { count: 'exact', head: true }).in('status', ['vendido', 'alugado']),
    supabase.from('leads').select('*', { count: 'exact', head: true }),
    supabase.from('leads').select('*', { count: 'exact', head: true }).eq('status', 'novo'),
  ])

  return {
    total_properties: total || 0,
    active_properties: active || 0,
    sold_properties: sold || 0,
    total_leads: totalLeads || 0,
    new_leads: newLeads || 0,
  }
}
