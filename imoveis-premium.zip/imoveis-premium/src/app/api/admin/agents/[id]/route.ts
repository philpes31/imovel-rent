import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

interface Params { params: Promise<{ id: string }> }

export async function PUT(req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()

  try {
    const fd = await req.formData()
    const updates: any = {
      name: fd.get('name'),
      email: fd.get('email'),
      phone: fd.get('phone') || null,
      whatsapp: fd.get('whatsapp') || null,
      creci: fd.get('creci') || null,
      bio: fd.get('bio') || null,
      active: fd.get('active') === 'true',
    }

    const photo = fd.get('photo') as File | null
    if (photo && photo.size > 0) {
      const ext = photo.name.split('.').pop()
      const path = `agents/${id}.${ext}`
      const { data: up } = await supabase.storage.from('agent-photos').upload(path, photo, { upsert: true })
      if (up) {
        const { data: { publicUrl } } = supabase.storage.from('agent-photos').getPublicUrl(up.path)
        updates.photo_url = publicUrl
      }
    }

    const { error } = await supabase.from('agents').update(updates).eq('id', id)
    if (error) throw error
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()

  try {
    await supabase.from('agents').update({ active: false }).eq('id', id)
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
