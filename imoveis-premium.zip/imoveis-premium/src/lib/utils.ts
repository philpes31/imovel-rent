import { Property } from '@/types'

export function formatPrice(price: number, purpose?: string): string {
  const formatted = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price)

  if (purpose === 'aluguel') return `${formatted}/mês`
  return formatted
}

export function formatArea(area?: number): string {
  if (!area) return '-'
  return `${area.toLocaleString('pt-BR')} m²`
}

export function getPropertyCover(property: Property): string {
  const cover = property.images?.find(img => img.is_cover)
  if (cover) return cover.url
  if (property.images?.[0]) return property.images[0].url
  return '/placeholder-property.jpg'
}

export function getWhatsAppLink(phone: string, message: string): string {
  const cleaned = phone.replace(/\D/g, '')
  const encoded = encodeURIComponent(message)
  return `https://wa.me/55${cleaned}?text=${encoded}`
}

export function generatePropertyWhatsApp(property: Property, agentPhone?: string): string {
  const phone = agentPhone || process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '5547999999999'
  const message = `Olá! Tenho interesse no imóvel *${property.title}* (Cód: ${property.code}). Poderia me dar mais informações?`
  return getWhatsAppLink(phone, message)
}

export function truncate(text: string, length: number): string {
  if (text.length <= length) return text
  return text.slice(0, length) + '...'
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim()
}

export function generatePropertyCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)]
  }
  return code
}

export const PROPERTY_TYPES = [
  { value: 'apartamento', label: 'Apartamento' },
  { value: 'casa', label: 'Casa' },
  { value: 'terreno', label: 'Terreno' },
  { value: 'comercial', label: 'Comercial' },
  { value: 'cobertura', label: 'Cobertura' },
  { value: 'studio', label: 'Studio' },
  { value: 'flat', label: 'Flat' },
  { value: 'chacara', label: 'Chácara' },
]

export const CITIES_FEATURED = [
  { name: 'Balneário Camboriú', slug: 'balneario-camboriu', image: '/cities/balneario-camboriu.jpg', subtitle: 'A Dubai brasileira' },
  { name: 'Itapema', slug: 'itapema', image: '/cities/itapema.jpg', subtitle: 'Praias e modernidade' },
  { name: 'Blumenau', slug: 'blumenau', image: '/cities/blumenau.jpg', subtitle: 'Tradição e inovação' },
  { name: 'Itajaí', slug: 'itajai', image: '/cities/itajai.jpg', subtitle: 'Porto e oportunidades' },
  { name: 'Florianópolis', slug: 'florianopolis', image: '/cities/florianopolis.jpg', subtitle: 'A ilha da magia' },
]

export function generateSitemapXml(properties: Property[]): string {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://imoveis.com.br'
  const urls = properties.map(p => `
  <url>
    <loc>${baseUrl}/imovel/${p.slug}</loc>
    <lastmod>${new Date(p.updated_at).toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`).join('')

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${baseUrl}/comprar</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${baseUrl}/alugar</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  ${urls}
</urlset>`
}

export function generatePropertySchema(property: Property) {
  return {
    '@context': 'https://schema.org',
    '@type': 'RealEstateListing',
    name: property.title,
    description: property.description,
    url: `${process.env.NEXT_PUBLIC_SITE_URL}/imovel/${property.slug}`,
    image: property.images?.map(img => img.url),
    offers: {
      '@type': 'Offer',
      price: property.price,
      priceCurrency: 'BRL',
    },
    address: {
      '@type': 'PostalAddress',
      streetAddress: property.address,
      addressLocality: property.city?.name,
      addressRegion: 'SC',
      addressCountry: 'BR',
    },
    numberOfRooms: property.bedrooms,
    floorSize: {
      '@type': 'QuantitativeValue',
      value: property.private_area,
      unitCode: 'MTK',
    },
  }
}

export function generateXMLFeed(properties: Property[]): string {
  const items = properties.map(p => `
  <imovel>
    <codigo>${p.code}</codigo>
    <titulo>${p.title}</titulo>
    <tipo>${p.type}</tipo>
    <finalidade>${p.purpose === 'venda' ? 'Venda' : 'Locação'}</finalidade>
    <preco>${p.price}</preco>
    <cidade>${p.city?.name}</cidade>
    <bairro>${p.neighborhood?.name || ''}</bairro>
    <endereco>${p.address || ''}</endereco>
    <quartos>${p.bedrooms}</quartos>
    <banheiros>${p.bathrooms}</banheiros>
    <vagas>${p.parking_spots}</vagas>
    <area>${p.private_area || 0}</area>
    <descricao><![CDATA[${p.description || ''}]]></descricao>
    <fotos>
      ${(p.images || []).map(img => `<foto>${img.url}</foto>`).join('\n      ')}
    </fotos>
  </imovel>`).join('')

  return `<?xml version="1.0" encoding="UTF-8"?>
<imoveis>
  ${items}
</imoveis>`
}
