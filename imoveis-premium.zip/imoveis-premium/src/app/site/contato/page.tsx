'use client'

import { useState } from 'react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'

const WHATSAPP = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '5547999999999'

export default function ContatoPage() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' })
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, source: 'site' }),
      })
      setSent(true)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">

        {/* Header */}
        <div className="bg-[#0A1628] py-16 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase font-medium mb-3">Fale conosco</p>
            <h1 className="font-serif text-4xl font-bold text-white mb-4">Contato</h1>
            <div className="w-12 h-0.5 bg-[#C9A84C] mx-auto mb-4" />
            <p className="text-neutral-400">Nossa equipe está pronta para atender você</p>
          </div>
        </div>

        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-10">

              {/* Info */}
              <div className="space-y-6">
                <div>
                  <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-4">Como nos encontrar</h2>
                  <div className="w-10 h-0.5 bg-[#C9A84C] mb-6" />
                </div>

                {[
                  {
                    icon: '📍',
                    title: 'Endereço',
                    lines: ['Av. Atlântica, 1000 - Sala 301', 'Centro - Balneário Camboriú, SC', 'CEP: 88330-000'],
                  },
                  {
                    icon: '📞',
                    title: 'Telefone',
                    lines: ['(47) 3333-3333', '(47) 3333-3334'],
                  },
                  {
                    icon: '💬',
                    title: 'WhatsApp',
                    lines: ['(47) 99999-9999'],
                  },
                  {
                    icon: '✉️',
                    title: 'E-mail',
                    lines: ['contato@premiumsc.com.br', 'vendas@premiumsc.com.br'],
                  },
                  {
                    icon: '🕐',
                    title: 'Horário de Atendimento',
                    lines: ['Seg–Sex: 09h às 18h', 'Sábado: 09h às 13h'],
                  },
                ].map(info => (
                  <div key={info.title} className="flex gap-4">
                    <div className="w-9 h-9 bg-neutral-100 flex items-center justify-center flex-shrink-0 text-lg">
                      {info.icon}
                    </div>
                    <div>
                      <h3 className="font-medium text-[#0A1628] text-sm mb-0.5">{info.title}</h3>
                      {info.lines.map(l => (
                        <p key={l} className="text-neutral-500 text-sm">{l}</p>
                      ))}
                    </div>
                  </div>
                ))}

                <a
                  href={`https://wa.me/${WHATSAPP}?text=Olá! Gostaria de falar com um corretor.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 justify-center w-full bg-green-500 hover:bg-green-600 text-white py-3 text-sm font-medium transition-colors mt-4"
                >
                  Chamar no WhatsApp agora
                </a>
              </div>

              {/* Form */}
              <div className="lg:col-span-2">
                {sent ? (
                  <div className="bg-green-50 border border-green-200 p-10 text-center">
                    <div className="text-4xl mb-4">✅</div>
                    <h3 className="font-serif text-xl font-bold text-green-800 mb-2">Mensagem enviada!</h3>
                    <p className="text-green-700">Em breve nossa equipe entrará em contato com você.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="bg-white border border-neutral-200 p-8">
                    <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-6">Envie uma mensagem</h2>
                    <div className="grid sm:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
                          Nome completo <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={form.name}
                          onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
                          placeholder="Seu nome"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
                          Telefone <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="tel"
                          required
                          value={form.phone}
                          onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
                          placeholder="(47) 99999-9999"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
                          E-mail
                        </label>
                        <input
                          type="email"
                          value={form.email}
                          onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
                          placeholder="seu@email.com"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
                          Assunto
                        </label>
                        <select
                          value={form.subject}
                          onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C] bg-white"
                        >
                          <option value="">Selecione...</option>
                          <option>Quero comprar um imóvel</option>
                          <option>Quero alugar um imóvel</option>
                          <option>Quero vender meu imóvel</option>
                          <option>Informações sobre lançamentos</option>
                          <option>Outro assunto</option>
                        </select>
                      </div>
                    </div>
                    <div className="mb-5">
                      <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
                        Mensagem
                      </label>
                      <textarea
                        rows={5}
                        value={form.message}
                        onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                        className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C] resize-none"
                        placeholder="Como podemos ajudar?"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-[#0A1628] hover:bg-[#1a2d4a] disabled:bg-neutral-400 text-white py-3 font-medium text-sm transition-colors"
                    >
                      {loading ? 'Enviando...' : 'Enviar mensagem'}
                    </button>
                    <p className="text-neutral-400 text-xs text-center mt-3">
                      Seus dados estão protegidos conforme nossa{' '}
                      <a href="/privacidade" className="underline">política de privacidade</a>.
                    </p>
                  </form>
                )}

                {/* Map embed */}
                <div className="mt-6 aspect-video bg-neutral-200 overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3564.3!2d-48.636!3d-26.991!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDU5JzE2LjAiUyA0OMKwMzgnMDkuNiJX!5e0!3m2!1spt-BR!2sbr!4v1000000000000"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    title="Localização PremiumSC"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
