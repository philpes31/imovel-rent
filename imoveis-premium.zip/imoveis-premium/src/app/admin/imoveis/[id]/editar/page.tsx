import { createClient } from '@/lib/supabase/server'
import { redirect, notFound } from 'next/navigation'
import PropertyForm from '@/components/admin/PropertyForm'

interface Props {
  params: Promise<{ id: string }>
}

export default async function EditarImovelPage({ params }: Props) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const [
    { data: property },
    { data: cities },
    { data: neighborhoods },
    { data: amenities },
  ] = await Promise.all([
    supabase
      .from('properties')
      .select(`
        *,
        images:property_images(*),
        amenities:property_amenities(amenity:amenities(*))
      `)
      .eq('id', id)
      .single(),
    supabase.from('cities').select('id, name').order('name'),
    supabase.from('neighborhoods').select('id, name, city_id').order('name'),
    supabase.from('amenities').select('id, name, category').order('name'),
  ])

  if (!property) notFound()

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Editar Imóvel</h1>
        <p className="text-neutral-500 text-sm mt-0.5">{property.title}</p>
      </div>
      <PropertyForm
        cities={cities || []}
        allNeighborhoods={neighborhoods || []}
        amenities={amenities || []}
        property={property}
      />
    </div>
  )
}
