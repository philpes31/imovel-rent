'use client'

import { useFavorites } from '@/hooks/useFavorites'

interface Props {
  propertyId: string
  className?: string
}

export default function FavoriteButton({ propertyId, className = '' }: Props) {
  const { toggle, isFavorite, loaded } = useFavorites()

  if (!loaded) return null

  const active = isFavorite(propertyId)

  return (
    <button
      onClick={e => {
        e.preventDefault()
        e.stopPropagation()
        toggle(propertyId)
      }}
      className={`flex items-center justify-center w-9 h-9 transition-all ${
        active
          ? 'bg-red-500 text-white'
          : 'bg-white/80 backdrop-blur-sm text-neutral-600 hover:text-red-500'
      } ${className}`}
      aria-label={active ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
      title={active ? 'Remover dos favoritos' : 'Salvar'}
    >
      <svg
        className="w-4 h-4"
        fill={active ? 'currentColor' : 'none'}
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
        />
      </svg>
    </button>
  )
}
