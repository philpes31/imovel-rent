import type { Metadata } from 'next'
import { createClient } from '@/lib/supabase/server'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import Image from 'next/image'
import Link from 'next/link'
import { formatPrice, formatArea, getPropertyCover } from '@/lib/utils'

export const metadata: Metadata = {
  title: 'Comparar Imóveis | PremiumSC',
}

interface PageProps {
  searchParams: Promise<{ ids?: string }>
}

const FIELDS = [
  { label: 'Preço', key: 'price', format: (p: any) => formatPrice(p.price, p.purpose) },
  { label: 'Tipo', key: 'type', format: (p: any) => p.type?.charAt(0).toUpperCase() + p.type?.slice(1) },
  { label: 'Finalidade', key: 'purpose', format: (p: any) => p.purpose === 'venda' ? 'Venda' : p.purpose === 'aluguel' ? 'Aluguel' : 'Lançamento' },
  { label: 'Quartos', key: 'bedrooms', format: (p: any) => p.bedrooms || '—' },
  { label: 'Suítes', key: 'suites', format: (p: any) => p.suites || '—' },
  { label: 'Banheiros', key: 'bathrooms', format: (p: any) => p.bathrooms || '—' },
  { label: 'Vagas', key: 'parking_spots', format: (p: any) => p.parking_spots || '—' },
  { label: 'Área Privativa', key: 'private_area', format: (p: any) => formatArea(p.private_area) },
  { label: 'Área Total', key: 'total_area', format: (p: any) => formatArea(p.total_area) },
  { label: 'Andar', key: 'floor', format: (p: any) => p.floor ? `${p.floor}º` : '—' },
  { label: 'Ano', key: 'year_built', format: (p: any) => p.year_built || '—' },
  { label: 'Condomínio', key: 'condo_fee', format: (p: any) => p.condo_fee ? formatPrice(p.condo_fee) : '—' },
  { label: 'Mobiliado', key: 'furnished', format: (p: any) => p.furnished ? '✓ Sim' : '✗ Não' },
  { label: 'Pet Friendly', key: 'pet_friendly', format: (p: any) => p.pet_friendly ? '✓ Sim' : '✗ Não' },
  { label: 'Cond. Fechado', key: 'gated_community', format: (p: any) => p.gated_community ? '✓ Sim' : '✗ Não' },
  { label: 'Cidade', key: 'city', format: (p: any) => p.city?.name || '—' },
  { label: 'Bairro', key: 'neighborhood', format: (p: any) => p.neighborhood?.name || '—' },
]

export default async function CompararPage({ searchParams }: PageProps) {
  const { ids } = await searchParams
  const idList = ids?.split(',').filter(Boolean).slice(0, 3) || []

  let properties: any[] = []
  if (idList.length > 0) {
    const supabase = await createClient()
    const { data } = await supabase
      .from('properties')
      .select(`
        id, code, title, slug, type, purpose, status, price, condo_fee, iptu,
        bedrooms, suites, bathrooms, parking_spots, private_area, total_area,
        floor, year_built, furnished, pet_friendly, gated_community,
        city:cities(name), neighborhood:neighborhoods(name),
        images:property_images(url, is_cover, position),
        amenities:property_amenities(amenity:amenities(name))
      `)
      .in('id', idList)
    properties = data || []
  }

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="bg-[#0A1628] py-10 px-4">
          <div className="max-w-7xl mx-auto">
            <h1 className="font-serif text-3xl font-bold text-white mb-1">Comparar Imóveis</h1>
            <p className="text-neutral-400 text-sm">{properties.length} imóveis selecionados para comparação</p>
          </div>
        </div>

        {properties.length < 2 ? (
          <div className="max-w-2xl mx-auto px-4 py-20 text-center">
            <div className="text-5xl mb-4">📊</div>
            <h2 className="font-serif text-2xl font-bold text-neutral-700 mb-3">
              Selecione pelo menos 2 imóveis
            </h2>
            <p className="text-neutral-400 mb-6 text-sm">
              Use o botão "Comparar" nos cards de imóveis para adicioná-los aqui.
            </p>
            <Link href="/site/imoveis" className="inline-block bg-[#0A1628] text-white px-8 py-3 text-sm font-medium hover:bg-[#1a2d4a] transition-colors">
              Ver imóveis
            </Link>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 overflow-x-auto">
            <table className="w-full border-collapse bg-white">
              {/* Header row with property cards */}
              <thead>
                <tr>
                  <th className="w-44 bg-neutral-50 border border-neutral-200 p-4 text-left">
                    <span className="text-xs font-medium text-neutral-500 uppercase tracking-wide">Característica</span>
                  </th>
                  {properties.map(p => (
                    <th key={p.id} className="border border-neutral-200 p-0 align-top min-w-[220px]">
                      <div className="relative h-40 bg-neutral-200">
                        <Image
                          src={getPropertyCover(p)}
                          alt={p.title}
                          fill
                          className="object-cover"
                          sizes="220px"
                        />
                      </div>
                      <div className="p-4 text-left">
                        <p className="font-serif text-lg font-bold text-[#C9A84C]">
                          {formatPrice(p.price, p.purpose)}
                        </p>
                        <h3 className="font-medium text-[#0A1628] text-sm leading-snug mt-1 mb-2 line-clamp-2">
                          {p.title}
                        </h3>
                        <Link
                          href={`/site/imovel/${p.slug}`}
                          className="inline-block text-xs text-white bg-[#0A1628] hover:bg-[#1a2d4a] px-3 py-1.5 transition-colors"
                        >
                          Ver imóvel
                        </Link>
                      </div>
                    </th>
                  ))}
                  {/* Empty filler columns if < 3 */}
                  {Array.from({ length: 3 - properties.length }).map((_, i) => (
                    <th key={i} className="border border-neutral-200 bg-neutral-50 min-w-[220px]">
                      <div className="h-40 flex items-center justify-center">
                        <Link href="/site/imoveis" className="text-neutral-400 text-sm hover:text-[#0A1628] transition-colors">
                          + Adicionar imóvel
                        </Link>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>

              {/* Comparison rows */}
              <tbody>
                {FIELDS.map((field, idx) => (
                  <tr key={field.key} className={idx % 2 === 0 ? 'bg-white' : 'bg-neutral-50/50'}>
                    <td className="border border-neutral-200 px-4 py-3 text-xs font-medium text-neutral-600 uppercase tracking-wide">
                      {field.label}
                    </td>
                    {properties.map(p => {
                      const val = field.format(p)
                      const isGood = String(val).startsWith('✓')
                      const isBad = String(val).startsWith('✗')
                      return (
                        <td
                          key={p.id}
                          className={`border border-neutral-200 px-4 py-3 text-sm text-center font-medium ${
                            isGood ? 'text-green-600' : isBad ? 'text-neutral-400' : 'text-[#0A1628]'
                          }`}
                        >
                          {val}
                        </td>
                      )
                    })}
                    {Array.from({ length: 3 - properties.length }).map((_, i) => (
                      <td key={i} className="border border-neutral-200" />
                    ))}
                  </tr>
                ))}

                {/* Amenities row */}
                <tr>
                  <td className="border border-neutral-200 px-4 py-3 text-xs font-medium text-neutral-600 uppercase tracking-wide">
                    Comodidades
                  </td>
                  {properties.map(p => (
                    <td key={p.id} className="border border-neutral-200 px-4 py-3">
                      <div className="flex flex-wrap gap-1 justify-center">
                        {(p.amenities || []).slice(0, 6).map((a: any) => (
                          <span key={a.amenity?.name} className="text-xs bg-neutral-100 text-neutral-600 px-2 py-0.5">
                            {a.amenity?.name}
                          </span>
                        ))}
                        {p.amenities?.length > 6 && (
                          <span className="text-xs text-neutral-400">+{p.amenities.length - 6}</span>
                        )}
                      </div>
                    </td>
                  ))}
                  {Array.from({ length: 3 - properties.length }).map((_, i) => (
                    <td key={i} className="border border-neutral-200" />
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
