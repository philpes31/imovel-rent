/**
 * Simple in-memory rate limiter for API routes.
 * For production, replace with Redis/Upstash.
 */

interface RateEntry {
  count: number
  resetAt: number
}

const store = new Map<string, RateEntry>()

interface RateLimitOptions {
  /** Max requests per window */
  limit?: number
  /** Window in seconds */
  windowSec?: number
}

export function rateLimit(key: string, options: RateLimitOptions = {}) {
  const { limit = 10, windowSec = 60 } = options
  const now = Date.now()
  const entry = store.get(key)

  if (!entry || now > entry.resetAt) {
    store.set(key, { count: 1, resetAt: now + windowSec * 1000 })
    return { allowed: true, remaining: limit - 1, resetAt: now + windowSec * 1000 }
  }

  entry.count++
  store.set(key, entry)

  const remaining = Math.max(0, limit - entry.count)
  const allowed = entry.count <= limit

  // Clean up old entries every 1000 requests
  if (store.size > 1000) {
    for (const [k, v] of store.entries()) {
      if (now > v.resetAt) store.delete(k)
    }
  }

  return { allowed, remaining, resetAt: entry.resetAt }
}

/**
 * Extract client IP from request headers
 */
export function getClientIp(headers: Headers): string {
  return (
    headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    headers.get('x-real-ip') ||
    'unknown'
  )
}
