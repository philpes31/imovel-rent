import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Image from 'next/image'

export default async function CorretoresPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: agents, count } = await supabase
    .from('agents')
    .select('*', { count: 'exact' })
    .order('name')

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Corretores</h1>
          <p className="text-neutral-500 text-sm mt-0.5">{count} corretores cadastrados</p>
        </div>
        <a
          href="/admin/corretores/novo"
          className="bg-[#C9A84C] text-white px-5 py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors"
        >
          + Novo corretor
        </a>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {(agents || []).map((agent: any) => (
          <div key={agent.id} className="bg-white border border-neutral-200 p-5 hover:border-[#C9A84C] transition-colors">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-full bg-neutral-200 overflow-hidden flex-shrink-0">
                {agent.photo_url ? (
                  <Image
                    src={agent.photo_url}
                    alt={agent.name}
                    width={48}
                    height={48}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-neutral-500 font-medium">
                    {agent.name.charAt(0)}
                  </div>
                )}
              </div>
              <div>
                <h3 className="font-medium text-[#0A1628] text-sm">{agent.name}</h3>
                {agent.creci && (
                  <p className="text-neutral-400 text-xs">CRECI {agent.creci}</p>
                )}
              </div>
            </div>

            <div className="space-y-1 text-xs text-neutral-500 border-t border-neutral-100 pt-3 mb-3">
              {agent.phone && <p>📞 {agent.phone}</p>}
              {agent.email && <p>✉ {agent.email}</p>}
            </div>

            <div className="flex items-center justify-between">
              <span className={`text-xs px-2 py-1 ${agent.active ? 'bg-green-100 text-green-700' : 'bg-neutral-100 text-neutral-500'}`}>
                {agent.active ? 'Ativo' : 'Inativo'}
              </span>
              <a
                href={`/admin/corretores/${agent.id}/editar`}
                className="text-xs text-[#0A1628] hover:text-[#C9A84C] font-medium transition-colors"
              >
                Editar
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
