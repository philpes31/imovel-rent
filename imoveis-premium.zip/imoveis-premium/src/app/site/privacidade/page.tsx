import type { Metadata } from 'next'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'

export const metadata: Metadata = {
  title: 'Política de Privacidade | PremiumSC',
}

export default function PrivacidadePage() {
  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="bg-[#0A1628] py-12 px-4">
          <div className="max-w-3xl mx-auto">
            <h1 className="font-serif text-3xl font-bold text-white">Política de Privacidade</h1>
            <div className="w-10 h-0.5 bg-[#C9A84C] mt-3" />
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
          <div className="bg-white border border-neutral-200 p-8 prose prose-neutral max-w-none text-sm leading-relaxed">
            <p className="text-neutral-500 mb-6">Última atualização: Janeiro de 2025</p>

            <h2 className="font-serif text-xl font-bold text-[#0A1628] mt-6 mb-3">1. Informações coletadas</h2>
            <p>A PremiumSC coleta informações que você nos fornece diretamente, como nome, telefone e e-mail ao preencher formulários de contato ou interesse em imóveis.</p>

            <h2 className="font-serif text-xl font-bold text-[#0A1628] mt-6 mb-3">2. Uso das informações</h2>
            <p>Utilizamos suas informações para:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Responder às suas solicitações e dúvidas</li>
              <li>Enviar informações sobre imóveis de seu interesse</li>
              <li>Melhorar nossos serviços e comunicações</li>
              <li>Cumprir obrigações legais</li>
            </ul>

            <h2 className="font-serif text-xl font-bold text-[#0A1628] mt-6 mb-3">3. Compartilhamento</h2>
            <p>Não vendemos, alugamos ou compartilhamos suas informações pessoais com terceiros, exceto quando necessário para a prestação dos serviços contratados ou por exigência legal.</p>

            <h2 className="font-serif text-xl font-bold text-[#0A1628] mt-6 mb-3">4. Segurança</h2>
            <p>Adotamos medidas técnicas e organizacionais para proteger suas informações contra acesso não autorizado, perda ou divulgação indevida.</p>

            <h2 className="font-serif text-xl font-bold text-[#0A1628] mt-6 mb-3">5. Seus direitos (LGPD)</h2>
            <p>Conforme a Lei Geral de Proteção de Dados (LGPD), você tem direito a:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Confirmar a existência de tratamento de seus dados</li>
              <li>Acessar seus dados pessoais</li>
              <li>Corrigir dados incompletos ou desatualizados</li>
              <li>Solicitar a exclusão de seus dados</li>
              <li>Revogar o consentimento</li>
            </ul>

            <h2 className="font-serif text-xl font-bold text-[#0A1628] mt-6 mb-3">6. Contato</h2>
            <p>Para exercer seus direitos ou esclarecer dúvidas, entre em contato: <a href="mailto:privacidade@premiumsc.com.br" className="text-[#C9A84C] underline">privacidade@premiumsc.com.br</a></p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
