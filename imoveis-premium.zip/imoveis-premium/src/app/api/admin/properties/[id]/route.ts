import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { slugify } from '@/lib/utils'

interface Params { params: Promise<{ id: string }> }

export async function PUT(req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()

  try {
    const formData = await req.formData()
    const title = formData.get('title') as string

    const updates: Record<string, any> = {
      title,
      description: formData.get('description') || null,
      type: formData.get('type'),
      purpose: formData.get('purpose'),
      status: formData.get('status'),
      price: Number(formData.get('price')),
      condo_fee: formData.get('condo_fee') ? Number(formData.get('condo_fee')) : null,
      iptu: formData.get('iptu') ? Number(formData.get('iptu')) : null,
      city_id: formData.get('city_id') || null,
      neighborhood_id: formData.get('neighborhood_id') || null,
      address: formData.get('address') || null,
      address_number: formData.get('address_number') || null,
      zip_code: formData.get('zip_code') || null,
      latitude: formData.get('latitude') ? Number(formData.get('latitude')) : null,
      longitude: formData.get('longitude') ? Number(formData.get('longitude')) : null,
      bedrooms: Number(formData.get('bedrooms') || 0),
      suites: Number(formData.get('suites') || 0),
      bathrooms: Number(formData.get('bathrooms') || 0),
      parking_spots: Number(formData.get('parking_spots') || 0),
      private_area: formData.get('private_area') ? Number(formData.get('private_area')) : null,
      total_area: formData.get('total_area') ? Number(formData.get('total_area')) : null,
      floor: formData.get('floor') ? Number(formData.get('floor')) : null,
      year_built: formData.get('year_built') ? Number(formData.get('year_built')) : null,
      furnished: formData.get('furnished') === 'true',
      pet_friendly: formData.get('pet_friendly') === 'true',
      gated_community: formData.get('gated_community') === 'true',
      featured: formData.get('featured') === 'true',
      launch: formData.get('launch') === 'true',
      video_url: formData.get('video_url') || null,
      virtual_tour_url: formData.get('virtual_tour_url') || null,
      seo_title: formData.get('seo_title') || null,
      seo_description: formData.get('seo_description') || null,
    }

    const { error } = await supabase.from('properties').update(updates).eq('id', id)
    if (error) throw error

    // Update amenities
    await supabase.from('property_amenities').delete().eq('property_id', id)
    const amenities = formData.getAll('amenities') as string[]
    if (amenities.length > 0) {
      await supabase.from('property_amenities').insert(
        amenities.map(aid => ({ property_id: id, amenity_id: aid }))
      )
    }

    // Upload new images
    const images = formData.getAll('images') as File[]
    for (let i = 0; i < images.length; i++) {
      const image = images[i]
      if (!image || image.size === 0) continue

      const ext = image.name.split('.').pop()
      const path = `properties/${id}/${Date.now()}-${i}.${ext}`

      const { data: uploaded, error: uploadError } = await supabase.storage
        .from('property-images')
        .upload(path, image, { upsert: true })

      if (!uploadError && uploaded) {
        const { data: { publicUrl } } = supabase.storage
          .from('property-images')
          .getPublicUrl(uploaded.path)

        const existingCount = (await supabase
          .from('property_images')
          .select('id', { count: 'exact' })
          .eq('property_id', id)).count || 0

        await supabase.from('property_images').insert({
          property_id: id,
          url: publicUrl,
          position: existingCount + i,
          is_cover: existingCount === 0 && i === 0,
        })
      }
    }

    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()

  try {
    const { error } = await supabase.from('properties').delete().eq('id', id)
    if (error) throw error
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
