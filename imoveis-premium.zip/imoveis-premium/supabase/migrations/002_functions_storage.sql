-- Increment views RPC
create or replace function increment_views(property_id uuid)
returns void as $$
begin
  update properties
  set views_count = views_count + 1
  where id = property_id;
end;
$$ language plpgsql security definer;

-- Storage policies for property-images bucket
-- Run these in Supabase Dashboard > Storage after creating buckets

-- Bucket: property-images (public)
insert into storage.buckets (id, name, public)
values ('property-images', 'property-images', true)
on conflict (id) do nothing;

-- Bucket: agent-photos (public)
insert into storage.buckets (id, name, public)
values ('agent-photos', 'agent-photos', true)
on conflict (id) do nothing;

-- Bucket: blog-images (public)
insert into storage.buckets (id, name, public)
values ('blog-images', 'blog-images', true)
on conflict (id) do nothing;

-- Storage policies: allow public read
create policy "Public read property images"
on storage.objects for select
using (bucket_id = 'property-images');

create policy "Public read agent photos"
on storage.objects for select
using (bucket_id = 'agent-photos');

create policy "Public read blog images"
on storage.objects for select
using (bucket_id = 'blog-images');

-- Auth users (service role) can upload
create policy "Service role upload property images"
on storage.objects for insert
with check (bucket_id = 'property-images');

create policy "Service role upload agent photos"
on storage.objects for insert
with check (bucket_id = 'agent-photos');

create policy "Service role upload blog images"
on storage.objects for insert
with check (bucket_id = 'blog-images');

-- Property status update logs (optional audit)
create table if not exists property_status_logs (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid references properties(id) on delete cascade,
  old_status text,
  new_status text,
  changed_by uuid references auth.users(id),
  changed_at timestamptz default now()
);

-- Trigger to log status changes
create or replace function log_property_status_change()
returns trigger as $$
begin
  if old.status <> new.status then
    insert into property_status_logs(property_id, old_status, new_status)
    values (new.id, old.status, new.status);
  end if;
  return new;
end;
$$ language plpgsql;

create trigger property_status_change
after update on properties
for each row execute function log_property_status_change();

-- Full-text search index
alter table properties add column if not exists search_vector tsvector
  generated always as (
    to_tsvector('portuguese',
      coalesce(title, '') || ' ' ||
      coalesce(description, '') || ' ' ||
      coalesce(address, '') || ' ' ||
      coalesce(type, '')
    )
  ) stored;

create index if not exists idx_properties_search on properties using gin(search_vector);
