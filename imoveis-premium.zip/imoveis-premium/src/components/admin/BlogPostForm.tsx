'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { slugify } from '@/lib/utils'

interface Agent { id: string; name: string }
interface Post {
  id?: string; title?: string; slug?: string; excerpt?: string
  content?: string; cover_image?: string; author_id?: string
  published?: boolean; seo_title?: string; seo_description?: string
}

interface Props { agents: Agent[]; post?: Post }

export default function BlogPostForm({ agents, post }: Props) {
  const router = useRouter()
  const fileRef = useRef<HTMLInputElement>(null)
  const [form, setForm] = useState({
    title: post?.title || '',
    slug: post?.slug || '',
    excerpt: post?.excerpt || '',
    content: post?.content || '',
    author_id: post?.author_id || '',
    published: post?.published || false,
    seo_title: post?.seo_title || '',
    seo_description: post?.seo_description || '',
  })
  const [cover, setCover] = useState<File | null>(null)
  const [coverPreview, setCoverPreview] = useState(post?.cover_image || '')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  function handleTitle(val: string) {
    setForm(f => ({
      ...f,
      title: val,
      slug: post?.slug ? f.slug : slugify(val),
      seo_title: f.seo_title || val,
    }))
  }

  function handleCover(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setCover(file)
    const reader = new FileReader()
    reader.onload = ev => setCoverPreview(ev.target?.result as string)
    reader.readAsDataURL(file)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const fd = new FormData()
      Object.entries(form).forEach(([k, v]) => fd.append(k, String(v)))
      if (cover) fd.append('cover', cover)

      const url = post?.id ? `/api/admin/blog/${post.id}` : '/api/admin/blog'
      const method = post?.id ? 'PUT' : 'POST'
      const res = await fetch(url, { method, body: fd })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Erro ao salvar')
      }
      router.push('/admin/blog')
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const inputCls = "w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"

  return (
    <form onSubmit={handleSubmit}>
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 text-sm mb-5">{error}</div>
      )}

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-5">
          <div className="bg-white border border-neutral-200 p-6">
            <h3 className="font-serif font-bold text-[#0A1628] mb-4 pb-3 border-b border-neutral-100">Conteúdo</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Título *</label>
                <input
                  required
                  value={form.title}
                  onChange={e => handleTitle(e.target.value)}
                  className={inputCls}
                  placeholder="Título do artigo"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Slug (URL)</label>
                <input
                  value={form.slug}
                  onChange={e => setForm(f => ({ ...f, slug: e.target.value }))}
                  className={inputCls}
                  placeholder="titulo-do-artigo"
                />
                <p className="text-xs text-neutral-400 mt-1">/blog/{form.slug || 'slug-do-artigo'}</p>
              </div>
              <div>
                <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Resumo</label>
                <textarea
                  rows={2}
                  value={form.excerpt}
                  onChange={e => setForm(f => ({ ...f, excerpt: e.target.value }))}
                  className={`${inputCls} resize-none`}
                  placeholder="Breve descrição do artigo..."
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Conteúdo (HTML)</label>
                <textarea
                  rows={16}
                  value={form.content}
                  onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
                  className={`${inputCls} resize-y font-mono text-xs`}
                  placeholder="<p>Conteúdo do artigo em HTML...</p>"
                />
                <p className="text-xs text-neutral-400 mt-1">Aceita HTML. Use &lt;h2&gt;, &lt;p&gt;, &lt;ul&gt;, &lt;strong&gt;, etc.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-5">
          {/* Publish */}
          <div className="bg-white border border-neutral-200 p-5">
            <h3 className="font-serif font-bold text-[#0A1628] mb-4 pb-3 border-b border-neutral-100 text-sm">Publicação</h3>
            <label className="flex items-center gap-2 cursor-pointer mb-4">
              <input
                type="checkbox"
                checked={form.published}
                onChange={e => setForm(f => ({ ...f, published: e.target.checked }))}
                className="w-4 h-4 accent-[#C9A84C]"
              />
              <span className="text-sm text-neutral-700">Publicar artigo</span>
            </label>
            <div>
              <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Autor</label>
              <select
                value={form.author_id}
                onChange={e => setForm(f => ({ ...f, author_id: e.target.value }))}
                className={`${inputCls} bg-white`}
              >
                <option value="">Selecione...</option>
                {agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </div>
          </div>

          {/* Cover image */}
          <div className="bg-white border border-neutral-200 p-5">
            <h3 className="font-serif font-bold text-[#0A1628] mb-4 pb-3 border-b border-neutral-100 text-sm">Imagem de Capa</h3>
            {coverPreview ? (
              <div className="relative mb-3">
                <img src={coverPreview} alt="" className="w-full h-36 object-cover" />
                <button
                  type="button"
                  onClick={() => { setCover(null); setCoverPreview('') }}
                  className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white text-xs flex items-center justify-center hover:bg-red-600"
                >×</button>
              </div>
            ) : (
              <div
                className="border-2 border-dashed border-neutral-300 h-28 flex items-center justify-center cursor-pointer hover:border-[#C9A84C] transition-colors mb-3"
                onClick={() => fileRef.current?.click()}
              >
                <span className="text-neutral-400 text-xs">Clique para adicionar capa</span>
              </div>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleCover} />
            <button type="button" onClick={() => fileRef.current?.click()} className="text-xs text-[#0A1628] hover:text-[#C9A84C] transition-colors font-medium">
              {coverPreview ? 'Trocar imagem' : 'Selecionar imagem'}
            </button>
          </div>

          {/* SEO */}
          <div className="bg-white border border-neutral-200 p-5">
            <h3 className="font-serif font-bold text-[#0A1628] mb-4 pb-3 border-b border-neutral-100 text-sm">SEO</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Título SEO</label>
                <input
                  value={form.seo_title}
                  onChange={e => setForm(f => ({ ...f, seo_title: e.target.value }))}
                  className={inputCls}
                  placeholder="Título para Google"
                />
                <p className="text-xs text-neutral-400 mt-0.5">{form.seo_title.length}/60</p>
              </div>
              <div>
                <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Meta Descrição</label>
                <textarea
                  rows={2}
                  value={form.seo_description}
                  onChange={e => setForm(f => ({ ...f, seo_description: e.target.value }))}
                  className={`${inputCls} resize-none`}
                  placeholder="Descrição para Google"
                />
                <p className="text-xs text-neutral-400 mt-0.5">{form.seo_description.length}/160</p>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button type="button" onClick={() => router.back()} className="text-sm text-neutral-500 hover:text-neutral-800 transition-colors">
              ← Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-[#C9A84C] text-white py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors disabled:opacity-50"
            >
              {loading ? 'Salvando...' : post?.id ? 'Atualizar' : 'Publicar'}
            </button>
          </div>
        </div>
      </div>
    </form>
  )
}
