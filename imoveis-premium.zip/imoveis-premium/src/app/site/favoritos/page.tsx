'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import { useFavorites } from '@/hooks/useFavorites'
import { createClient } from '@/lib/supabase/client'

export default function FavoritosPage() {
  const { favorites, loaded } = useFavorites()
  const [properties, setProperties] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!loaded) return
    if (favorites.length === 0) { setLoading(false); return }

    const supabase = createClient()
    supabase
      .from('properties')
      .select(`
        id, code, title, slug, type, purpose, status, price, condo_fee,
        bedrooms, suites, bathrooms, parking_spots, private_area, featured, launch,
        city:cities(id, name, slug, state),
        neighborhood:neighborhoods(id, name, slug),
        images:property_images(id, url, alt, position, is_cover)
      `)
      .in('id', favorites)
      .then(({ data }) => {
        setProperties(data || [])
        setLoading(false)
      })
  }, [favorites, loaded])

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="bg-[#0A1628] py-12 px-4">
          <div className="max-w-7xl mx-auto">
            <h1 className="font-serif text-3xl font-bold text-white mb-1">Meus Favoritos</h1>
            <p className="text-neutral-400 text-sm">
              {loaded && `${favorites.length} imóvel${favorites.length !== 1 ? 'is' : ''} salvo${favorites.length !== 1 ? 's' : ''}`}
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          {loading ? (
            <div className="text-center py-20 text-neutral-400">Carregando...</div>
          ) : properties.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {properties.map(p => <PropertyCard key={p.id} property={p} />)}
            </div>
          ) : (
            <div className="text-center py-24">
              <div className="text-5xl mb-4">💔</div>
              <h2 className="font-serif text-2xl text-neutral-600 mb-2">Nenhum favorito ainda</h2>
              <p className="text-neutral-400 text-sm mb-6">
                Clique no ícone ❤️ em qualquer imóvel para salvá-lo aqui.
              </p>
              <Link href="/imoveis" className="inline-block bg-[#0A1628] text-white px-8 py-3 text-sm font-medium hover:bg-[#1a2d4a] transition-colors">
                Explorar imóveis
              </Link>
            </div>
          )}
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
