'use client'

import { useState } from 'react'

interface Props {
  propertyId: string
  propertyTitle: string
}

export default function LeadForm({ propertyId, propertyTitle }: Props) {
  const [form, setForm] = useState({ name: '', phone: '', email: '', message: '' })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          property_id: propertyId,
          source: 'site',
          message: form.message || `Interesse no imóvel: ${propertyTitle}`,
        }),
      })

      if (!res.ok) throw new Error('Erro ao enviar')
      setSuccess(true)
    } catch {
      setError('Ocorreu um erro. Tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="border border-green-200 bg-green-50 p-6 text-center">
        <svg className="w-10 h-10 text-green-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h3 className="font-serif text-lg font-bold text-green-800 mb-1">Mensagem enviada!</h3>
        <p className="text-green-700 text-sm">
          Em breve um de nossos corretores entrará em contato.
        </p>
      </div>
    )
  }

  return (
    <div className="border border-neutral-200 p-5">
      <h3 className="font-serif font-bold text-[#0A1628] mb-1">Tenho interesse</h3>
      <p className="text-neutral-500 text-xs mb-4">Deixe seu contato e falaremos com você</p>

      <form onSubmit={handleSubmit} className="space-y-3">
        <input
          type="text"
          required
          value={form.name}
          onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
          placeholder="Seu nome completo"
          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
        />
        <input
          type="tel"
          required
          value={form.phone}
          onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
          placeholder="Telefone / WhatsApp"
          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
        />
        <input
          type="email"
          value={form.email}
          onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
          placeholder="E-mail (opcional)"
          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
        />
        <textarea
          value={form.message}
          onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
          placeholder="Mensagem (opcional)"
          rows={3}
          className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C] resize-none"
        />

        {error && (
          <p className="text-red-500 text-xs">{error}</p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-[#0A1628] hover:bg-[#1a2d4a] disabled:bg-neutral-400 text-white py-3 text-sm font-medium transition-colors"
        >
          {loading ? 'Enviando...' : 'Entrar em contato'}
        </button>

        <p className="text-neutral-400 text-xs text-center">
          Ao enviar, você concorda com nossa{' '}
          <a href="/privacidade" className="underline">política de privacidade</a>
        </p>
      </form>
    </div>
  )
}
