import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import PropertyForm from '@/components/admin/PropertyForm'

export default async function NovoImovelPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const [{ data: cities }, { data: neighborhoods }, { data: amenities }] = await Promise.all([
    supabase.from('cities').select('id, name').order('name'),
    supabase.from('neighborhoods').select('id, name, city_id').order('name'),
    supabase.from('amenities').select('id, name, category').order('name'),
  ])

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Novo Imóvel</h1>
        <p className="text-neutral-500 text-sm mt-0.5">Preencha os dados do imóvel</p>
      </div>
      <PropertyForm
        cities={cities || []}
        allNeighborhoods={neighborhoods || []}
        amenities={amenities || []}
      />
    </div>
  )
}
