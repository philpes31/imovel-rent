import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

interface Params { params: Promise<{ id: string }> }

export async function PUT(req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()
  try {
    const fd = await req.formData()
    const published = fd.get('published') === 'true'

    const updates: any = {
      title: fd.get('title'),
      slug: fd.get('slug'),
      excerpt: fd.get('excerpt') || null,
      content: fd.get('content') || null,
      author_id: fd.get('author_id') || null,
      published,
      seo_title: fd.get('seo_title') || null,
      seo_description: fd.get('seo_description') || null,
    }

    if (published) {
      const { data: existing } = await supabase.from('blog_posts').select('published_at').eq('id', id).single()
      if (!existing?.published_at) updates.published_at = new Date().toISOString()
    }

    const cover = fd.get('cover') as File | null
    if (cover && cover.size > 0) {
      const ext = cover.name.split('.').pop()
      const path = `blog/${id}.${ext}`
      const { data: up } = await supabase.storage.from('blog-images').upload(path, cover, { upsert: true })
      if (up) {
        const { data: { publicUrl } } = supabase.storage.from('blog-images').getPublicUrl(up.path)
        updates.cover_image = publicUrl
      }
    }

    const { error } = await supabase.from('blog_posts').update(updates).eq('id', id)
    if (error) throw error
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()
  try {
    const { error } = await supabase.from('blog_posts').delete().eq('id', id)
    if (error) throw error
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
