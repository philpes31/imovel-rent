'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { PROPERTY_TYPES } from '@/lib/utils'

interface City {
  id: string
  name: string
  slug: string
}

interface HeroProps {
  cities: City[]
}

export default function HeroSearch({ cities }: HeroProps) {
  const router = useRouter()
  const [form, setForm] = useState({
    purpose: 'venda',
    type: '',
    city_id: '',
    min_price: '',
    max_price: '',
    bedrooms: '',
  })

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const params = new URLSearchParams()
    Object.entries(form).forEach(([key, val]) => {
      if (val) params.set(key, val)
    })
    router.push(`/imoveis?${params.toString()}`)
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0A1628]">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage: 'url(/hero-bg.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A1628]/60 via-[#0A1628]/40 to-[#0A1628]/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 max-w-5xl mx-auto pt-20">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 text-white text-xs px-4 py-2 mb-6">
          <span className="w-1.5 h-1.5 bg-[#C9A84C] rounded-full animate-pulse" />
          Mais de 1.200 imóveis disponíveis em SC
        </div>

        <h1 className="font-serif text-4xl sm:text-5xl lg:text-7xl font-bold text-white mb-4 leading-tight">
          Encontre o imóvel
          <br />
          <span className="text-[#C9A84C]">ideal para você</span>
        </h1>
        <p className="text-white/70 text-lg sm:text-xl mb-10 max-w-xl mx-auto">
          Apartamentos, casas e coberturas de alto padrão em Santa Catarina
        </p>

        {/* Search Form */}
        <div className="bg-white/95 backdrop-blur-sm p-4 sm:p-6 shadow-2xl">
          {/* Purpose tabs */}
          <div className="flex gap-1 mb-4 border-b border-neutral-200 pb-4">
            {[
              { value: 'venda', label: 'Comprar' },
              { value: 'aluguel', label: 'Alugar' },
              { value: 'lancamento', label: 'Lançamentos' },
            ].map(tab => (
              <button
                key={tab.value}
                type="button"
                onClick={() => setForm(f => ({ ...f, purpose: tab.value }))}
                className={`px-5 py-2 text-sm font-medium transition-all ${
                  form.purpose === tab.value
                    ? 'bg-[#0A1628] text-white'
                    : 'text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
              <select
                value={form.type}
                onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
                className="col-span-1 border border-neutral-200 px-3 py-2.5 text-sm text-neutral-700 bg-white focus:outline-none focus:border-[#C9A84C]"
              >
                <option value="">Tipo do imóvel</option>
                {PROPERTY_TYPES.map(t => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>

              <select
                value={form.city_id}
                onChange={e => setForm(f => ({ ...f, city_id: e.target.value }))}
                className="col-span-1 border border-neutral-200 px-3 py-2.5 text-sm text-neutral-700 bg-white focus:outline-none focus:border-[#C9A84C]"
              >
                <option value="">Cidade</option>
                {cities.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>

              <select
                value={form.bedrooms}
                onChange={e => setForm(f => ({ ...f, bedrooms: e.target.value }))}
                className="col-span-1 border border-neutral-200 px-3 py-2.5 text-sm text-neutral-700 bg-white focus:outline-none focus:border-[#C9A84C]"
              >
                <option value="">Quartos</option>
                {[1, 2, 3, 4, 5].map(n => (
                  <option key={n} value={n}>{n}+ quartos</option>
                ))}
              </select>

              <select
                value={form.min_price}
                onChange={e => setForm(f => ({ ...f, min_price: e.target.value }))}
                className="col-span-1 border border-neutral-200 px-3 py-2.5 text-sm text-neutral-700 bg-white focus:outline-none focus:border-[#C9A84C]"
              >
                <option value="">Preço mín.</option>
                {[200000, 500000, 1000000, 2000000, 5000000].map(p => (
                  <option key={p} value={p}>
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(p)}
                  </option>
                ))}
              </select>

              <select
                value={form.max_price}
                onChange={e => setForm(f => ({ ...f, max_price: e.target.value }))}
                className="col-span-1 border border-neutral-200 px-3 py-2.5 text-sm text-neutral-700 bg-white focus:outline-none focus:border-[#C9A84C]"
              >
                <option value="">Preço máx.</option>
                {[500000, 1000000, 2000000, 5000000, 10000000].map(p => (
                  <option key={p} value={p}>
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(p)}
                  </option>
                ))}
              </select>

              <button
                type="submit"
                className="col-span-2 sm:col-span-1 bg-[#C9A84C] hover:bg-[#b8963e] text-white font-medium py-2.5 text-sm transition-colors flex items-center justify-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Buscar imóveis
              </button>
            </div>
          </form>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap items-center justify-center gap-8 mt-8">
          {[
            ['1.200+', 'Imóveis'],
            ['15 anos', 'de Mercado'],
            ['3.500+', 'Clientes'],
            ['98%', 'Satisfação'],
          ].map(([num, label]) => (
            <div key={label} className="text-center">
              <div className="font-serif text-2xl font-bold text-[#C9A84C]">{num}</div>
              <div className="text-white/60 text-xs mt-0.5">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50">
        <span className="text-xs tracking-widest uppercase">Explorar</span>
        <div className="w-px h-8 bg-white/20 animate-pulse" />
      </div>
    </section>
  )
}
