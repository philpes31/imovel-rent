import Link from 'next/link'

const WHATSAPP = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '5547999999999'

export default function Footer() {
  return (
    <footer className="bg-[#0A1628] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">

          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-[#C9A84C] flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="white" className="w-5 h-5">
                  <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z"/>
                </svg>
              </div>
              <span className="font-serif font-bold text-xl">Premium<span className="text-[#C9A84C]">SC</span></span>
            </div>
            <p className="text-neutral-400 text-sm leading-relaxed mb-6">
              Especialistas em imóveis de alto padrão em Santa Catarina. Conectamos pessoas aos melhores imóveis desde 2010.
            </p>
            <p className="text-neutral-500 text-xs">CRECI-SC 12.345-J</p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif text-sm uppercase tracking-widest text-[#C9A84C] mb-4">Navegação</h4>
            <ul className="space-y-2">
              {[
                ['Comprar', '/comprar'],
                ['Alugar', '/alugar'],
                ['Lançamentos', '/lancamentos'],
                ['Imóveis', '/imoveis'],
                ['Sobre nós', '/sobre'],
                ['Blog', '/blog'],
                ['Contato', '/contato'],
                ['Anunciar imóvel', '/anunciar'],
              ].map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-neutral-400 hover:text-[#C9A84C] text-sm transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Cities */}
          <div>
            <h4 className="font-serif text-sm uppercase tracking-widest text-[#C9A84C] mb-4">Cidades</h4>
            <ul className="space-y-2">
              {[
                ['Balneário Camboriú', '/cidade/balneario-camboriu'],
                ['Itapema', '/cidade/itapema'],
                ['Blumenau', '/cidade/blumenau'],
                ['Itajaí', '/cidade/itajai'],
                ['Florianópolis', '/cidade/florianopolis'],
              ].map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-neutral-400 hover:text-[#C9A84C] text-sm transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif text-sm uppercase tracking-widest text-[#C9A84C] mb-4">Contato</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm text-neutral-400">
                <svg className="w-4 h-4 mt-0.5 text-[#C9A84C] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                Av. Atlântica, 1000 - Centro<br />Balneário Camboriú, SC
              </li>
              <li>
                <a href="tel:+554733333333" className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white transition-colors">
                  <svg className="w-4 h-4 text-[#C9A84C]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  (47) 3333-3333
                </a>
              </li>
              <li>
                <a href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-neutral-400 hover:text-green-400 transition-colors">
                  <svg className="w-4 h-4 text-green-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488"/>
                  </svg>
                  (47) 99999-9999
                </a>
              </li>
              <li>
                <a href="mailto:contato@premiumsc.com.br" className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white transition-colors">
                  <svg className="w-4 h-4 text-[#C9A84C]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  contato@premiumsc.com.br
                </a>
              </li>
            </ul>

            {/* Social */}
            <div className="flex gap-3 mt-6">
              {['instagram', 'facebook', 'linkedin', 'youtube'].map(social => (
                <a
                  key={social}
                  href={`https://${social}.com`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 border border-neutral-700 flex items-center justify-center text-neutral-500 hover:border-[#C9A84C] hover:text-[#C9A84C] transition-all"
                  aria-label={social}
                >
                  <span className="text-xs capitalize">{social[0].toUpperCase()}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-neutral-800 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-neutral-600 text-xs">
            © {new Date().getFullYear()} PremiumSC Imóveis. Todos os direitos reservados.
          </p>
          <div className="flex gap-6">
            <Link href="/privacidade" className="text-neutral-600 hover:text-neutral-400 text-xs transition-colors">
              Política de Privacidade
            </Link>
            <Link href="/termos" className="text-neutral-600 hover:text-neutral-400 text-xs transition-colors">
              Termos de Uso
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
