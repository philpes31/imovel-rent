'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import { formatPrice, getPropertyCover } from '@/lib/utils'
import Link from 'next/link'
import Image from 'next/image'

interface MapProperty {
  id: string
  title: string
  slug: string
  price: number
  purpose: string
  type: string
  bedrooms: number
  private_area?: number
  latitude: number
  longitude: number
  images?: Array<{ url: string; is_cover: boolean }>
  city?: { name: string }
  neighborhood?: { name: string }
}

export default function MapaPage() {
  const mapRef = useRef<HTMLDivElement>(null)
  const [properties, setProperties] = useState<MapProperty[]>([])
  const [selected, setSelected] = useState<MapProperty | null>(null)
  const [loading, setLoading] = useState(true)
  const [purpose, setPurpose] = useState<string>('all')

  const loadProperties = useCallback(async () => {
    setLoading(true)
    const params = purpose !== 'all' ? `?purpose=${purpose}` : ''
    const res = await fetch(`/api/properties/map${params}`)
    if (res.ok) {
      const data = await res.json()
      setProperties(data)
    }
    setLoading(false)
  }, [purpose])

  useEffect(() => { loadProperties() }, [loadProperties])

  // Initialize Google Maps
  useEffect(() => {
    if (!mapRef.current || !properties.length) return
    if (typeof window === 'undefined' || !(window as any).google) {
      // Load Google Maps script
      const key = process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY
      if (!key) return
      const script = document.createElement('script')
      script.src = `https://maps.googleapis.com/maps/api/js?key=${key}&callback=initMap`
      script.async = true
        ; (window as any).initMap = initializeMap
      document.head.appendChild(script)
    } else {
      initializeMap()
    }
  }, [properties])

  function initializeMap() {
    if (!mapRef.current || !properties.length) return
    const google = (window as any).google

    const center = { lat: -27.0, lng: -48.6 }
    const map = new google.maps.Map(mapRef.current, {
      zoom: 10,
      center,
      mapTypeControl: false,
      fullscreenControl: false,
      streetViewControl: false,
      styles: [
        { featureType: 'all', elementType: 'labels.text.fill', stylers: [{ color: '#374151' }] },
        { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#dbeafe' }] },
      ],
    })

    properties.forEach(p => {
      if (!p.latitude || !p.longitude) return

      const label = new google.maps.Marker({
        position: { lat: p.latitude, lng: p.longitude },
        map,
        label: {
          text: formatPrice(p.price),
          color: 'white',
          fontSize: '11px',
          fontWeight: '600',
        },
        icon: {
          path: 'M -30 -10 L 30 -10 L 30 10 L 0 18 L -30 10 Z',
          fillColor: p.purpose === 'aluguel' ? '#7c3aed' : '#0A1628',
          fillOpacity: 1,
          strokeColor: '#C9A84C',
          strokeWeight: 1.5,
          scale: 1,
          labelOrigin: new google.maps.Point(0, 0),
        },
      })

      label.addListener('click', () => setSelected(p))
    })
  }

  return (
    <>
      <Header />
      <main className="pt-16 h-screen flex flex-col">
        {/* Filter bar */}
        <div className="bg-white border-b border-neutral-200 px-4 py-3 flex items-center gap-3 z-10 flex-shrink-0">
          <span className="text-sm font-medium text-[#0A1628]">Busca por mapa</span>
          <div className="flex gap-1">
            {[
              { value: 'all', label: 'Todos' },
              { value: 'venda', label: 'Venda' },
              { value: 'aluguel', label: 'Aluguel' },
              { value: 'lancamento', label: 'Lançamentos' },
            ].map(o => (
              <button
                key={o.value}
                onClick={() => setPurpose(o.value)}
                className={`px-3 py-1.5 text-xs font-medium transition-colors ${
                  purpose === o.value ? 'bg-[#0A1628] text-white' : 'border border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
                }`}
              >
                {o.label}
              </button>
            ))}
          </div>
          <span className="text-xs text-neutral-400 ml-auto">
            {loading ? 'Carregando...' : `${properties.length} imóveis no mapa`}
          </span>
        </div>

        {/* Map + panel */}
        <div className="flex-1 flex overflow-hidden">
          {/* Map */}
          <div ref={mapRef} className="flex-1 relative">
            {loading && (
              <div className="absolute inset-0 bg-neutral-100 flex items-center justify-center z-10">
                <div className="text-neutral-400 text-sm">Carregando mapa...</div>
              </div>
            )}
            {!process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY && (
              <div className="absolute inset-0 bg-neutral-200 flex flex-col items-center justify-center gap-3">
                <div className="text-4xl">🗺️</div>
                <p className="text-neutral-600 font-medium">Configure NEXT_PUBLIC_GOOGLE_MAPS_KEY</p>
                <p className="text-neutral-400 text-sm">para ativar o mapa interativo</p>
              </div>
            )}
          </div>

          {/* Property panel */}
          {selected && (
            <div className="w-80 bg-white border-l border-neutral-200 overflow-y-auto flex-shrink-0">
              <div className="relative">
                <button
                  onClick={() => setSelected(null)}
                  className="absolute top-2 right-2 z-10 w-7 h-7 bg-white/90 flex items-center justify-center text-neutral-600 hover:text-red-500 transition-colors"
                >
                  ×
                </button>
                <div className="h-44 relative">
                  <Image
                    src={getPropertyCover(selected as any)}
                    alt={selected.title}
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
              <div className="p-4">
                <p className="font-serif text-xl font-bold text-[#C9A84C] mb-1">
                  {formatPrice(selected.price, selected.purpose)}
                </p>
                <h3 className="font-medium text-[#0A1628] text-sm mb-1 leading-snug">{selected.title}</h3>
                <p className="text-neutral-400 text-xs mb-3">
                  📍 {selected.neighborhood?.name && `${selected.neighborhood.name}, `}{selected.city?.name}
                </p>
                <div className="flex gap-3 text-xs text-neutral-600 mb-4">
                  {selected.bedrooms > 0 && <span>🛏 {selected.bedrooms}</span>}
                  {selected.private_area && <span>📐 {selected.private_area}m²</span>}
                  <span className="capitalize">{selected.type}</span>
                </div>
                <Link
                  href={`/imovel/${selected.slug}`}
                  className="block text-center bg-[#0A1628] text-white py-2.5 text-sm font-medium hover:bg-[#1a2d4a] transition-colors"
                >
                  Ver imóvel completo
                </Link>
              </div>
            </div>
          )}
        </div>
      </main>
    </>
  )
}
