import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function GET() {
  const supabase = await createAdminClient()

  const { data: leads } = await supabase
    .from('leads')
    .select(`
      id, name, email, phone, message, source, status, created_at,
      property:properties(title, code)
    `)
    .order('created_at', { ascending: false })

  const headers = ['ID', 'Nome', 'Email', 'Telefone', 'Mensagem', 'Origem', 'Status', 'Imóvel', 'Código', 'Data']
  const rows = (leads || []).map((l: any) => [
    l.id,
    l.name,
    l.email || '',
    l.phone,
    l.message || '',
    l.source,
    l.status,
    l.property?.title || '',
    l.property?.code || '',
    new Date(l.created_at).toLocaleDateString('pt-BR'),
  ])

  const csv = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n')

  return new NextResponse(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="leads-${new Date().toISOString().split('T')[0]}.csv"`,
    },
  })
}
