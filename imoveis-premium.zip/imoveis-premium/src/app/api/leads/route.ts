import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { rateLimit, getClientIp } from '@/lib/rate-limit'

function sanitize(str: string): string {
  return str.trim().replace(/<[^>]*>/g, '').slice(0, 1000)
}

export async function POST(req: NextRequest) {
  // Rate limit: 5 leads per IP per 10 min
  const ip = getClientIp(req.headers)
  const { allowed } = rateLimit(`lead:${ip}`, { limit: 5, windowSec: 600 })

  if (!allowed) {
    return NextResponse.json(
      { error: 'Muitas requisições. Tente novamente em alguns minutos.' },
      { status: 429 }
    )
  }

  try {
    const body = await req.json()
    const { name, phone, email, message, property_id, source } = body

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return NextResponse.json({ error: 'Nome inválido' }, { status: 400 })
    }
    if (!phone || typeof phone !== 'string') {
      return NextResponse.json({ error: 'Telefone obrigatório' }, { status: 400 })
    }
    const cleanPhone = phone.replace(/\D/g, '')
    if (cleanPhone.length < 10 || cleanPhone.length > 13) {
      return NextResponse.json({ error: 'Telefone inválido' }, { status: 400 })
    }

    const supabase = await createClient()
    const { data, error } = await supabase
      .from('leads')
      .insert({
        name: sanitize(name),
        phone: cleanPhone,
        email: email ? sanitize(email).toLowerCase() : null,
        message: message ? sanitize(message) : null,
        property_id: property_id || null,
        source: source || 'site',
        status: 'novo',
      })
      .select('id')
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, id: data.id })
  } catch (err: any) {
    console.error('Lead creation error:', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
