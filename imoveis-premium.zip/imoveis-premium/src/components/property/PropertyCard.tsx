import Link from 'next/link'
import Image from 'next/image'
import { Property } from '@/types'
import { formatPrice, formatArea, getPropertyCover, generatePropertyWhatsApp } from '@/lib/utils'
import FavoriteButton from './FavoriteButton'

interface PropertyCardProps {
  property: Property
  featured?: boolean
}

export default function PropertyCard({ property, featured = false }: PropertyCardProps) {
  const cover = getPropertyCover(property)
  const whatsapp = generatePropertyWhatsApp(property, property.agent?.whatsapp)

  const purposeLabel = property.purpose === 'venda' ? 'Venda' : property.purpose === 'aluguel' ? 'Aluguel' : 'Lançamento'
  const purposeColor = property.purpose === 'lancamento' ? 'bg-[#C9A84C]' : property.purpose === 'aluguel' ? 'bg-blue-600' : 'bg-[#0A1628]'

  return (
    <div className={`property-card group border border-neutral-100 ${featured ? 'shadow-md' : ''}`}>
      {/* Image */}
      <div className="property-img-wrapper relative aspect-[4/3]">
        <Image
          src={cover}
          alt={property.title}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          loading="lazy"
        />
        {/* Badges */}
        <div className="absolute top-3 left-3 flex gap-2">
          <span className={`${purposeColor} text-white text-xs font-medium px-2.5 py-1`}>
            {purposeLabel}
          </span>
          {property.launch && (
            <span className="bg-[#C9A84C] text-white text-xs font-medium px-2.5 py-1">
              Lançamento
            </span>
          )}
        </div>
        <div className="absolute top-3 right-3 flex flex-col gap-1">
          {property.featured && (
            <span className="bg-white/90 text-[#0A1628] text-xs font-medium px-2.5 py-1">
              ★ Destaque
            </span>
          )}
          <FavoriteButton propertyId={property.id} />
        </div>
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-[#0A1628]/0 group-hover:bg-[#0A1628]/10 transition-all duration-300" />
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Price */}
        <div className="flex items-center justify-between mb-2">
          <span className="font-serif text-xl font-bold text-[#0A1628]">
            {formatPrice(property.price, property.purpose)}
          </span>
          {property.condo_fee && (
            <span className="text-xs text-neutral-500">
              + {formatPrice(property.condo_fee)} cond.
            </span>
          )}
        </div>

        {/* Title */}
        <h3 className="font-medium text-neutral-800 text-sm leading-snug mb-2 line-clamp-2">
          {property.title}
        </h3>

        {/* Location */}
        <p className="text-xs text-neutral-500 flex items-center gap-1 mb-4">
          <svg className="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
          </svg>
          {property.neighborhood?.name && `${property.neighborhood.name}, `}{property.city?.name}
        </p>

        {/* Specs */}
        <div className="flex items-center gap-4 py-3 border-t border-neutral-100 mb-4">
          {property.bedrooms > 0 && (
            <div className="flex items-center gap-1 text-xs text-neutral-600">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
              {property.bedrooms} {property.bedrooms === 1 ? 'quarto' : 'quartos'}
            </div>
          )}
          {property.bathrooms > 0 && (
            <div className="flex items-center gap-1 text-xs text-neutral-600">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" />
              </svg>
              {property.bathrooms}
            </div>
          )}
          {property.parking_spots > 0 && (
            <div className="flex items-center gap-1 text-xs text-neutral-600">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h11a2 2 0 012 2v3m2 4h2a2 2 0 012 2v3a2 2 0 01-2 2h-1m-5-3v.5M15 17v.5M9 9h6m-3-3v6" />
              </svg>
              {property.parking_spots}
            </div>
          )}
          {property.private_area && (
            <div className="flex items-center gap-1 text-xs text-neutral-600">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
              </svg>
              {formatArea(property.private_area)}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Link
            href={`/imovel/${property.slug}`}
            className="flex-1 text-center text-xs font-medium text-white bg-[#0A1628] hover:bg-[#1a2d4a] py-2.5 transition-colors"
          >
            Ver imóvel
          </Link>
          <a
            href={whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center w-10 bg-green-500 hover:bg-green-600 transition-colors"
            aria-label="Contato via WhatsApp"
          >
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488"/>
            </svg>
          </a>
        </div>
      </div>
    </div>
  )
}
