'use client'

import { useState } from 'react'
import Image from 'next/image'
import { PropertyImage } from '@/types'

interface Props {
  images: PropertyImage[]
  title: string
}

export default function ImageGallery({ images, title }: Props) {
  const [current, setCurrent] = useState(0)
  const [fullscreen, setFullscreen] = useState(false)

  if (!images.length) {
    return (
      <div className="w-full h-80 bg-neutral-200 flex items-center justify-center">
        <svg className="w-16 h-16 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      </div>
    )
  }

  return (
    <>
      <div className="relative bg-neutral-900">
        {/* Main image */}
        <div className="relative aspect-[16/9] sm:aspect-[21/9] max-h-[70vh]">
          <Image
            src={images[current].url}
            alt={images[current].alt || title}
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
          {/* Overlay controls */}
          <div className="absolute inset-0 flex items-center justify-between px-4 opacity-0 hover:opacity-100 transition-opacity">
            {images.length > 1 && (
              <>
                <button
                  onClick={() => setCurrent(c => (c - 1 + images.length) % images.length)}
                  className="w-10 h-10 bg-black/60 text-white flex items-center justify-center hover:bg-black/80 transition-colors"
                  aria-label="Anterior"
                >
                  ‹
                </button>
                <button
                  onClick={() => setCurrent(c => (c + 1) % images.length)}
                  className="w-10 h-10 bg-black/60 text-white flex items-center justify-center hover:bg-black/80 transition-colors"
                  aria-label="Próximo"
                >
                  ›
                </button>
              </>
            )}
          </div>

          {/* Counter & fullscreen */}
          <div className="absolute bottom-4 right-4 flex items-center gap-2">
            <span className="bg-black/60 text-white text-xs px-3 py-1">
              {current + 1} / {images.length}
            </span>
            <button
              onClick={() => setFullscreen(true)}
              className="bg-black/60 text-white w-8 h-8 flex items-center justify-center hover:bg-black/80 transition-colors"
              aria-label="Tela cheia"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
              </svg>
            </button>
          </div>
        </div>

        {/* Thumbnails */}
        {images.length > 1 && (
          <div className="flex gap-1 p-2 bg-black/80 overflow-x-auto">
            {images.map((img, i) => (
              <button
                key={img.id}
                onClick={() => setCurrent(i)}
                className={`flex-shrink-0 w-16 h-12 relative overflow-hidden transition-all ${
                  i === current ? 'ring-2 ring-[#C9A84C]' : 'opacity-50 hover:opacity-100'
                }`}
              >
                <Image src={img.url} alt={img.alt || `Foto ${i + 1}`} fill className="object-cover" sizes="64px" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Fullscreen modal */}
      {fullscreen && (
        <div className="fixed inset-0 z-50 bg-black flex items-center justify-center" onClick={() => setFullscreen(false)}>
          <button
            className="absolute top-4 right-4 text-white text-3xl z-10"
            onClick={() => setFullscreen(false)}
          >
            ×
          </button>
          <div className="relative w-full h-full" onClick={e => e.stopPropagation()}>
            <Image
              src={images[current].url}
              alt={images[current].alt || title}
              fill
              className="object-contain"
              sizes="100vw"
            />
          </div>
          {images.length > 1 && (
            <>
              <button
                onClick={e => { e.stopPropagation(); setCurrent(c => (c - 1 + images.length) % images.length) }}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/20 text-white text-2xl flex items-center justify-center hover:bg-white/40 transition-colors"
              >
                ‹
              </button>
              <button
                onClick={e => { e.stopPropagation(); setCurrent(c => (c + 1) % images.length) }}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/20 text-white text-2xl flex items-center justify-center hover:bg-white/40 transition-colors"
              >
                ›
              </button>
            </>
          )}
        </div>
      )}
    </>
  )
}
