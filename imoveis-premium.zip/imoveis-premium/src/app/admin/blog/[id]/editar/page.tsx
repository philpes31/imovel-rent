import { createClient } from '@/lib/supabase/server'
import { redirect, notFound } from 'next/navigation'
import BlogPostForm from '@/components/admin/BlogPostForm'

interface Props { params: Promise<{ id: string }> }

export default async function EditarBlogPostPage({ params }: Props) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const [{ data: post }, { data: agents }] = await Promise.all([
    supabase.from('blog_posts').select('*').eq('id', id).single(),
    supabase.from('agents').select('id, name').eq('active', true).order('name'),
  ])

  if (!post) notFound()

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Editar Artigo</h1>
        <p className="text-neutral-500 text-sm mt-0.5 line-clamp-1">{post.title}</p>
      </div>
      <BlogPostForm agents={agents || []} post={post} />
    </div>
  )
}
