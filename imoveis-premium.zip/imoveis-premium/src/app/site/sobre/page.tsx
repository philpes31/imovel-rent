import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import { createClient } from '@/lib/supabase/server'

export const metadata: Metadata = {
  title: 'Sobre Nós | PremiumSC Imóveis',
  description:
    'Conheça a PremiumSC, especialistas em imóveis de alto padrão em Santa Catarina há mais de 15 anos. Nossa história, missão e equipe.',
}

export default async function SobrePage() {
  const supabase = await createClient()
  const { data: agents } = await supabase
    .from('agents')
    .select('*')
    .eq('active', true)
    .order('name')
    .limit(8)

  const timeline = [
    { year: '2010', title: 'Fundação', desc: 'A PremiumSC nasce em Balneário Camboriú com foco em imóveis de alto padrão.' },
    { year: '2013', title: 'Expansão', desc: 'Abertura da segunda unidade em Itapema, atendendo a crescente demanda regional.' },
    { year: '2016', title: 'Digitalização', desc: 'Lançamento da plataforma digital com mais de 500 imóveis cadastrados.' },
    { year: '2019', title: 'Premiação', desc: 'Reconhecidos como a melhor imobiliária de SC pelo prêmio CRECI Excellence.' },
    { year: '2022', title: 'SC Completo', desc: 'Atuação em 5 cidades: Balneário Camboriú, Itapema, Blumenau, Itajaí e Florianópolis.' },
    { year: '2025', title: 'Hoje', desc: 'Mais de 1.200 imóveis, 50 corretores e 3.500 clientes satisfeitos.' },
  ]

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">

        {/* Hero */}
        <div className="bg-[#0A1628] py-20 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase font-medium mb-3">Nossa história</p>
            <h1 className="font-serif text-4xl sm:text-5xl font-bold text-white mb-4">
              Sobre a PremiumSC
            </h1>
            <div className="w-16 h-0.5 bg-[#C9A84C] mx-auto mb-5" />
            <p className="text-neutral-400 max-w-xl mx-auto leading-relaxed">
              Desde 2010 conectando pessoas aos melhores imóveis de Santa Catarina com
              transparência, expertise e dedicação.
            </p>
          </div>
        </div>

        {/* Mission + Values */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <p className="text-[#C9A84C] text-xs tracking-widest uppercase font-medium mb-3">Missão</p>
                <h2 className="font-serif text-3xl font-bold text-[#0A1628] mb-4 leading-tight">
                  Transformar o sonho da casa própria em realidade
                </h2>
                <div className="w-12 h-0.5 bg-[#C9A84C] mb-6" />
                <p className="text-neutral-600 leading-relaxed mb-6">
                  Nossa missão é oferecer a melhor experiência imobiliária do mercado catarinense,
                  combinando tecnologia de ponta com atendimento personalizado e humano.
                </p>
                <p className="text-neutral-600 leading-relaxed mb-8">
                  Acreditamos que cada família merece encontrar o lar perfeito, e trabalhamos
                  incansavelmente para tornar isso possível — seja na compra, na venda ou no aluguel.
                </p>
                <Link href="/contato" className="btn-primary inline-block">
                  Fale com nossa equipe
                </Link>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: '🏆', title: 'Excelência', desc: 'Comprometidos com o mais alto padrão de qualidade em cada atendimento' },
                  { icon: '🤝', title: 'Confiança', desc: 'Transparência total em todas as etapas da negociação' },
                  { icon: '💡', title: 'Inovação', desc: 'Tecnologia a serviço de uma experiência imobiliária moderna' },
                  { icon: '❤️', title: 'Pessoas', desc: 'O cliente no centro de tudo que fazemos, sempre' },
                ].map(v => (
                  <div key={v.title} className="border border-neutral-200 p-5 hover:border-[#C9A84C] transition-colors">
                    <div className="text-2xl mb-3">{v.icon}</div>
                    <h3 className="font-medium text-[#0A1628] mb-1">{v.title}</h3>
                    <p className="text-neutral-500 text-xs leading-relaxed">{v.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="bg-[#C9A84C] py-14">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                ['15+', 'Anos de experiência'],
                ['1.200+', 'Imóveis disponíveis'],
                ['3.500+', 'Clientes atendidos'],
                ['50+', 'Corretores especializados'],
              ].map(([num, label]) => (
                <div key={label}>
                  <div className="font-serif text-4xl font-bold text-[#0A1628] mb-1">{num}</div>
                  <div className="text-[#0A1628]/70 text-sm">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-20 bg-neutral-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="font-serif text-3xl font-bold text-[#0A1628] mb-2">Nossa Trajetória</h2>
              <div className="w-12 h-0.5 bg-[#C9A84C] mx-auto mt-3" />
            </div>
            <div className="relative">
              <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-neutral-200 -translate-x-px" />
              <div className="space-y-8">
                {timeline.map((item, i) => (
                  <div key={item.year} className={`flex gap-6 md:gap-0 ${i % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                    <div className={`flex-1 ${i % 2 === 0 ? 'md:pr-10 md:text-right' : 'md:pl-10'} pl-10 md:pl-0`}>
                      <div className="bg-white border border-neutral-200 p-5 hover:border-[#C9A84C] transition-colors">
                        <div className="font-serif text-[#C9A84C] text-xl font-bold mb-1">{item.year}</div>
                        <h3 className="font-medium text-[#0A1628] mb-1">{item.title}</h3>
                        <p className="text-neutral-500 text-xs leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                    <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-3 h-3 bg-[#C9A84C] rounded-full border-2 border-white" style={{ marginTop: '20px' }} />
                    <div className="hidden md:block flex-1" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Team */}
        {agents && agents.length > 0 && (
          <section className="py-20 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                <h2 className="font-serif text-3xl font-bold text-[#0A1628] mb-2">Nossa Equipe</h2>
                <div className="w-12 h-0.5 bg-[#C9A84C] mx-auto mt-3 mb-4" />
                <p className="text-neutral-500">Corretores especializados prontos para ajudar você</p>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                {agents.map((agent: any) => (
                  <div key={agent.id} className="text-center group">
                    <div className="w-20 h-20 rounded-full bg-neutral-200 overflow-hidden mx-auto mb-3 ring-2 ring-transparent group-hover:ring-[#C9A84C] transition-all">
                      {agent.photo_url ? (
                        <Image src={agent.photo_url} alt={agent.name} width={80} height={80} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center font-serif text-2xl text-neutral-500">
                          {agent.name.charAt(0)}
                        </div>
                      )}
                    </div>
                    <h3 className="font-medium text-[#0A1628] text-sm">{agent.name}</h3>
                    {agent.creci && <p className="text-neutral-400 text-xs mt-0.5">CRECI {agent.creci}</p>}
                    {agent.whatsapp && (
                      <a
                        href={`https://wa.me/55${agent.whatsapp.replace(/\D/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-green-500 text-xs mt-2 inline-block hover:text-green-700 transition-colors"
                      >
                        WhatsApp
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CTA */}
        <section className="bg-[#0A1628] py-16">
          <div className="max-w-2xl mx-auto px-4 text-center">
            <h2 className="font-serif text-3xl font-bold text-white mb-3">Pronto para começar?</h2>
            <p className="text-neutral-400 mb-8">Fale com nossa equipe e encontre o imóvel ideal para você.</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/imoveis" className="bg-[#C9A84C] text-white px-8 py-3 font-medium text-sm hover:bg-[#b8963e] transition-colors">
                Ver imóveis
              </Link>
              <Link href="/contato" className="border border-white/30 text-white px-8 py-3 font-medium text-sm hover:border-white transition-colors">
                Falar com corretor
              </Link>
            </div>
          </div>
        </section>

      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
