import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import { createClient } from '@/lib/supabase/server'
import { getProperties } from '@/lib/queries'

interface Props { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const supabase = await createClient()
  const { data: n } = await supabase
    .from('neighborhoods')
    .select('*, city:cities(name, state)')
    .eq('slug', slug)
    .single()
  if (!n) return { title: 'Bairro não encontrado' }
  return {
    title: `Imóveis no ${n.name} - ${(n.city as any).name} | PremiumSC`,
    description: `Encontre apartamentos, casas e imóveis no bairro ${n.name} em ${(n.city as any).name}, SC.`,
  }
}

export default async function BairroPage({ params }: Props) {
  const { slug } = await params
  const supabase = await createClient()

  const { data: neighborhood } = await supabase
    .from('neighborhoods')
    .select('*, city:cities(id, name, slug, state)')
    .eq('slug', slug)
    .single()

  if (!neighborhood) notFound()

  const { data: properties, total } = await getProperties({
    neighborhood_id: neighborhood.id,
    per_page: 12,
  })

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">
        <div className="bg-[#0A1628] py-14 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-2 text-neutral-500 text-xs mb-4">
              <a href="/" className="hover:text-white transition-colors">Home</a>
              <span>›</span>
              <a href={`/cidade/${(neighborhood.city as any).slug}`} className="hover:text-white transition-colors">
                {(neighborhood.city as any).name}
              </a>
              <span>›</span>
              <span className="text-white">{neighborhood.name}</span>
            </div>
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase font-medium mb-2">Bairro</p>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-white mb-2">
              {neighborhood.name}
            </h1>
            <p className="text-neutral-400 text-sm">{(neighborhood.city as any).name}, SC • {total} imóveis disponíveis</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          {properties.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {properties.map(p => <PropertyCard key={p.id} property={p} />)}
            </div>
          ) : (
            <div className="text-center py-20 text-neutral-400">
              <p className="font-serif text-xl">Nenhum imóvel disponível neste bairro no momento.</p>
            </div>
          )}
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
