import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { getDashboardStats } from '@/lib/queries'
import Link from 'next/link'

export default async function AdminDashboard() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/auth/login')

  const stats = await getDashboardStats()

  const statCards = [
    { label: 'Imóveis Ativos', value: stats.active_properties, color: 'text-blue-600', href: '/admin/imoveis' },
    { label: 'Total de Imóveis', value: stats.total_properties, color: 'text-neutral-700', href: '/admin/imoveis' },
    { label: 'Vendidos/Alugados', value: stats.sold_properties, color: 'text-green-600', href: '/admin/imoveis?status=vendido' },
    { label: 'Novos Leads', value: stats.new_leads, color: 'text-orange-600', href: '/admin/leads' },
    { label: 'Total de Leads', value: stats.total_leads, color: 'text-neutral-700', href: '/admin/leads' },
  ]

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Dashboard</h1>
          <p className="text-neutral-500 text-sm mt-1">Visão geral da plataforma</p>
        </div>
        <Link href="/admin/imoveis/novo" className="bg-[#C9A84C] text-white px-5 py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors">
          + Novo imóvel
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        {statCards.map(card => (
          <Link
            key={card.label}
            href={card.href}
            className="bg-white border border-neutral-200 p-5 hover:border-[#C9A84C] transition-colors"
          >
            <p className={`font-serif text-3xl font-bold ${card.color}`}>{card.value}</p>
            <p className="text-neutral-500 text-xs mt-1">{card.label}</p>
          </Link>
        ))}
      </div>

      {/* Quick links */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Gerenciar Imóveis', desc: 'Criar, editar e publicar', href: '/admin/imoveis', icon: '🏠' },
          { label: 'Ver Leads', desc: 'Novos contatos e interessados', href: '/admin/leads', icon: '📩' },
          { label: 'Corretores', desc: 'Gerenciar equipe', href: '/admin/corretores', icon: '👥' },
          { label: 'Site', desc: 'Visualizar site público', href: '/', icon: '🌐', target: '_blank' },
        ].map(item => (
          <Link
            key={item.label}
            href={item.href}
            target={item.target as any}
            className="bg-white border border-neutral-200 p-5 hover:border-[#0A1628] transition-colors group"
          >
            <div className="text-2xl mb-3">{item.icon}</div>
            <h3 className="font-medium text-[#0A1628] text-sm group-hover:text-[#C9A84C] transition-colors">
              {item.label}
            </h3>
            <p className="text-neutral-400 text-xs mt-1">{item.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
