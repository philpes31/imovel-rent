'use client'

import { useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { useRecentlyViewed, RecentlyViewedItem } from '@/hooks/useRecentlyViewed'
import { formatPrice } from '@/lib/utils'

interface TrackerProps {
  item: Omit<RecentlyViewedItem, 'viewedAt'>
}

/** Drop this on a property page to auto-register the view */
export function RecentlyViewedTracker({ item }: TrackerProps) {
  const { add } = useRecentlyViewed()
  useEffect(() => { add(item) }, []) // eslint-disable-line
  return null
}

/** Display strip of recently viewed properties */
export function RecentlyViewedStrip({ excludeId }: { excludeId?: string }) {
  const { items } = useRecentlyViewed()
  const filtered = items.filter(i => i.id !== excludeId)
  if (filtered.length === 0) return null

  return (
    <section className="py-12 bg-neutral-50 border-t border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-2">Vistos recentemente</h2>
        <div className="w-8 h-0.5 bg-[#C9A84C] mb-6" />
        <div className="flex gap-4 overflow-x-auto pb-2">
          {filtered.map(item => (
            <Link
              key={item.id}
              href={`/site/imovel/${item.slug}`}
              className="flex-shrink-0 w-52 bg-white border border-neutral-200 hover:border-[#C9A84C] transition-colors group"
            >
              <div className="h-32 relative overflow-hidden bg-neutral-200">
                {item.coverImage ? (
                  <Image
                    src={item.coverImage}
                    alt={item.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                    sizes="208px"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-3xl bg-gradient-to-br from-neutral-300 to-neutral-400">🏠</div>
                )}
              </div>
              <div className="p-3">
                <p className="font-medium text-[#0A1628] text-xs leading-snug line-clamp-2 mb-1">
                  {item.title}
                </p>
                <p className="font-serif text-sm font-bold text-[#C9A84C]">
                  {formatPrice(item.price, item.purpose)}
                </p>
                {item.city && (
                  <p className="text-xs text-neutral-400 mt-0.5">📍 {item.city}</p>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
