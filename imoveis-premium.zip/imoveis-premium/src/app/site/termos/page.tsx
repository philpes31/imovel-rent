import type { Metadata } from 'next'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'

export const metadata: Metadata = {
  title: 'Termos de Uso | PremiumSC',
}

export default function TermosPage() {
  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="bg-[#0A1628] py-12 px-4">
          <div className="max-w-3xl mx-auto">
            <h1 className="font-serif text-3xl font-bold text-white">Termos de Uso</h1>
            <div className="w-10 h-0.5 bg-[#C9A84C] mt-3" />
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
          <div className="bg-white border border-neutral-200 p-8 text-sm leading-relaxed text-neutral-700 space-y-6">
            <p className="text-neutral-500">Última atualização: Janeiro de 2025</p>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">1. Aceitação dos Termos</h2>
              <p>Ao acessar e utilizar o site da PremiumSC, você concorda com estes Termos de Uso. Se não concordar com alguma parte, pedimos que não utilize nossos serviços.</p>
            </section>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">2. Uso do Site</h2>
              <p className="mb-2">O site da PremiumSC destina-se à divulgação de imóveis para venda e locação. Você concorda em não:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Usar o site para fins ilícitos ou não autorizados</li>
                <li>Tentar acessar áreas restritas sem autorização</li>
                <li>Enviar informações falsas ou enganosas</li>
                <li>Interferir no funcionamento do site</li>
                <li>Realizar scraping ou coleta automatizada de dados</li>
              </ul>
            </section>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">3. Informações dos Imóveis</h2>
              <p>As informações sobre os imóveis disponibilizadas no site são fornecidas a título informativo. Embora nos esforcemos para manter as informações atualizadas e precisas, não garantimos a completude ou exatidão dos dados. Preços, disponibilidade e características estão sujeitos a alterações sem aviso prévio.</p>
            </section>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">4. Propriedade Intelectual</h2>
              <p>Todo o conteúdo do site, incluindo textos, imagens, logotipos e design, é propriedade da PremiumSC ou de seus licenciantes, protegido por leis de direitos autorais. É proibida a reprodução sem autorização expressa.</p>
            </section>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">5. Limitação de Responsabilidade</h2>
              <p>A PremiumSC não se responsabiliza por danos diretos ou indiretos decorrentes do uso ou impossibilidade de uso do site. Atuamos como intermediários e não somos parte nos contratos de compra, venda ou locação de imóveis.</p>
            </section>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">6. Alterações nos Termos</h2>
              <p>Reservamo-nos o direito de modificar estes termos a qualquer momento. As alterações entram em vigor imediatamente após sua publicação. O uso continuado do site constitui aceitação dos novos termos.</p>
            </section>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">7. Legislação Aplicável</h2>
              <p>Estes termos são regidos pelas leis brasileiras. Fica eleito o foro da Comarca de Balneário Camboriú, SC, para dirimir quaisquer controvérsias.</p>
            </section>

            <section>
              <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-3">8. Contato</h2>
              <p>Para dúvidas sobre estes termos: <a href="mailto:juridico@premiumsc.com.br" className="text-[#C9A84C] underline">juridico@premiumsc.com.br</a></p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
