import { NextRequest, NextResponse } from 'next/server'
import { revalidatePath, revalidateTag } from 'next/cache'
import { createAdminClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const supabase = await createAdminClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { path, tag } = await req.json()

    if (tag) {
      revalidateTag(tag)
    } else if (path) {
      revalidatePath(path)
    } else {
      // Revalidate all main pages
      revalidatePath('/site')
      revalidatePath('/site/imoveis')
      revalidatePath('/site/comprar')
      revalidatePath('/site/alugar')
      revalidatePath('/site/lancamentos')
    }

    return NextResponse.json({ success: true, revalidated: path || tag || 'all' })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
