import { ImageResponse } from 'next/og'
import { NextRequest } from 'next/server'

export const runtime = 'edge'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const title = searchParams.get('title') || 'Imóvel PremiumSC'
  const price = searchParams.get('price') || ''
  const city = searchParams.get('city') || 'Santa Catarina'
  const type = searchParams.get('type') || 'Imóvel'

  return new ImageResponse(
    (
      <div
        style={{
          width: '1200px',
          height: '630px',
          background: '#0A1628',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          padding: '48px',
          position: 'relative',
        }}
      >
        {/* Gold accent */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '6px',
            background: '#C9A84C',
          }}
        />

        {/* Logo area */}
        <div
          style={{
            position: 'absolute',
            top: '32px',
            left: '48px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
          }}
        >
          <div
            style={{
              width: '36px',
              height: '36px',
              background: '#C9A84C',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '18px',
            }}
          >
            🏠
          </div>
          <span style={{ color: 'white', fontSize: '22px', fontWeight: 'bold' }}>
            Premium<span style={{ color: '#C9A84C' }}>SC</span>
          </span>
        </div>

        {/* Content */}
        <div>
          <div
            style={{
              display: 'flex',
              gap: '8px',
              marginBottom: '16px',
            }}
          >
            <span
              style={{
                background: 'rgba(201,168,76,0.2)',
                border: '1px solid #C9A84C',
                color: '#C9A84C',
                padding: '4px 12px',
                fontSize: '14px',
                textTransform: 'uppercase',
                letterSpacing: '2px',
              }}
            >
              {type}
            </span>
          </div>

          <div
            style={{
              color: 'white',
              fontSize: '42px',
              fontWeight: 'bold',
              lineHeight: 1.2,
              marginBottom: '16px',
              maxWidth: '800px',
            }}
          >
            {title}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            {price && (
              <span style={{ color: '#C9A84C', fontSize: '32px', fontWeight: 'bold' }}>
                {price}
              </span>
            )}
            <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '18px' }}>
              📍 {city}, SC
            </span>
          </div>
        </div>
      </div>
    ),
    { width: 1200, height: 630 }
  )
}
