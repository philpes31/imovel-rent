import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { slugify } from '@/lib/utils'

export async function POST(req: NextRequest) {
  const supabase = await createAdminClient()
  try {
    const fd = await req.formData()
    const title = fd.get('title') as string
    const published = fd.get('published') === 'true'

    const data: any = {
      title,
      slug: (fd.get('slug') as string) || slugify(title),
      excerpt: fd.get('excerpt') || null,
      content: fd.get('content') || null,
      author_id: fd.get('author_id') || null,
      published,
      published_at: published ? new Date().toISOString() : null,
      seo_title: fd.get('seo_title') || null,
      seo_description: fd.get('seo_description') || null,
    }

    const cover = fd.get('cover') as File | null
    if (cover && cover.size > 0) {
      const ext = cover.name.split('.').pop()
      const path = `blog/${Date.now()}.${ext}`
      const { data: up } = await supabase.storage.from('blog-images').upload(path, cover, { upsert: true })
      if (up) {
        const { data: { publicUrl } } = supabase.storage.from('blog-images').getPublicUrl(up.path)
        data.cover_image = publicUrl
      }
    }

    const { data: post, error } = await supabase.from('blog_posts').insert(data).select().single()
    if (error) throw error
    return NextResponse.json({ success: true, id: post.id, slug: post.slug })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
