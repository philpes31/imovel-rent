import type { Metadata } from 'next'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import PropertyFilters from '@/components/property/PropertyFilters'
import { getProperties, getCities } from '@/lib/queries'
import { SearchFilters } from '@/types'

export const metadata: Metadata = {
  title: 'Imóveis para Alugar em Santa Catarina | PremiumSC',
  description:
    'Alugue apartamentos, casas e studios de alto padrão em Balneário Camboriú, Itapema, Blumenau e demais cidades de SC.',
}

interface PageProps {
  searchParams: Promise<Record<string, string>>
}

export default async function AlugarPage({ searchParams }: PageProps) {
  const params = await searchParams
  const filters: SearchFilters = {
    purpose: 'aluguel',
    type: params.type as any,
    city_id: params.city_id,
    min_price: params.min_price ? Number(params.min_price) : undefined,
    max_price: params.max_price ? Number(params.max_price) : undefined,
    bedrooms: params.bedrooms ? Number(params.bedrooms) : undefined,
    furnished: params.furnished === 'true' ? true : undefined,
    pet_friendly: params.pet_friendly === 'true' ? true : undefined,
    page: params.page ? Number(params.page) : 1,
    per_page: 12,
    sort: params.sort as any,
  }

  const [{ data: properties, total, total_pages, page }, cities] = await Promise.all([
    getProperties(filters),
    getCities(),
  ])

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="bg-[#0A1628] py-10 px-4">
          <div className="max-w-7xl mx-auto">
            <p className="text-[#C9A84C] text-xs font-medium tracking-widest uppercase mb-2">Aluguel</p>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-white">
              Imóveis para Alugar
            </h1>
            <div className="w-12 h-0.5 bg-[#C9A84C] mt-3" />
            <p className="text-neutral-400 text-sm mt-3">{total} imóveis disponíveis para locação</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            <aside className="w-full lg:w-72 flex-shrink-0">
              <PropertyFilters cities={cities} currentFilters={filters} />
            </aside>
            <div className="flex-1">
              {properties.length > 0 ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                    {properties.map(p => <PropertyCard key={p.id} property={p} />)}
                  </div>
                  {total_pages > 1 && (
                    <div className="flex items-center justify-center gap-2 mt-10">
                      {Array.from({ length: total_pages }, (_, i) => i + 1).map(p => (
                        <a
                          key={p}
                          href={`/alugar?page=${p}`}
                          className={`w-9 h-9 flex items-center justify-center text-sm transition-colors ${
                            p === page ? 'bg-[#0A1628] text-white' : 'border border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
                          }`}
                        >{p}</a>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-20 bg-white border border-neutral-200">
                  <p className="font-serif text-xl text-neutral-500">Nenhum imóvel para alugar no momento</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
