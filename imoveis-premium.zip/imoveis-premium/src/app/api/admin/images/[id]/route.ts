import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

interface Params { params: Promise<{ id: string }> }

export async function DELETE(_req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()

  try {
    // Get image URL to delete from storage
    const { data: image } = await supabase
      .from('property_images')
      .select('url, property_id')
      .eq('id', id)
      .single()

    if (image?.url) {
      // Extract storage path from URL
      const url = new URL(image.url)
      const path = url.pathname.split('/storage/v1/object/public/property-images/')[1]
      if (path) {
        await supabase.storage.from('property-images').remove([path])
      }
    }

    const { error } = await supabase.from('property_images').delete().eq('id', id)
    if (error) throw error

    // If this was the cover, promote next image
    if (image?.property_id) {
      const { data: remaining } = await supabase
        .from('property_images')
        .select('id')
        .eq('property_id', image.property_id)
        .order('position')
        .limit(1)
      if (remaining?.[0]) {
        await supabase.from('property_images').update({ is_cover: true }).eq('id', remaining[0].id)
      }
    }

    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()

  try {
    const { property_id, position } = await req.json()

    // Set as cover: unset all others first
    await supabase.from('property_images').update({ is_cover: false }).eq('property_id', property_id)
    await supabase.from('property_images').update({ is_cover: true }).eq('id', id)

    if (position !== undefined) {
      await supabase.from('property_images').update({ position }).eq('id', id)
    }

    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
