'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { PROPERTY_TYPES } from '@/lib/utils'

interface City { id: string; name: string }
interface Neighborhood { id: string; name: string; city_id: string }
interface Amenity { id: string; name: string }

interface Props {
  cities: City[]
  allNeighborhoods: Neighborhood[]
  amenities: Amenity[]
  property?: any
}

export default function PropertyForm({ cities, allNeighborhoods, amenities, property }: Props) {
  const router = useRouter()
  const isEdit = !!property

  const [form, setForm] = useState({
    title: property?.title || '',
    description: property?.description || '',
    type: property?.type || 'apartamento',
    purpose: property?.purpose || 'venda',
    status: property?.status || 'rascunho',
    price: property?.price || '',
    condo_fee: property?.condo_fee || '',
    iptu: property?.iptu || '',
    city_id: property?.city_id || '',
    neighborhood_id: property?.neighborhood_id || '',
    address: property?.address || '',
    address_number: property?.address_number || '',
    zip_code: property?.zip_code || '',
    latitude: property?.latitude || '',
    longitude: property?.longitude || '',
    bedrooms: property?.bedrooms || 0,
    suites: property?.suites || 0,
    bathrooms: property?.bathrooms || 0,
    parking_spots: property?.parking_spots || 0,
    private_area: property?.private_area || '',
    total_area: property?.total_area || '',
    floor: property?.floor || '',
    total_floors: property?.total_floors || '',
    year_built: property?.year_built || '',
    furnished: property?.furnished || false,
    pet_friendly: property?.pet_friendly || false,
    gated_community: property?.gated_community || false,
    featured: property?.featured || false,
    launch: property?.launch || false,
    video_url: property?.video_url || '',
    virtual_tour_url: property?.virtual_tour_url || '',
    seo_title: property?.seo_title || '',
    seo_description: property?.seo_description || '',
  })

  const [selectedAmenities, setSelectedAmenities] = useState<string[]>(
    property?.amenities?.map((a: any) => a.amenity?.id || a.id) || []
  )
  const [images, setImages] = useState<File[]>([])
  const [imagePreviews, setImagePreviews] = useState<string[]>(
    property?.images?.map((i: any) => i.url) || []
  )
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)

  const filteredNeighborhoods = allNeighborhoods.filter(n => n.city_id === form.city_id)

  function set(key: string, value: any) {
    setForm(f => ({ ...f, [key]: value }))
  }

  function handleFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || [])
    setImages(prev => [...prev, ...files])
    files.forEach(f => {
      const reader = new FileReader()
      reader.onload = ev => setImagePreviews(prev => [...prev, ev.target?.result as string])
      reader.readAsDataURL(f)
    })
  }

  function removeImage(index: number) {
    setImagePreviews(prev => prev.filter((_, i) => i !== index))
    setImages(prev => prev.filter((_, i) => i !== index))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const formData = new FormData()
      Object.entries(form).forEach(([k, v]) => formData.append(k, String(v)))
      selectedAmenities.forEach(id => formData.append('amenities', id))
      images.forEach(img => formData.append('images', img))

      const url = isEdit ? `/api/admin/properties/${property.id}` : '/api/admin/properties'
      const method = isEdit ? 'PUT' : 'POST'

      const res = await fetch(url, { method, body: formData })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Erro ao salvar')
      }

      router.push('/admin/imoveis')
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="bg-white border border-neutral-200 p-6 mb-5">
      <h3 className="font-serif font-bold text-[#0A1628] mb-4 pb-3 border-b border-neutral-100">{title}</h3>
      {children}
    </div>
  )

  const Field = ({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) => (
    <div>
      <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
        {label}{required && <span className="text-red-500 ml-1">*</span>}
      </label>
      {children}
    </div>
  )

  const inputCls = "w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C] bg-white"

  return (
    <form onSubmit={handleSubmit}>
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 text-sm mb-5">
          {error}
        </div>
      )}

      {/* Basic info */}
      <Section title="Informações Básicas">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-3">
            <Field label="Título" required>
              <input
                type="text"
                required
                value={form.title}
                onChange={e => set('title', e.target.value)}
                placeholder="Ex: Apartamento 3 suítes com vista mar"
                className={inputCls}
              />
            </Field>
          </div>

          <Field label="Tipo" required>
            <select value={form.type} onChange={e => set('type', e.target.value)} className={inputCls}>
              {PROPERTY_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </Field>

          <Field label="Finalidade" required>
            <select value={form.purpose} onChange={e => set('purpose', e.target.value)} className={inputCls}>
              <option value="venda">Venda</option>
              <option value="aluguel">Aluguel</option>
              <option value="lancamento">Lançamento</option>
            </select>
          </Field>

          <Field label="Status" required>
            <select value={form.status} onChange={e => set('status', e.target.value)} className={inputCls}>
              <option value="rascunho">Rascunho</option>
              <option value="ativo">Ativo</option>
              <option value="inativo">Inativo</option>
              <option value="vendido">Vendido</option>
              <option value="alugado">Alugado</option>
            </select>
          </Field>

          <Field label="Preço (R$)" required>
            <input
              type="number"
              required
              value={form.price}
              onChange={e => set('price', e.target.value)}
              placeholder="0,00"
              className={inputCls}
            />
          </Field>

          <Field label="Condomínio (R$)">
            <input
              type="number"
              value={form.condo_fee}
              onChange={e => set('condo_fee', e.target.value)}
              placeholder="0,00"
              className={inputCls}
            />
          </Field>

          <Field label="IPTU (R$/ano)">
            <input
              type="number"
              value={form.iptu}
              onChange={e => set('iptu', e.target.value)}
              placeholder="0,00"
              className={inputCls}
            />
          </Field>
        </div>

        <div className="mt-4">
          <Field label="Descrição">
            <textarea
              value={form.description}
              onChange={e => set('description', e.target.value)}
              rows={5}
              placeholder="Descreva o imóvel em detalhes..."
              className={`${inputCls} resize-none`}
            />
          </Field>
        </div>
      </Section>

      {/* Location */}
      <Section title="Localização">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Field label="Cidade" required>
            <select
              value={form.city_id}
              onChange={e => { set('city_id', e.target.value); set('neighborhood_id', '') }}
              className={inputCls}
            >
              <option value="">Selecione...</option>
              {cities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>

          <Field label="Bairro">
            <select
              value={form.neighborhood_id}
              onChange={e => set('neighborhood_id', e.target.value)}
              className={inputCls}
              disabled={!form.city_id}
            >
              <option value="">Selecione...</option>
              {filteredNeighborhoods.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
            </select>
          </Field>

          <Field label="CEP">
            <input
              type="text"
              value={form.zip_code}
              onChange={e => set('zip_code', e.target.value)}
              placeholder="00000-000"
              className={inputCls}
            />
          </Field>

          <div className="sm:col-span-2">
            <Field label="Endereço">
              <input
                type="text"
                value={form.address}
                onChange={e => set('address', e.target.value)}
                placeholder="Rua, Avenida..."
                className={inputCls}
              />
            </Field>
          </div>

          <Field label="Número">
            <input
              type="text"
              value={form.address_number}
              onChange={e => set('address_number', e.target.value)}
              className={inputCls}
            />
          </Field>

          <Field label="Latitude">
            <input
              type="number"
              step="any"
              value={form.latitude}
              onChange={e => set('latitude', e.target.value)}
              placeholder="-26.9000"
              className={inputCls}
            />
          </Field>

          <Field label="Longitude">
            <input
              type="number"
              step="any"
              value={form.longitude}
              onChange={e => set('longitude', e.target.value)}
              placeholder="-48.6000"
              className={inputCls}
            />
          </Field>
        </div>
      </Section>

      {/* Specs */}
      <Section title="Características">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
          {[
            { key: 'bedrooms', label: 'Quartos' },
            { key: 'suites', label: 'Suítes' },
            { key: 'bathrooms', label: 'Banheiros' },
            { key: 'parking_spots', label: 'Vagas' },
          ].map(({ key, label }) => (
            <Field key={key} label={label}>
              <input
                type="number"
                min={0}
                value={form[key as keyof typeof form] as number}
                onChange={e => set(key, Number(e.target.value))}
                className={inputCls}
              />
            </Field>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
          <Field label="Área Privativa (m²)">
            <input type="number" value={form.private_area} onChange={e => set('private_area', e.target.value)} className={inputCls} />
          </Field>
          <Field label="Área Total (m²)">
            <input type="number" value={form.total_area} onChange={e => set('total_area', e.target.value)} className={inputCls} />
          </Field>
          <Field label="Andar">
            <input type="number" value={form.floor} onChange={e => set('floor', e.target.value)} className={inputCls} />
          </Field>
          <Field label="Ano de construção">
            <input type="number" value={form.year_built} onChange={e => set('year_built', e.target.value)} placeholder="2024" className={inputCls} />
          </Field>
        </div>

        {/* Toggles */}
        <div className="flex flex-wrap gap-6 pt-2 border-t border-neutral-100">
          {[
            { key: 'furnished', label: 'Mobiliado' },
            { key: 'pet_friendly', label: 'Pet Friendly' },
            { key: 'gated_community', label: 'Cond. Fechado' },
            { key: 'featured', label: 'Em Destaque' },
            { key: 'launch', label: 'Lançamento' },
          ].map(({ key, label }) => (
            <label key={key} className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={form[key as keyof typeof form] as boolean}
                onChange={e => set(key, e.target.checked)}
                className="w-4 h-4 accent-[#C9A84C]"
              />
              <span className="text-sm text-neutral-700">{label}</span>
            </label>
          ))}
        </div>
      </Section>

      {/* Amenities */}
      <Section title="Comodidades">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {amenities.map(amenity => (
            <label key={amenity.id} className="flex items-center gap-2 cursor-pointer py-1">
              <input
                type="checkbox"
                checked={selectedAmenities.includes(amenity.id)}
                onChange={e => {
                  setSelectedAmenities(prev =>
                    e.target.checked ? [...prev, amenity.id] : prev.filter(id => id !== amenity.id)
                  )
                }}
                className="w-4 h-4 accent-[#C9A84C]"
              />
              <span className="text-sm text-neutral-700">{amenity.name}</span>
            </label>
          ))}
        </div>
      </Section>

      {/* Images */}
      <Section title="Fotos">
        <div
          className="border-2 border-dashed border-neutral-300 p-8 text-center cursor-pointer hover:border-[#C9A84C] transition-colors mb-4"
          onClick={() => fileRef.current?.click()}
        >
          <svg className="w-10 h-10 text-neutral-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <p className="text-sm text-neutral-600 font-medium">Clique para adicionar fotos</p>
          <p className="text-xs text-neutral-400 mt-1">JPG, PNG ou WebP. Máx. 10MB cada.</p>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleFiles}
          />
        </div>

        {imagePreviews.length > 0 && (
          <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
            {imagePreviews.map((src, i) => (
              <div key={i} className="relative aspect-square">
                <img src={src} alt="" className="w-full h-full object-cover" />
                {i === 0 && (
                  <span className="absolute top-1 left-1 bg-[#C9A84C] text-white text-xs px-1.5 py-0.5">
                    Capa
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => removeImage(i)}
                  className="absolute top-1 right-1 w-6 h-6 bg-red-500 text-white text-xs flex items-center justify-center hover:bg-red-600"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* Media */}
      <Section title="Mídia">
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="URL do Vídeo (YouTube)">
            <input
              type="url"
              value={form.video_url}
              onChange={e => set('video_url', e.target.value)}
              placeholder="https://youtube.com/..."
              className={inputCls}
            />
          </Field>
          <Field label="Tour Virtual">
            <input
              type="url"
              value={form.virtual_tour_url}
              onChange={e => set('virtual_tour_url', e.target.value)}
              placeholder="https://..."
              className={inputCls}
            />
          </Field>
        </div>
      </Section>

      {/* SEO */}
      <Section title="SEO">
        <div className="space-y-4">
          <Field label="Título SEO">
            <input
              type="text"
              value={form.seo_title}
              onChange={e => set('seo_title', e.target.value)}
              placeholder="Título para motores de busca"
              className={inputCls}
            />
            <p className="text-xs text-neutral-400 mt-1">{form.seo_title.length}/60 caracteres</p>
          </Field>
          <Field label="Descrição SEO">
            <textarea
              value={form.seo_description}
              onChange={e => set('seo_description', e.target.value)}
              placeholder="Descrição para motores de busca"
              rows={2}
              className={`${inputCls} resize-none`}
            />
            <p className="text-xs text-neutral-400 mt-1">{form.seo_description.length}/160 caracteres</p>
          </Field>
        </div>
      </Section>

      {/* Actions */}
      <div className="flex items-center justify-between pt-2">
        <button
          type="button"
          onClick={() => router.back()}
          className="text-sm text-neutral-500 hover:text-neutral-800 transition-colors"
        >
          ← Cancelar
        </button>
        <div className="flex gap-3">
          <button
            type="submit"
            disabled={loading}
            onClick={() => set('status', 'rascunho')}
            className="border border-neutral-300 text-neutral-700 px-5 py-2.5 text-sm hover:border-neutral-500 transition-colors disabled:opacity-50"
          >
            Salvar rascunho
          </button>
          <button
            type="submit"
            disabled={loading}
            onClick={() => set('status', 'ativo')}
            className="bg-[#C9A84C] text-white px-6 py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors disabled:opacity-50"
          >
            {loading ? 'Salvando...' : isEdit ? 'Atualizar imóvel' : 'Publicar imóvel'}
          </button>
        </div>
      </div>
    </form>
  )
}
