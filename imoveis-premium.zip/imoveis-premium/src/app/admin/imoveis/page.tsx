import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { formatPrice } from '@/lib/utils'

interface SearchParams {
  page?: string
  status?: string
  q?: string
}

export default async function AdminImoveisPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>
}) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const params = await searchParams
  const page = Number(params.page || 1)
  const perPage = 20
  const from = (page - 1) * perPage

  let query = supabase
    .from('properties')
    .select(`
      id, code, title, slug, type, purpose, status, price, bedrooms,
      private_area, created_at, featured,
      city:cities(name),
      neighborhood:neighborhoods(name)
    `, { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(from, from + perPage - 1)

  if (params.status) query = query.eq('status', params.status)
  if (params.q) query = query.ilike('title', `%${params.q}%`)

  const { data: properties, count } = await query
  const totalPages = Math.ceil((count || 0) / perPage)

  const statusColor: Record<string, string> = {
    ativo: 'bg-green-100 text-green-800',
    inativo: 'bg-neutral-100 text-neutral-600',
    vendido: 'bg-blue-100 text-blue-800',
    alugado: 'bg-purple-100 text-purple-800',
    rascunho: 'bg-yellow-100 text-yellow-800',
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Imóveis</h1>
          <p className="text-neutral-500 text-sm mt-0.5">{count} imóveis cadastrados</p>
        </div>
        <Link
          href="/admin/imoveis/novo"
          className="bg-[#C9A84C] text-white px-5 py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors"
        >
          + Novo imóvel
        </Link>
      </div>

      {/* Filters */}
      <div className="bg-white border border-neutral-200 p-4 mb-5 flex flex-wrap gap-3">
        <form method="get" className="flex gap-3 flex-wrap flex-1">
          <input
            type="text"
            name="q"
            defaultValue={params.q}
            placeholder="Buscar por título..."
            className="border border-neutral-200 px-3 py-2 text-sm focus:outline-none focus:border-[#C9A84C] w-64"
          />
          <select
            name="status"
            defaultValue={params.status || ''}
            className="border border-neutral-200 px-3 py-2 text-sm focus:outline-none focus:border-[#C9A84C]"
          >
            <option value="">Todos os status</option>
            <option value="ativo">Ativo</option>
            <option value="rascunho">Rascunho</option>
            <option value="vendido">Vendido</option>
            <option value="alugado">Alugado</option>
            <option value="inativo">Inativo</option>
          </select>
          <button
            type="submit"
            className="bg-[#0A1628] text-white px-4 py-2 text-sm hover:bg-[#1a2d4a] transition-colors"
          >
            Filtrar
          </button>
        </form>
      </div>

      {/* Table */}
      <div className="bg-white border border-neutral-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-neutral-50 border-b border-neutral-200">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Imóvel</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Código</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Tipo</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Preço</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Status</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {(properties || []).map((p: any) => (
                <tr key={p.id} className="hover:bg-neutral-50 transition-colors">
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium text-[#0A1628] line-clamp-1">{p.title}</p>
                      <p className="text-neutral-400 text-xs mt-0.5">
                        {p.neighborhood?.name && `${p.neighborhood.name}, `}{p.city?.name}
                      </p>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-neutral-500 font-mono text-xs">{p.code}</td>
                  <td className="px-4 py-3 text-neutral-600 capitalize">{p.type}</td>
                  <td className="px-4 py-3 font-medium text-[#0A1628]">
                    {formatPrice(p.price, p.purpose)}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2.5 py-1 font-medium capitalize ${statusColor[p.status] || ''}`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Link
                        href={`/admin/imoveis/${p.id}/editar`}
                        className="text-xs text-[#0A1628] hover:text-[#C9A84C] font-medium transition-colors"
                      >
                        Editar
                      </Link>
                      <a
                        href={`/imovel/${p.slug}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-neutral-400 hover:text-[#0A1628] transition-colors"
                      >
                        Ver
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-neutral-200">
            <p className="text-xs text-neutral-500">
              Página {page} de {totalPages}
            </p>
            <div className="flex gap-1">
              {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => i + 1).map(p => (
                <a
                  key={p}
                  href={`/admin/imoveis?page=${p}${params.status ? `&status=${params.status}` : ''}`}
                  className={`w-8 h-8 flex items-center justify-center text-xs transition-colors ${
                    p === page
                      ? 'bg-[#0A1628] text-white'
                      : 'border border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
                  }`}
                >
                  {p}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
