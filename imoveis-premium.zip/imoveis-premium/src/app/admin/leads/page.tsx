import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import LeadsTable from '@/components/admin/LeadsTable'

interface SearchParams {
  page?: string
  status?: string
}

export default async function AdminLeadsPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>
}) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const params = await searchParams
  const page = Number(params.page || 1)
  const perPage = 25
  const from = (page - 1) * perPage

  let query = supabase
    .from('leads')
    .select(`
      id, name, email, phone, message, source, status, created_at,
      property:properties(id, title, code),
      agent:agents(name)
    `, { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(from, from + perPage - 1)

  if (params.status) query = query.eq('status', params.status)

  const { data: leads, count } = await query
  const totalPages = Math.ceil((count || 0) / perPage)

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Leads</h1>
          <p className="text-neutral-500 text-sm mt-0.5">{count} contatos recebidos</p>
        </div>
        <a
          href="/api/admin/leads/export"
          className="border border-neutral-300 text-neutral-700 px-4 py-2.5 text-sm hover:border-[#0A1628] transition-colors"
        >
          ↓ Exportar CSV
        </a>
      </div>

      {/* Status filter */}
      <div className="flex gap-2 mb-5">
        {[
          { value: '', label: 'Todos' },
          { value: 'novo', label: 'Novos' },
          { value: 'contato', label: 'Em contato' },
          { value: 'negociando', label: 'Negociando' },
          { value: 'convertido', label: 'Convertidos' },
          { value: 'perdido', label: 'Perdidos' },
        ].map(s => (
          <a
            key={s.value}
            href={`/admin/leads${s.value ? `?status=${s.value}` : ''}`}
            className={`px-3 py-1.5 text-xs font-medium transition-colors ${
              params.status === s.value || (!params.status && !s.value)
                ? 'bg-[#0A1628] text-white'
                : 'border border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
            }`}
          >
            {s.label}
          </a>
        ))}
      </div>

      <LeadsTable leads={leads || []} totalPages={totalPages} currentPage={page} />
    </div>
  )
}
