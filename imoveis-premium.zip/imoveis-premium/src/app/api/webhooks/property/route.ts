import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

/**
 * Supabase Database Webhook
 * Configure in Supabase Dashboard > Database > Webhooks
 * Event: INSERT/UPDATE on properties table
 * URL: https://yoursite.com/api/webhooks/property
 *
 * This triggers cache revalidation and (future) portal sync.
 */
export async function POST(req: NextRequest) {
  // Verify webhook secret
  const secret = req.headers.get('x-webhook-secret')
  if (secret !== process.env.WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json()
    const { type, record, old_record } = body

    console.log(`[Webhook] Property ${type}:`, record?.id)

    // Here you could:
    // 1. Invalidate ISR cache for affected property page
    // 2. Push to OLX / ZAP / VivaReal APIs
    // 3. Send notification to assigned agent
    // 4. Update city property_count

    if (type === 'INSERT' || type === 'UPDATE') {
      const supabase = await createAdminClient()

      // Update city property count
      if (record?.city_id) {
        const { count } = await supabase
          .from('properties')
          .select('*', { count: 'exact', head: true })
          .eq('city_id', record.city_id)
          .eq('status', 'ativo')

        await supabase
          .from('cities')
          .update({ property_count: count || 0 })
          .eq('id', record.city_id)
      }
    }

    return NextResponse.json({ received: true })
  } catch (err: any) {
    console.error('[Webhook] Error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
