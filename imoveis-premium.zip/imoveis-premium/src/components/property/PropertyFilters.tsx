'use client'

import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { SearchFilters, PROPERTY_TYPES } from '@/types'
import { PROPERTY_TYPES as PT } from '@/lib/utils'

interface City { id: string; name: string }

interface Props {
  cities: City[]
  currentFilters: SearchFilters
}

export default function PropertyFilters({ cities, currentFilters }: Props) {
  const router = useRouter()
  const [filters, setFilters] = useState({
    purpose: currentFilters.purpose || '',
    type: currentFilters.type || '',
    city_id: currentFilters.city_id || '',
    min_price: currentFilters.min_price?.toString() || '',
    max_price: currentFilters.max_price?.toString() || '',
    bedrooms: currentFilters.bedrooms?.toString() || '',
    suites: currentFilters.suites?.toString() || '',
    parking_spots: currentFilters.parking_spots?.toString() || '',
    min_area: currentFilters.min_area?.toString() || '',
    max_area: currentFilters.max_area?.toString() || '',
    furnished: currentFilters.furnished ? 'true' : '',
    pet_friendly: currentFilters.pet_friendly ? 'true' : '',
    gated_community: currentFilters.gated_community ? 'true' : '',
  })

  function applyFilters() {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, val]) => {
      if (val) params.set(key, val)
    })
    router.push(`/imoveis?${params.toString()}`)
  }

  function clearFilters() {
    setFilters({
      purpose: '', type: '', city_id: '', min_price: '', max_price: '',
      bedrooms: '', suites: '', parking_spots: '', min_area: '', max_area: '',
      furnished: '', pet_friendly: '', gated_community: '',
    })
    router.push('/imoveis')
  }

  const Label = ({ children }: { children: React.ReactNode }) => (
    <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
      {children}
    </label>
  )

  const Select = ({ name, value, onChange, children }: any) => (
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C] bg-white"
    >
      {children}
    </select>
  )

  return (
    <div className="bg-white border border-neutral-200 p-5 sticky top-24">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-serif font-bold text-[#0A1628]">Filtros</h3>
        <button
          onClick={clearFilters}
          className="text-xs text-neutral-400 hover:text-[#0A1628] transition-colors"
        >
          Limpar tudo
        </button>
      </div>

      <div className="space-y-4">
        <div>
          <Label>Finalidade</Label>
          <Select value={filters.purpose} onChange={(v: string) => setFilters(f => ({ ...f, purpose: v }))}>
            <option value="">Todos</option>
            <option value="venda">Comprar</option>
            <option value="aluguel">Alugar</option>
            <option value="lancamento">Lançamentos</option>
          </Select>
        </div>

        <div>
          <Label>Tipo de imóvel</Label>
          <Select value={filters.type} onChange={(v: string) => setFilters(f => ({ ...f, type: v }))}>
            <option value="">Todos os tipos</option>
            {PT.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </Select>
        </div>

        <div>
          <Label>Cidade</Label>
          <Select value={filters.city_id} onChange={(v: string) => setFilters(f => ({ ...f, city_id: v }))}>
            <option value="">Todas as cidades</option>
            {cities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label>Preço mín.</Label>
            <input
              type="number"
              value={filters.min_price}
              onChange={e => setFilters(f => ({ ...f, min_price: e.target.value }))}
              placeholder="R$ 0"
              className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
            />
          </div>
          <div>
            <Label>Preço máx.</Label>
            <input
              type="number"
              value={filters.max_price}
              onChange={e => setFilters(f => ({ ...f, max_price: e.target.value }))}
              placeholder="R$ ∞"
              className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
            />
          </div>
        </div>

        <div>
          <Label>Quartos</Label>
          <div className="flex gap-1">
            {['', '1', '2', '3', '4', '5+'].map(n => (
              <button
                key={n}
                type="button"
                onClick={() => setFilters(f => ({ ...f, bedrooms: n === '5+' ? '5' : n }))}
                className={`flex-1 py-2 text-xs border transition-colors ${
                  (n === '' && !filters.bedrooms) || (n !== '' && filters.bedrooms === (n === '5+' ? '5' : n))
                    ? 'bg-[#0A1628] text-white border-[#0A1628]'
                    : 'border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
                }`}
              >
                {n || 'T'}
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label>Suítes</Label>
          <Select value={filters.suites} onChange={(v: string) => setFilters(f => ({ ...f, suites: v }))}>
            <option value="">Qualquer</option>
            {[1, 2, 3, 4].map(n => <option key={n} value={n}>{n}+</option>)}
          </Select>
        </div>

        <div>
          <Label>Vagas de garagem</Label>
          <Select value={filters.parking_spots} onChange={(v: string) => setFilters(f => ({ ...f, parking_spots: v }))}>
            <option value="">Qualquer</option>
            {[1, 2, 3, 4].map(n => <option key={n} value={n}>{n}+</option>)}
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label>Área mín.</Label>
            <input
              type="number"
              value={filters.min_area}
              onChange={e => setFilters(f => ({ ...f, min_area: e.target.value }))}
              placeholder="m²"
              className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
            />
          </div>
          <div>
            <Label>Área máx.</Label>
            <input
              type="number"
              value={filters.max_area}
              onChange={e => setFilters(f => ({ ...f, max_area: e.target.value }))}
              placeholder="m²"
              className="w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"
            />
          </div>
        </div>

        {/* Toggles */}
        <div className="space-y-2 pt-2 border-t border-neutral-100">
          {[
            { key: 'furnished', label: 'Mobiliado' },
            { key: 'pet_friendly', label: 'Pet Friendly' },
            { key: 'gated_community', label: 'Condomínio fechado' },
          ].map(({ key, label }) => (
            <label key={key} className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters[key as keyof typeof filters] === 'true'}
                onChange={e => setFilters(f => ({ ...f, [key]: e.target.checked ? 'true' : '' }))}
                className="w-4 h-4 accent-[#C9A84C]"
              />
              <span className="text-sm text-neutral-700">{label}</span>
            </label>
          ))}
        </div>

        <button
          onClick={applyFilters}
          className="w-full bg-[#C9A84C] text-white py-3 text-sm font-medium hover:bg-[#b8963e] transition-colors mt-2"
        >
          Aplicar filtros
        </button>
      </div>
    </div>
  )
}
