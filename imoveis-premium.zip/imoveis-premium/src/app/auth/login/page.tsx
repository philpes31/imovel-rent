'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      setError('E-mail ou senha incorretos')
      setLoading(false)
    } else {
      router.push('/admin/dashboard')
    }
  }

  return (
    <div className="min-h-screen bg-[#0A1628] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 bg-[#C9A84C] flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="white" className="w-6 h-6">
                <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z"/>
              </svg>
            </div>
            <span className="font-serif text-2xl font-bold text-white">
              Premium<span className="text-[#C9A84C]">SC</span>
            </span>
          </Link>
          <p className="text-neutral-500 text-sm mt-2">Painel Administrativo</p>
        </div>

        <div className="bg-white p-8">
          <h1 className="font-serif text-xl font-bold text-[#0A1628] mb-6">Entrar</h1>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
                E-mail
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full border border-neutral-200 px-4 py-3 text-sm focus:outline-none focus:border-[#C9A84C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">
                Senha
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full border border-neutral-200 px-4 py-3 text-sm focus:outline-none focus:border-[#C9A84C]"
              />
            </div>

            {error && (
              <p className="text-red-500 text-sm bg-red-50 px-3 py-2">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#0A1628] hover:bg-[#1a2d4a] disabled:bg-neutral-400 text-white py-3 text-sm font-medium transition-colors mt-2"
            >
              {loading ? 'Entrando...' : 'Entrar no painel'}
            </button>
          </form>
        </div>

        <p className="text-center mt-4">
          <Link href="/" className="text-neutral-500 text-sm hover:text-white transition-colors">
            ← Voltar ao site
          </Link>
        </p>
      </div>
    </div>
  )
}
