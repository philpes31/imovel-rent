import type { Metadata } from 'next'
import { Suspense } from 'react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import PropertyFilters from '@/components/property/PropertyFilters'
import { getProperties, getCities } from '@/lib/queries'
import { SearchFilters } from '@/types'

export const metadata: Metadata = {
  title: 'Imóveis à Venda e para Alugar | PremiumSC',
  description: 'Encontre apartamentos, casas, terrenos e coberturas em Santa Catarina. Filtre por cidade, preço, quartos e muito mais.',
}

interface PageProps {
  searchParams: Promise<Record<string, string>>
}

export default async function ImoveisPage({ searchParams }: PageProps) {
  const params = await searchParams

  const filters: SearchFilters = {
    purpose: params.purpose as any,
    type: params.type as any,
    city_id: params.city_id,
    neighborhood_id: params.neighborhood_id,
    min_price: params.min_price ? Number(params.min_price) : undefined,
    max_price: params.max_price ? Number(params.max_price) : undefined,
    bedrooms: params.bedrooms ? Number(params.bedrooms) : undefined,
    suites: params.suites ? Number(params.suites) : undefined,
    parking_spots: params.parking_spots ? Number(params.parking_spots) : undefined,
    min_area: params.min_area ? Number(params.min_area) : undefined,
    max_area: params.max_area ? Number(params.max_area) : undefined,
    furnished: params.furnished === 'true' ? true : undefined,
    pet_friendly: params.pet_friendly === 'true' ? true : undefined,
    gated_community: params.gated_community === 'true' ? true : undefined,
    page: params.page ? Number(params.page) : 1,
    per_page: 12,
    sort: params.sort as any,
  }

  const [{ data: properties, total, total_pages, page }, cities] = await Promise.all([
    getProperties(filters),
    getCities(),
  ])

  return (
    <>
      <Header />
      <main className="pt-20 min-h-screen bg-neutral-50">

        {/* Page header */}
        <div className="bg-white border-b border-neutral-200 py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="font-serif text-2xl font-bold text-[#0A1628]">
              {filters.purpose === 'aluguel' ? 'Imóveis para Alugar' :
               filters.purpose === 'lancamento' ? 'Lançamentos' :
               filters.purpose === 'venda' ? 'Imóveis à Venda' :
               'Todos os Imóveis'}
            </h1>
            <p className="text-neutral-500 text-sm mt-1">
              {total} {total === 1 ? 'imóvel encontrado' : 'imóveis encontrados'}
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row gap-8">

            {/* Sidebar */}
            <aside className="w-full lg:w-72 flex-shrink-0">
              <PropertyFilters cities={cities} currentFilters={filters} />
            </aside>

            {/* Results */}
            <div className="flex-1">
              {/* Sort */}
              <div className="flex items-center justify-between mb-6">
                <p className="text-sm text-neutral-500">
                  Página {page} de {total_pages || 1}
                </p>
                <form>
                  <select
                    name="sort"
                    defaultValue={filters.sort || 'newest'}
                    className="border border-neutral-200 text-sm px-3 py-2 focus:outline-none focus:border-[#C9A84C]"
                    onChange={e => {
                      const url = new URL(window.location.href)
                      url.searchParams.set('sort', e.target.value)
                      window.location.href = url.toString()
                    }}
                  >
                    <option value="newest">Mais recentes</option>
                    <option value="price_asc">Menor preço</option>
                    <option value="price_desc">Maior preço</option>
                    <option value="most_viewed">Mais vistos</option>
                  </select>
                </form>
              </div>

              {properties.length > 0 ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                    {properties.map(property => (
                      <PropertyCard key={property.id} property={property} />
                    ))}
                  </div>

                  {/* Pagination */}
                  {total_pages > 1 && (
                    <div className="flex items-center justify-center gap-2 mt-10">
                      {Array.from({ length: total_pages }, (_, i) => i + 1).map(p => {
                        const url = new URL('http://x/imoveis')
                        Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v))
                        url.searchParams.set('page', String(p))
                        return (
                          <a
                            key={p}
                            href={`/imoveis?${url.searchParams.toString()}`}
                            className={`w-9 h-9 flex items-center justify-center text-sm transition-colors ${
                              p === page
                                ? 'bg-[#0A1628] text-white'
                                : 'border border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
                            }`}
                          >
                            {p}
                          </a>
                        )
                      })}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-20 bg-white border border-neutral-200">
                  <svg className="w-12 h-12 text-neutral-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                  </svg>
                  <h3 className="font-serif text-xl text-neutral-700 mb-2">Nenhum imóvel encontrado</h3>
                  <p className="text-neutral-400 text-sm">Tente ajustar os filtros de busca</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
