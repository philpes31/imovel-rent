'use client'

import { useState } from 'react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'

export default function AnunciarPage() {
  const [form, setForm] = useState({
    name: '', phone: '', email: '',
    type: '', purpose: '', city: '', address: '',
    price: '', area: '', bedrooms: '', message: '',
  })
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const message = `*Anunciar imóvel*\nTipo: ${form.type}\nFinalidade: ${form.purpose}\nCidade: ${form.city}\nEndereço: ${form.address}\nPreço: ${form.price}\nÁrea: ${form.area}m²\nQuartos: ${form.bedrooms}\nObs: ${form.message}`
    await fetch('/api/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: form.name, phone: form.phone, email: form.email, message, source: 'site' }),
    })
    setSent(true)
    setLoading(false)
  }

  const inputCls = "w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">

        {/* Hero */}
        <div className="bg-[#0A1628] py-16 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase font-medium mb-3">Venda com a gente</p>
            <h1 className="font-serif text-4xl font-bold text-white mb-4">Anuncie seu Imóvel</h1>
            <div className="w-12 h-0.5 bg-[#C9A84C] mx-auto mb-4" />
            <p className="text-neutral-400 max-w-lg mx-auto">
              Alcance milhares de compradores qualificados em Santa Catarina. Cadastre seu imóvel gratuitamente.
            </p>
          </div>
        </div>

        {/* Benefits */}
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: '👁️', title: 'Máxima visibilidade', desc: 'Seu imóvel em destaque no site e nos principais portais imobiliários.' },
                { icon: '📸', title: 'Fotos profissionais', desc: 'Fotógrafo especializado para valorizar cada detalhe do seu imóvel.' },
                { icon: '📊', title: 'Gestão completa', desc: 'Acompanhe visitas, leads e negociações em tempo real.' },
                { icon: '🤝', title: 'Corretor dedicado', desc: 'Um corretor exclusivo cuidará do seu imóvel do anúncio ao fechamento.' },
              ].map(b => (
                <div key={b.title} className="text-center p-6 border border-neutral-100 hover:border-[#C9A84C] transition-colors">
                  <div className="text-3xl mb-3">{b.icon}</div>
                  <h3 className="font-medium text-[#0A1628] mb-2">{b.title}</h3>
                  <p className="text-neutral-500 text-xs leading-relaxed">{b.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Form */}
        <section className="py-14 bg-neutral-50">
          <div className="max-w-3xl mx-auto px-4 sm:px-6">
            {sent ? (
              <div className="bg-white border border-green-200 p-12 text-center">
                <div className="text-4xl mb-4">✅</div>
                <h3 className="font-serif text-2xl font-bold text-green-800 mb-2">Recebemos seus dados!</h3>
                <p className="text-green-700 mb-6">Um de nossos corretores entrará em contato em breve para avaliar seu imóvel.</p>
                <a href="/" className="inline-block bg-[#0A1628] text-white px-8 py-3 text-sm font-medium hover:bg-[#1a2d4a] transition-colors">
                  Voltar ao início
                </a>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-white border border-neutral-200 p-8">
                <h2 className="font-serif text-xl font-bold text-[#0A1628] mb-6">Dados do seu imóvel</h2>

                {/* Owner info */}
                <div className="mb-6 pb-6 border-b border-neutral-100">
                  <h3 className="text-xs font-medium text-neutral-500 uppercase tracking-widest mb-4">Seus dados</h3>
                  <div className="grid sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Nome <span className="text-red-500">*</span></label>
                      <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={inputCls} placeholder="Seu nome" />
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Telefone <span className="text-red-500">*</span></label>
                      <input required type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className={inputCls} placeholder="(47) 99999-9999" />
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">E-mail</label>
                      <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className={inputCls} placeholder="seu@email.com" />
                    </div>
                  </div>
                </div>

                {/* Property info */}
                <div className="mb-6">
                  <h3 className="text-xs font-medium text-neutral-500 uppercase tracking-widest mb-4">Dados do imóvel</h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Tipo do imóvel</label>
                      <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))} className={`${inputCls} bg-white`}>
                        <option value="">Selecione...</option>
                        <option>Apartamento</option><option>Casa</option><option>Cobertura</option>
                        <option>Terreno</option><option>Comercial</option><option>Studio</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Finalidade</label>
                      <select value={form.purpose} onChange={e => setForm(f => ({ ...f, purpose: e.target.value }))} className={`${inputCls} bg-white`}>
                        <option value="">Selecione...</option>
                        <option>Venda</option><option>Aluguel</option><option>Venda e Aluguel</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Cidade</label>
                      <select value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} className={`${inputCls} bg-white`}>
                        <option value="">Selecione...</option>
                        <option>Balneário Camboriú</option><option>Itapema</option><option>Blumenau</option>
                        <option>Itajaí</option><option>Florianópolis</option><option>Outra</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Endereço / Bairro</label>
                      <input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} className={inputCls} placeholder="Ex: Centro, Rua das Flores" />
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Preço estimado (R$)</label>
                      <input type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} className={inputCls} placeholder="0,00" />
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Área (m²)</label>
                      <input type="number" value={form.area} onChange={e => setForm(f => ({ ...f, area: e.target.value }))} className={inputCls} placeholder="0" />
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-600 mb-1.5">Quartos</label>
                      <select value={form.bedrooms} onChange={e => setForm(f => ({ ...f, bedrooms: e.target.value }))} className={`${inputCls} bg-white`}>
                        <option value="">Selecione...</option>
                        {[1, 2, 3, 4, 5].map(n => <option key={n}>{n}{n === 5 ? '+' : ''}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="mt-4">
                    <label className="block text-xs text-neutral-600 mb-1.5">Observações adicionais</label>
                    <textarea rows={3} value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} className={`${inputCls} resize-none`} placeholder="Diferenciais, reformas, estado de conservação..." />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#C9A84C] hover:bg-[#b8963e] disabled:bg-neutral-400 text-white py-3.5 font-medium text-sm transition-colors"
                >
                  {loading ? 'Enviando...' : 'Quero anunciar meu imóvel →'}
                </button>
                <p className="text-neutral-400 text-xs text-center mt-3">
                  Ao enviar, nossa equipe entrará em contato em até 24 horas.
                </p>
              </form>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
