import { createClient } from '@/lib/supabase/server'
import { redirect, notFound } from 'next/navigation'
import AgentForm from '@/components/admin/AgentForm'

interface Props { params: Promise<{ id: string }> }

export default async function EditarCorretorPage({ params }: Props) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: agent } = await supabase.from('agents').select('*').eq('id', id).single()
  if (!agent) notFound()

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Editar Corretor</h1>
        <p className="text-neutral-500 text-sm mt-0.5">{agent.name}</p>
      </div>
      <AgentForm agent={agent} />
    </div>
  )
}
