'use client'

import { CompareProvider } from '@/hooks/useCompare'
import CompareBar from '@/components/property/CompareBar'

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <CompareProvider>
      {children}
      <CompareBar />
    </CompareProvider>
  )
}
