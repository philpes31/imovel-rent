'use client'

import { useState, useEffect, useCallback, createContext, useContext } from 'react'

const MAX_COMPARE = 3

export interface CompareItem {
  id: string
  slug: string
  title: string
  price: number
  purpose: string
  type: string
  bedrooms: number
  suites: number
  bathrooms: number
  parking_spots: number
  private_area?: number
  total_area?: number
  coverImage?: string
  city?: string
  neighborhood?: string
  furnished: boolean
  pet_friendly: boolean
  gated_community: boolean
  condo_fee?: number
}

interface CompareContextType {
  items: CompareItem[]
  add: (item: CompareItem) => void
  remove: (id: string) => void
  toggle: (item: CompareItem) => void
  isComparing: (id: string) => boolean
  clear: () => void
  canAdd: boolean
}

const CompareContext = createContext<CompareContextType>({
  items: [], add: () => {}, remove: () => {}, toggle: () => {},
  isComparing: () => false, clear: () => {}, canAdd: true,
})

const KEY = 'premiumsc_compare'

export function CompareProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CompareItem[]>([])

  useEffect(() => {
    try {
      const stored = localStorage.getItem(KEY)
      if (stored) setItems(JSON.parse(stored))
    } catch {}
  }, [])

  const persist = (next: CompareItem[]) => {
    setItems(next)
    try { localStorage.setItem(KEY, JSON.stringify(next)) } catch {}
  }

  const add = useCallback((item: CompareItem) => {
    setItems(prev => {
      if (prev.length >= MAX_COMPARE || prev.find(i => i.id === item.id)) return prev
      const next = [...prev, item]
      try { localStorage.setItem(KEY, JSON.stringify(next)) } catch {}
      return next
    })
  }, [])

  const remove = useCallback((id: string) => {
    setItems(prev => {
      const next = prev.filter(i => i.id !== id)
      try { localStorage.setItem(KEY, JSON.stringify(next)) } catch {}
      return next
    })
  }, [])

  const toggle = useCallback((item: CompareItem) => {
    setItems(prev => {
      const exists = prev.find(i => i.id === item.id)
      const next = exists ? prev.filter(i => i.id !== item.id) : prev.length < MAX_COMPARE ? [...prev, item] : prev
      try { localStorage.setItem(KEY, JSON.stringify(next)) } catch {}
      return next
    })
  }, [])

  const isComparing = useCallback((id: string) => items.some(i => i.id === id), [items])
  const clear = useCallback(() => persist([]), [])

  return (
    <CompareContext.Provider value={{ items, add, remove, toggle, isComparing, clear, canAdd: items.length < MAX_COMPARE }}>
      {children}
    </CompareContext.Provider>
  )
}

export function useCompare() {
  return useContext(CompareContext)
}
