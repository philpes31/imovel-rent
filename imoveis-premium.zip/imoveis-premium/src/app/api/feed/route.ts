import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateXMLFeed } from '@/lib/utils'

export async function GET() {
  const supabase = await createClient()

  const { data: properties } = await supabase
    .from('properties')
    .select(`
      id, code, title, type, purpose, status, price,
      address, bedrooms, bathrooms, parking_spots, private_area,
      description, latitude, longitude,
      city:cities(name),
      neighborhood:neighborhoods(name),
      images:property_images(url)
    `)
    .eq('status', 'ativo')
    .order('published_at', { ascending: false })
    .limit(500)

  const xml = generateXMLFeed((properties || []) as any[])

  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=1800',
    },
  })
}
