import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import { createClient } from '@/lib/supabase/server'

interface Props { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const supabase = await createClient()
  const { data } = await supabase.from('blog_posts').select('title, seo_description').eq('slug', slug).single()
  if (!data) return { title: 'Artigo não encontrado' }
  return { title: `${data.title} | Blog PremiumSC`, description: data.seo_description }
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params
  const supabase = await createClient()

  const { data: post } = await supabase
    .from('blog_posts')
    .select('*, author:agents(name, photo_url, creci)')
    .eq('slug', slug)
    .eq('published', true)
    .single()

  if (!post) notFound()

  const { data: related } = await supabase
    .from('blog_posts')
    .select('id, title, slug, excerpt, cover_image, published_at')
    .eq('published', true)
    .neq('id', post.id)
    .order('published_at', { ascending: false })
    .limit(3)

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">

        {/* Hero */}
        <div className="relative bg-[#0A1628] py-16 px-4">
          {post.cover_image && (
            <div className="absolute inset-0">
              <Image src={post.cover_image} alt={post.title} fill className="object-cover opacity-20" />
            </div>
          )}
          <div className="relative z-10 max-w-3xl mx-auto text-center">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase font-medium mb-3">Blog</p>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-white leading-tight mb-4">
              {post.title}
            </h1>
            <div className="flex items-center justify-center gap-4 text-neutral-400 text-sm">
              {post.author && <span>Por {(post.author as any).name}</span>}
              <span>·</span>
              <span>{new Date(post.published_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid lg:grid-cols-3 gap-10">

            {/* Content */}
            <article className="lg:col-span-2">
              {post.cover_image && (
                <div className="relative aspect-video mb-8 overflow-hidden">
                  <Image src={post.cover_image} alt={post.title} fill className="object-cover" />
                </div>
              )}
              <div
                className="prose prose-neutral max-w-none text-sm leading-relaxed"
                dangerouslySetInnerHTML={{ __html: post.content || '<p>Conteúdo em breve.</p>' }}
              />

              {/* Author box */}
              {post.author && (
                <div className="mt-10 border border-neutral-200 p-6 flex gap-4 items-start">
                  <div className="w-14 h-14 rounded-full bg-neutral-200 overflow-hidden flex-shrink-0">
                    {(post.author as any).photo_url ? (
                      <Image src={(post.author as any).photo_url} alt={(post.author as any).name} width={56} height={56} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-serif text-2xl text-neutral-500">
                        {(post.author as any).name?.charAt(0)}
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-[#0A1628]">{(post.author as any).name}</p>
                    {(post.author as any).creci && (
                      <p className="text-neutral-400 text-xs">CRECI {(post.author as any).creci}</p>
                    )}
                    <p className="text-neutral-500 text-xs mt-1">Corretor especializado em imóveis de alto padrão em Santa Catarina.</p>
                  </div>
                </div>
              )}

              {/* Share */}
              <div className="mt-8 pt-6 border-t border-neutral-200 flex items-center gap-3">
                <span className="text-sm text-neutral-500">Compartilhar:</span>
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(`${post.title} — ${process.env.NEXT_PUBLIC_SITE_URL}/blog/${post.slug}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-green-500 text-white text-xs px-4 py-2 hover:bg-green-600 transition-colors"
                >
                  WhatsApp
                </a>
                <a
                  href={`https://www.facebook.com/sharer/sharer.php?u=${process.env.NEXT_PUBLIC_SITE_URL}/blog/${post.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-blue-600 text-white text-xs px-4 py-2 hover:bg-blue-700 transition-colors"
                >
                  Facebook
                </a>
              </div>
            </article>

            {/* Sidebar */}
            <aside className="space-y-6">
              {/* CTA box */}
              <div className="bg-[#0A1628] p-6 text-white">
                <h3 className="font-serif text-lg font-bold mb-2">Procurando um imóvel?</h3>
                <div className="w-8 h-0.5 bg-[#C9A84C] mb-4" />
                <p className="text-neutral-400 text-sm mb-4">
                  Nossa equipe pode ajudá-lo a encontrar o imóvel ideal em SC.
                </p>
                <Link href="/imoveis" className="block text-center bg-[#C9A84C] text-white py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors mb-2">
                  Ver imóveis
                </Link>
                <a
                  href={`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '5547999999999'}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-center border border-white/20 text-white py-2.5 text-sm hover:border-white transition-colors"
                >
                  Falar no WhatsApp
                </a>
              </div>

              {/* Related */}
              {related && related.length > 0 && (
                <div>
                  <h3 className="font-serif font-bold text-[#0A1628] mb-4">Artigos relacionados</h3>
                  <div className="space-y-4">
                    {related.map((r: any) => (
                      <Link key={r.id} href={`/blog/${r.slug}`} className="group flex gap-3">
                        <div className="w-16 h-16 bg-neutral-200 flex-shrink-0 overflow-hidden">
                          {r.cover_image ? (
                            <Image src={r.cover_image} alt={r.title} width={64} height={64} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                          ) : (
                            <div className="w-full h-full bg-neutral-300 flex items-center justify-center text-xl">📰</div>
                          )}
                        </div>
                        <div>
                          <p className="text-xs font-medium text-[#0A1628] line-clamp-2 group-hover:text-[#C9A84C] transition-colors leading-snug">
                            {r.title}
                          </p>
                          <p className="text-xs text-neutral-400 mt-1">
                            {new Date(r.published_at).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </aside>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
