import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const supabase = await createAdminClient()
  try {
    const fd = await req.formData()
    const data: any = {
      name: fd.get('name'),
      email: fd.get('email'),
      phone: fd.get('phone') || null,
      whatsapp: fd.get('whatsapp') || null,
      creci: fd.get('creci') || null,
      bio: fd.get('bio') || null,
      active: fd.get('active') === 'true',
    }

    const photo = fd.get('photo') as File | null
    if (photo && photo.size > 0) {
      const ext = photo.name.split('.').pop()
      const path = `agents/${Date.now()}.${ext}`
      const { data: up } = await supabase.storage.from('agent-photos').upload(path, photo, { upsert: true })
      if (up) {
        const { data: { publicUrl } } = supabase.storage.from('agent-photos').getPublicUrl(up.path)
        data.photo_url = publicUrl
      }
    }

    const { data: agent, error } = await supabase.from('agents').insert(data).select().single()
    if (error) throw error
    return NextResponse.json({ success: true, id: agent.id })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
