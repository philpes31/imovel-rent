import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'

export default async function AdminBlogPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: posts, count } = await supabase
    .from('blog_posts')
    .select('id, title, slug, published, published_at, author:agents(name)', { count: 'exact' })
    .order('created_at', { ascending: false })

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Blog</h1>
          <p className="text-neutral-500 text-sm mt-0.5">{count} artigos</p>
        </div>
        <Link href="/admin/blog/novo" className="bg-[#C9A84C] text-white px-5 py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors">
          + Novo artigo
        </Link>
      </div>

      <div className="bg-white border border-neutral-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-neutral-50 border-b border-neutral-200">
            <tr>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Título</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Autor</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Data</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Status</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {(posts || []).map((post: any) => (
              <tr key={post.id} className="hover:bg-neutral-50 transition-colors">
                <td className="px-4 py-3">
                  <p className="font-medium text-[#0A1628] line-clamp-1">{post.title}</p>
                  <p className="text-neutral-400 text-xs font-mono mt-0.5">/blog/{post.slug}</p>
                </td>
                <td className="px-4 py-3 text-neutral-600 text-sm">
                  {post.author?.name || '—'}
                </td>
                <td className="px-4 py-3 text-neutral-500 text-xs">
                  {post.published_at
                    ? new Date(post.published_at).toLocaleDateString('pt-BR')
                    : '—'}
                </td>
                <td className="px-4 py-3">
                  <span className={`text-xs px-2.5 py-1 font-medium ${post.published ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                    {post.published ? 'Publicado' : 'Rascunho'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-3">
                    <Link href={`/admin/blog/${post.id}/editar`} className="text-xs text-[#0A1628] hover:text-[#C9A84C] font-medium transition-colors">
                      Editar
                    </Link>
                    <a href={`/blog/${post.slug}`} target="_blank" rel="noopener noreferrer" className="text-xs text-neutral-400 hover:text-[#0A1628] transition-colors">
                      Ver
                    </a>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
