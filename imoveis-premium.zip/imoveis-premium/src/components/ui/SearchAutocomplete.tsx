'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { formatPrice } from '@/lib/utils'

interface SearchResult {
  id: string
  title: string
  slug: string
  price: number
  purpose: string
  type: string
  bedrooms?: number
  private_area?: number
  city?: { name: string }
  images?: Array<{ url: string; is_cover: boolean }>
}

export default function SearchAutocomplete() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const timerRef = useRef<ReturnType<typeof setTimeout>>()

  const search = useCallback(async (q: string) => {
    if (q.length < 2) { setResults([]); setOpen(false); return }
    setLoading(true)
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&limit=6`)
      const data = await res.json()
      setResults(data)
      setOpen(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => search(query), 300)
    return () => clearTimeout(timerRef.current)
  }, [query, search])

  // Close on outside click
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  function getCover(r: SearchResult) {
    const cover = r.images?.find(i => i.is_cover)
    return cover?.url || r.images?.[0]?.url || ''
  }

  return (
    <div ref={containerRef} className="relative w-full max-w-lg">
      <div className="relative">
        <svg
          className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400"
          fill="none" stroke="currentColor" viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onFocus={() => results.length > 0 && setOpen(true)}
          placeholder="Buscar imóveis, cidades, bairros..."
          className="w-full pl-9 pr-4 py-2.5 border border-neutral-200 text-sm focus:outline-none focus:border-[#C9A84C] bg-white"
        />
        {loading && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 border-2 border-[#C9A84C] border-t-transparent rounded-full animate-spin" />
        )}
      </div>

      {open && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-white border border-neutral-200 shadow-xl z-50 mt-1 max-h-80 overflow-y-auto">
          {results.map(r => (
            <Link
              key={r.id}
              href={`/site/imovel/${r.slug}`}
              onClick={() => { setOpen(false); setQuery('') }}
              className="flex items-center gap-3 px-4 py-3 hover:bg-neutral-50 transition-colors border-b border-neutral-100 last:border-0"
            >
              <div className="w-12 h-12 bg-neutral-200 flex-shrink-0 overflow-hidden">
                {getCover(r) ? (
                  <Image src={getCover(r)} alt={r.title} width={48} height={48} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xl">🏠</div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[#0A1628] line-clamp-1">{r.title}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs font-bold text-[#C9A84C]">{formatPrice(r.price, r.purpose)}</span>
                  {r.city && <span className="text-xs text-neutral-400">• {r.city.name}</span>}
                  {r.bedrooms ? <span className="text-xs text-neutral-400">• {r.bedrooms} qts</span> : null}
                </div>
              </div>
            </Link>
          ))}
          <Link
            href={`/site/imoveis?q=${encodeURIComponent(query)}`}
            onClick={() => setOpen(false)}
            className="flex items-center justify-center gap-1 py-3 text-xs text-[#C9A84C] hover:text-[#b8963e] font-medium transition-colors border-t border-neutral-100"
          >
            Ver todos os resultados para "{query}" →
          </Link>
        </div>
      )}

      {open && query.length >= 2 && results.length === 0 && !loading && (
        <div className="absolute top-full left-0 right-0 bg-white border border-neutral-200 shadow-xl z-50 mt-1 px-4 py-3 text-sm text-neutral-500">
          Nenhum imóvel encontrado para "{query}"
        </div>
      )}
    </div>
  )
}
