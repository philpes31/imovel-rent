import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

interface Params { params: Promise<{ id: string }> }

export async function PATCH(req: NextRequest, { params }: Params) {
  const { id } = await params
  const supabase = await createAdminClient()

  try {
    const { status, notes } = await req.json()
    const updates: any = {}
    if (status) updates.status = status
    if (notes !== undefined) updates.notes = notes

    const { error } = await supabase.from('leads').update(updates).eq('id', id)
    if (error) throw error

    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
