import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { slugify, generatePropertyCode } from '@/lib/utils'

export async function POST(req: NextRequest) {
  const supabase = await createAdminClient()

  try {
    const formData = await req.formData()

    const title = formData.get('title') as string
    const slug = slugify(title) + '-' + Date.now()
    const code = generatePropertyCode()

    const propertyData: Record<string, any> = {
      code,
      slug,
      title,
      description: formData.get('description') || null,
      type: formData.get('type'),
      purpose: formData.get('purpose'),
      status: formData.get('status'),
      price: Number(formData.get('price')),
      condo_fee: formData.get('condo_fee') ? Number(formData.get('condo_fee')) : null,
      iptu: formData.get('iptu') ? Number(formData.get('iptu')) : null,
      city_id: formData.get('city_id') || null,
      neighborhood_id: formData.get('neighborhood_id') || null,
      address: formData.get('address') || null,
      address_number: formData.get('address_number') || null,
      zip_code: formData.get('zip_code') || null,
      latitude: formData.get('latitude') ? Number(formData.get('latitude')) : null,
      longitude: formData.get('longitude') ? Number(formData.get('longitude')) : null,
      bedrooms: Number(formData.get('bedrooms') || 0),
      suites: Number(formData.get('suites') || 0),
      bathrooms: Number(formData.get('bathrooms') || 0),
      parking_spots: Number(formData.get('parking_spots') || 0),
      private_area: formData.get('private_area') ? Number(formData.get('private_area')) : null,
      total_area: formData.get('total_area') ? Number(formData.get('total_area')) : null,
      floor: formData.get('floor') ? Number(formData.get('floor')) : null,
      total_floors: formData.get('total_floors') ? Number(formData.get('total_floors')) : null,
      year_built: formData.get('year_built') ? Number(formData.get('year_built')) : null,
      furnished: formData.get('furnished') === 'true',
      pet_friendly: formData.get('pet_friendly') === 'true',
      gated_community: formData.get('gated_community') === 'true',
      featured: formData.get('featured') === 'true',
      launch: formData.get('launch') === 'true',
      video_url: formData.get('video_url') || null,
      virtual_tour_url: formData.get('virtual_tour_url') || null,
      seo_title: formData.get('seo_title') || null,
      seo_description: formData.get('seo_description') || null,
      published_at: formData.get('status') === 'ativo' ? new Date().toISOString() : null,
    }

    const { data: property, error } = await supabase
      .from('properties')
      .insert(propertyData)
      .select()
      .single()

    if (error) throw error

    // Upload images
    const images = formData.getAll('images') as File[]
    for (let i = 0; i < images.length; i++) {
      const image = images[i]
      if (!image || image.size === 0) continue

      const ext = image.name.split('.').pop()
      const path = `properties/${property.id}/${Date.now()}-${i}.${ext}`

      const { data: uploaded, error: uploadError } = await supabase.storage
        .from('property-images')
        .upload(path, image, { upsert: true })

      if (!uploadError && uploaded) {
        const { data: { publicUrl } } = supabase.storage
          .from('property-images')
          .getPublicUrl(uploaded.path)

        await supabase.from('property_images').insert({
          property_id: property.id,
          url: publicUrl,
          position: i,
          is_cover: i === 0,
        })
      }
    }

    // Link amenities
    const amenities = formData.getAll('amenities') as string[]
    if (amenities.length > 0) {
      await supabase.from('property_amenities').insert(
        amenities.map(id => ({ property_id: property.id, amenity_id: id }))
      )
    }

    return NextResponse.json({ success: true, id: property.id, slug: property.slug })
  } catch (err: any) {
    console.error('Property creation error:', err)
    return NextResponse.json({ error: err.message || 'Erro interno' }, { status: 500 })
  }
}
