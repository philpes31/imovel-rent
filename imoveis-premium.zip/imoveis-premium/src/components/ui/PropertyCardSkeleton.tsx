export default function PropertyCardSkeleton() {
  return (
    <div className="bg-white border border-neutral-100 overflow-hidden animate-pulse">
      <div className="aspect-[4/3] bg-neutral-200" />
      <div className="p-5 space-y-3">
        <div className="h-5 bg-neutral-200 rounded w-2/3" />
        <div className="h-4 bg-neutral-100 rounded w-full" />
        <div className="h-3 bg-neutral-100 rounded w-1/2" />
        <div className="flex gap-3 pt-1 border-t border-neutral-100">
          <div className="h-3 bg-neutral-100 rounded w-12" />
          <div className="h-3 bg-neutral-100 rounded w-12" />
          <div className="h-3 bg-neutral-100 rounded w-16" />
        </div>
        <div className="flex gap-2 pt-1">
          <div className="h-8 bg-neutral-200 rounded flex-1" />
          <div className="h-8 w-10 bg-neutral-200 rounded" />
        </div>
      </div>
    </div>
  )
}

export function PropertyGridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {Array.from({ length: count }).map((_, i) => (
        <PropertyCardSkeleton key={i} />
      ))}
    </div>
  )
}
