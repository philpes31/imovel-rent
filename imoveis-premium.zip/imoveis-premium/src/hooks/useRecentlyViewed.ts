'use client'

import { useState, useEffect, useCallback } from 'react'

const KEY = 'premiumsc_recently_viewed'
const MAX = 8

export interface RecentlyViewedItem {
  id: string
  slug: string
  title: string
  price: number
  purpose: string
  coverImage?: string
  city?: string
  bedrooms?: number
  private_area?: number
  viewedAt: number
}

export function useRecentlyViewed() {
  const [items, setItems] = useState<RecentlyViewedItem[]>([])

  useEffect(() => {
    try {
      const stored = localStorage.getItem(KEY)
      if (stored) setItems(JSON.parse(stored))
    } catch {}
  }, [])

  const add = useCallback((item: Omit<RecentlyViewedItem, 'viewedAt'>) => {
    setItems(prev => {
      const filtered = prev.filter(i => i.id !== item.id)
      const next = [{ ...item, viewedAt: Date.now() }, ...filtered].slice(0, MAX)
      try { localStorage.setItem(KEY, JSON.stringify(next)) } catch {}
      return next
    })
  }, [])

  const clear = useCallback(() => {
    setItems([])
    try { localStorage.removeItem(KEY) } catch {}
  }, [])

  return { items, add, clear }
}
