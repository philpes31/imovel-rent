import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateSitemapXml } from '@/lib/utils'

export async function GET() {
  const supabase = await createClient()

  const { data: properties } = await supabase
    .from('properties')
    .select('slug, updated_at')
    .eq('status', 'ativo')
    .order('updated_at', { ascending: false })

  const xml = generateSitemapXml((properties || []) as any[])

  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  })
}
