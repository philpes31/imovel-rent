import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import { createClient } from '@/lib/supabase/server'

export const metadata: Metadata = {
  title: 'Blog Imobiliário | PremiumSC',
  description: 'Dicas, tendências e novidades do mercado imobiliário de Santa Catarina.',
}

export const revalidate = 600

export default async function BlogPage() {
  const supabase = await createClient()
  const { data: posts } = await supabase
    .from('blog_posts')
    .select('id, title, slug, excerpt, cover_image, published_at, author:agents(name, photo_url)')
    .eq('published', true)
    .order('published_at', { ascending: false })

  // Static fallback posts for when DB is empty
  const fallbackPosts = [
    { id: '1', title: 'Balneário Camboriú: por que é o melhor lugar para investir em imóveis?', slug: 'balneario-camboriu-investimento', excerpt: 'Entenda o que torna a "Dubai brasileira" o destino mais valorizado do mercado imobiliário catarinense.', published_at: '2025-03-01', cover_image: null },
    { id: '2', title: '5 dicas para valorizar seu imóvel antes de vender', slug: 'valorizar-imovel-antes-vender', excerpt: 'Pequenas melhorias podem aumentar o valor de venda do seu imóvel em até 20%. Confira as principais estratégias.', published_at: '2025-02-15', cover_image: null },
    { id: '3', title: 'Documentação para compra de imóvel: guia completo', slug: 'documentacao-compra-imovel', excerpt: 'Saiba quais documentos são necessários para comprar um imóvel em Santa Catarina sem surpresas.', published_at: '2025-02-01', cover_image: null },
    { id: '4', title: 'Mercado imobiliário de SC em 2025: tendências e perspectivas', slug: 'mercado-imobiliario-sc-2025', excerpt: 'Especialistas apontam forte crescimento nas cidades litorâneas e aumento na busca por imóveis compactos.', published_at: '2025-01-20', cover_image: null },
    { id: '5', title: 'Aluguel por temporada: vale a pena investir?', slug: 'aluguel-por-temporada', excerpt: 'Com o crescimento do turismo em SC, o aluguel por temporada pode ser um excelente investimento. Veja como funciona.', published_at: '2025-01-10', cover_image: null },
    { id: '6', title: 'Como escolher o bairro ideal para morar em Blumenau', slug: 'bairros-blumenau', excerpt: 'Um guia completo sobre os principais bairros de Blumenau: infraestrutura, segurança e qualidade de vida.', published_at: '2024-12-20', cover_image: null },
  ]

  const allPosts = (posts && posts.length > 0) ? posts : fallbackPosts
  const featured = allPosts[0]
  const rest = allPosts.slice(1)

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">

        {/* Header */}
        <div className="bg-[#0A1628] py-14 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase font-medium mb-3">Conteúdo</p>
            <h1 className="font-serif text-4xl font-bold text-white mb-4">Blog Imobiliário</h1>
            <div className="w-12 h-0.5 bg-[#C9A84C] mx-auto mb-4" />
            <p className="text-neutral-400">Dicas, tendências e novidades do mercado imobiliário de SC</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

          {/* Featured post */}
          {featured && (
            <div className="mb-12">
              <Link href={`/blog/${featured.slug}`} className="group grid md:grid-cols-2 bg-white border border-neutral-200 overflow-hidden hover:border-[#C9A84C] transition-colors">
                <div className="h-64 md:h-auto bg-neutral-200 relative overflow-hidden">
                  {featured.cover_image ? (
                    <Image src={featured.cover_image} alt={featured.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" sizes="50vw" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-[#0A1628] to-[#1a2d4a] flex items-center justify-center">
                      <span className="text-5xl">🏡</span>
                    </div>
                  )}
                  <span className="absolute top-4 left-4 bg-[#C9A84C] text-white text-xs px-3 py-1 font-medium">Destaque</span>
                </div>
                <div className="p-8 flex flex-col justify-center">
                  <p className="text-neutral-400 text-xs mb-3">
                    {new Date(featured.published_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}
                  </p>
                  <h2 className="font-serif text-2xl font-bold text-[#0A1628] mb-3 leading-tight group-hover:text-[#C9A84C] transition-colors">
                    {featured.title}
                  </h2>
                  {featured.excerpt && (
                    <p className="text-neutral-500 text-sm leading-relaxed mb-4">{featured.excerpt}</p>
                  )}
                  <span className="text-[#C9A84C] text-sm font-medium">Ler artigo →</span>
                </div>
              </Link>
            </div>
          )}

          {/* Grid */}
          {rest.length > 0 && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {rest.map((post: any) => (
                <Link
                  key={post.id}
                  href={`/blog/${post.slug}`}
                  className="group bg-white border border-neutral-200 overflow-hidden hover:border-[#C9A84C] transition-colors hover:-translate-y-1 hover:shadow-lg transition-all duration-300"
                >
                  <div className="h-44 bg-neutral-200 relative overflow-hidden">
                    {post.cover_image ? (
                      <Image src={post.cover_image} alt={post.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" sizes="33vw" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-neutral-800 to-neutral-900 flex items-center justify-center">
                        <span className="text-4xl">📰</span>
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <p className="text-neutral-400 text-xs mb-2">
                      {new Date(post.published_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </p>
                    <h3 className="font-serif font-bold text-[#0A1628] text-sm leading-snug mb-2 line-clamp-2 group-hover:text-[#C9A84C] transition-colors">
                      {post.title}
                    </h3>
                    {post.excerpt && (
                      <p className="text-neutral-500 text-xs leading-relaxed line-clamp-2">{post.excerpt}</p>
                    )}
                    <span className="inline-block text-[#C9A84C] text-xs font-medium mt-3">Ler mais →</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
