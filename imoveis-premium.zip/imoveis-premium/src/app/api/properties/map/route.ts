import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const supabase = await createClient()
  const { searchParams } = new URL(req.url)
  const purpose = searchParams.get('purpose')

  let query = supabase
    .from('properties')
    .select(`
      id, title, slug, price, purpose, type, bedrooms, private_area,
      latitude, longitude,
      city:cities(name),
      neighborhood:neighborhoods(name),
      images:property_images(url, is_cover)
    `)
    .eq('status', 'ativo')
    .not('latitude', 'is', null)
    .not('longitude', 'is', null)
    .limit(200)

  if (purpose && purpose !== 'all') {
    query = query.eq('purpose', purpose)
  }

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json(data, {
    headers: { 'Cache-Control': 'public, max-age=300' },
  })
}
