export type PropertyType = 'apartamento' | 'casa' | 'terreno' | 'comercial' | 'cobertura' | 'studio' | 'flat' | 'chacara'
export type PropertyPurpose = 'venda' | 'aluguel' | 'lancamento'
export type PropertyStatus = 'ativo' | 'vendido' | 'alugado' | 'inativo' | 'rascunho'
export type LeadStatus = 'novo' | 'contato' | 'negociando' | 'convertido' | 'perdido'
export type LeadSource = 'site' | 'whatsapp' | 'telefone' | 'email' | 'indicacao' | 'portal'

export interface City {
  id: string
  name: string
  state: string
  slug: string
  image_url?: string
  property_count: number
}

export interface Neighborhood {
  id: string
  name: string
  slug: string
  city_id: string
  city?: City
}

export interface Amenity {
  id: string
  name: string
  icon?: string
  category?: string
}

export interface Agent {
  id: string
  name: string
  email: string
  phone?: string
  whatsapp?: string
  creci?: string
  photo_url?: string
  bio?: string
  active: boolean
}

export interface PropertyImage {
  id: string
  property_id: string
  url: string
  alt?: string
  position: number
  is_cover: boolean
}

export interface Property {
  id: string
  code: string
  title: string
  slug: string
  description?: string
  type: PropertyType
  purpose: PropertyPurpose
  status: PropertyStatus
  price: number
  condo_fee?: number
  iptu?: number
  city_id: string
  neighborhood_id?: string
  address?: string
  address_number?: string
  address_complement?: string
  zip_code?: string
  latitude?: number
  longitude?: number
  bedrooms: number
  suites: number
  bathrooms: number
  parking_spots: number
  private_area?: number
  total_area?: number
  floor?: number
  total_floors?: number
  year_built?: number
  furnished: boolean
  pet_friendly: boolean
  gated_community: boolean
  featured: boolean
  launch: boolean
  views_count: number
  agent_id?: string
  video_url?: string
  virtual_tour_url?: string
  seo_title?: string
  seo_description?: string
  published_at?: string
  created_at: string
  updated_at: string
  // Relations
  city?: City
  neighborhood?: Neighborhood
  agent?: Agent
  images?: PropertyImage[]
  amenities?: Amenity[]
}

export interface Lead {
  id: string
  property_id?: string
  agent_id?: string
  name: string
  email?: string
  phone: string
  message?: string
  source: LeadSource
  status: LeadStatus
  notes?: string
  created_at: string
  updated_at: string
  property?: Property
  agent?: Agent
}

export interface SearchFilters {
  purpose?: PropertyPurpose
  type?: PropertyType
  city_id?: string
  neighborhood_id?: string
  min_price?: number
  max_price?: number
  bedrooms?: number
  suites?: number
  parking_spots?: number
  min_area?: number
  max_area?: number
  furnished?: boolean
  pet_friendly?: boolean
  gated_community?: boolean
  pool?: boolean
  page?: number
  per_page?: number
  sort?: 'price_asc' | 'price_desc' | 'newest' | 'most_viewed'
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  per_page: number
  total_pages: number
}

export interface DashboardStats {
  total_properties: number
  active_properties: number
  sold_properties: number
  total_leads: number
  new_leads: number
  total_views: number
  monthly_leads: number
}
