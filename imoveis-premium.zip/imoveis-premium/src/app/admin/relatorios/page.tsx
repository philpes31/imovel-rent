import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { formatPrice } from '@/lib/utils'

export default async function AdminRelatoriosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const now = new Date()
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString()
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString()

  const [
    { data: propertiesByType },
    { data: propertiesByCity },
    { data: leadsLast30 },
    { data: leadsLast7 },
    { data: topViewedProperties },
    { data: leadsByStatus },
    { data: leadsBySource },
  ] = await Promise.all([
    supabase
      .from('properties')
      .select('type')
      .eq('status', 'ativo'),
    supabase
      .from('properties')
      .select('city_id, city:cities(name)')
      .eq('status', 'ativo'),
    supabase
      .from('leads')
      .select('id', { count: 'exact', head: true })
      .gte('created_at', thirtyDaysAgo),
    supabase
      .from('leads')
      .select('id', { count: 'exact', head: true })
      .gte('created_at', sevenDaysAgo),
    supabase
      .from('properties')
      .select('id, title, slug, views_count, price, purpose, city:cities(name)')
      .eq('status', 'ativo')
      .order('views_count', { ascending: false })
      .limit(10),
    supabase
      .from('leads')
      .select('status'),
    supabase
      .from('leads')
      .select('source'),
  ])

  // Aggregate by type
  const typeCount: Record<string, number> = {}
  propertiesByType?.forEach((p: any) => {
    typeCount[p.type] = (typeCount[p.type] || 0) + 1
  })

  // Aggregate by city
  const cityCount: Record<string, number> = {}
  propertiesByCity?.forEach((p: any) => {
    const name = p.city?.name || 'Outros'
    cityCount[name] = (cityCount[name] || 0) + 1
  })

  // Aggregate leads by status
  const statusCount: Record<string, number> = {}
  leadsByStatus?.forEach((l: any) => {
    statusCount[l.status] = (statusCount[l.status] || 0) + 1
  })

  // Aggregate leads by source
  const sourceCount: Record<string, number> = {}
  leadsBySource?.forEach((l: any) => {
    sourceCount[l.source] = (sourceCount[l.source] || 0) + 1
  })

  const totalLeads = leadsByStatus?.length || 0
  const totalProperties = propertiesByType?.length || 0

  const Bar = ({ value, max, color = 'bg-[#C9A84C]' }: { value: number; max: number; color?: string }) => (
    <div className="flex-1 bg-neutral-100 h-2 rounded-full overflow-hidden">
      <div
        className={`h-full ${color} rounded-full transition-all`}
        style={{ width: `${max > 0 ? (value / max) * 100 : 0}%` }}
      />
    </div>
  )

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-serif text-2xl font-bold text-[#0A1628]">Relatórios</h1>
        <p className="text-neutral-500 text-sm mt-0.5">Análise de desempenho da plataforma</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Imóveis ativos', value: totalProperties, sub: 'Total no catálogo', color: 'text-blue-600' },
          { label: 'Leads (30 dias)', value: leadsLast30?.length ?? 0, sub: 'Novos contatos', color: 'text-green-600' },
          { label: 'Leads (7 dias)', value: leadsLast7?.length ?? 0, sub: 'Esta semana', color: 'text-orange-500' },
          { label: 'Total leads', value: totalLeads, sub: 'Histórico completo', color: 'text-[#0A1628]' },
        ].map(card => (
          <div key={card.label} className="bg-white border border-neutral-200 p-5">
            <p className={`font-serif text-3xl font-bold ${card.color}`}>{card.value}</p>
            <p className="text-neutral-700 text-sm font-medium mt-1">{card.label}</p>
            <p className="text-neutral-400 text-xs mt-0.5">{card.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mb-6">
        {/* Properties by type */}
        <div className="bg-white border border-neutral-200 p-6">
          <h2 className="font-serif font-bold text-[#0A1628] mb-4">Imóveis por Tipo</h2>
          <div className="space-y-3">
            {Object.entries(typeCount)
              .sort(([, a], [, b]) => b - a)
              .map(([type, count]) => (
                <div key={type} className="flex items-center gap-3">
                  <span className="text-xs text-neutral-600 capitalize w-24 flex-shrink-0">{type}</span>
                  <Bar value={count} max={totalProperties} />
                  <span className="text-xs font-medium text-neutral-700 w-8 text-right">{count}</span>
                </div>
              ))}
          </div>
        </div>

        {/* Properties by city */}
        <div className="bg-white border border-neutral-200 p-6">
          <h2 className="font-serif font-bold text-[#0A1628] mb-4">Imóveis por Cidade</h2>
          <div className="space-y-3">
            {Object.entries(cityCount)
              .sort(([, a], [, b]) => b - a)
              .map(([city, count]) => (
                <div key={city} className="flex items-center gap-3">
                  <span className="text-xs text-neutral-600 w-28 flex-shrink-0 truncate">{city}</span>
                  <Bar value={count} max={totalProperties} color="bg-[#0A1628]" />
                  <span className="text-xs font-medium text-neutral-700 w-8 text-right">{count}</span>
                </div>
              ))}
          </div>
        </div>

        {/* Leads by status */}
        <div className="bg-white border border-neutral-200 p-6">
          <h2 className="font-serif font-bold text-[#0A1628] mb-4">Leads por Status</h2>
          <div className="space-y-3">
            {[
              { key: 'novo', label: 'Novo', color: 'bg-blue-400' },
              { key: 'contato', label: 'Em contato', color: 'bg-yellow-400' },
              { key: 'negociando', label: 'Negociando', color: 'bg-purple-400' },
              { key: 'convertido', label: 'Convertido', color: 'bg-green-500' },
              { key: 'perdido', label: 'Perdido', color: 'bg-red-400' },
            ].map(({ key, label, color }) => {
              const count = statusCount[key] || 0
              return (
                <div key={key} className="flex items-center gap-3">
                  <span className="text-xs text-neutral-600 w-24 flex-shrink-0">{label}</span>
                  <Bar value={count} max={totalLeads} color={color} />
                  <span className="text-xs font-medium text-neutral-700 w-8 text-right">{count}</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Top viewed properties */}
        <div className="bg-white border border-neutral-200">
          <div className="px-5 py-4 border-b border-neutral-100">
            <h2 className="font-serif font-bold text-[#0A1628]">Imóveis Mais Vistos</h2>
          </div>
          <div className="divide-y divide-neutral-100">
            {(topViewedProperties || []).map((p: any, i: number) => (
              <div key={p.id} className="flex items-center gap-3 px-5 py-3 hover:bg-neutral-50 transition-colors">
                <span className="text-neutral-400 text-xs font-mono w-5">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#0A1628] truncate">{p.title}</p>
                  <p className="text-xs text-neutral-400">{p.city?.name} · {formatPrice(p.price, p.purpose)}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-bold text-[#0A1628]">{p.views_count}</p>
                  <p className="text-xs text-neutral-400">views</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Leads by source */}
        <div className="bg-white border border-neutral-200 p-6">
          <h2 className="font-serif font-bold text-[#0A1628] mb-4">Origem dos Leads</h2>
          <div className="space-y-4">
            {Object.entries(sourceCount)
              .sort(([, a], [, b]) => b - a)
              .map(([source, count]) => {
                const pct = totalLeads > 0 ? Math.round((count / totalLeads) * 100) : 0
                return (
                  <div key={source}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 capitalize">{source}</span>
                      <span className="text-sm font-bold text-[#0A1628]">{count} <span className="text-neutral-400 font-normal">({pct}%)</span></span>
                    </div>
                    <div className="bg-neutral-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#C9A84C] rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                )
              })}
          </div>

          {/* Quick export */}
          <div className="mt-6 pt-4 border-t border-neutral-100">
            <a
              href="/api/admin/leads/export"
              className="flex items-center gap-2 text-sm text-[#0A1628] hover:text-[#C9A84C] font-medium transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Exportar todos os leads (CSV)
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
