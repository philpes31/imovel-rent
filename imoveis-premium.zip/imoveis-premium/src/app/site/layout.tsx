// This layout wraps all (site) routes.
// Header and Footer are included per-page so each page can control
// hero transparency and other layout details independently.
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
