import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import { createClient } from '@/lib/supabase/server'
import { getProperties } from '@/lib/queries'

interface Props {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const supabase = await createClient()
  const { data: city } = await supabase.from('cities').select('*').eq('slug', slug).single()
  if (!city) return { title: 'Cidade não encontrada' }

  return {
    title: `Imóveis em ${city.name} | PremiumSC`,
    description: `Apartamentos, casas e coberturas à venda e para alugar em ${city.name}, ${city.state}. Encontre o imóvel ideal com a PremiumSC.`,
  }
}

export default async function CityPage({ params }: Props) {
  const { slug } = await params
  const supabase = await createClient()

  const { data: city } = await supabase.from('cities').select('*').eq('slug', slug).single()
  if (!city) notFound()

  const { data: properties, total } = await getProperties({ city_id: city.id, per_page: 12 })

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">
        {/* Hero */}
        <div className="bg-[#0A1628] py-16 px-4">
          <div className="max-w-7xl mx-auto text-center">
            <p className="text-[#C9A84C] text-sm font-medium tracking-widest uppercase mb-3">
              {city.state}
            </p>
            <h1 className="font-serif text-4xl sm:text-5xl font-bold text-white mb-3">
              Imóveis em {city.name}
            </h1>
            <div className="w-16 h-0.5 bg-[#C9A84C] mx-auto mb-4" />
            <p className="text-neutral-400">
              {total} imóveis disponíveis
            </p>
          </div>
        </div>

        {/* Properties */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {properties.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {properties.map(p => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 text-neutral-400">
              <p className="text-lg font-serif">Nenhum imóvel disponível em {city.name} no momento.</p>
            </div>
          )}
        </div>

        {/* SEO content */}
        <div className="bg-neutral-50 py-12">
          <div className="max-w-3xl mx-auto px-4 sm:px-6">
            <h2 className="font-serif text-2xl font-bold text-[#0A1628] mb-4">
              Sobre o mercado imobiliário em {city.name}
            </h2>
            <div className="w-8 h-0.5 bg-[#C9A84C] mb-6" />
            <p className="text-neutral-600 leading-relaxed mb-4">
              {city.name} é um dos destinos mais procurados para compra e aluguel de imóveis em Santa Catarina.
              A cidade oferece excelente qualidade de vida, infraestrutura completa e um mercado imobiliário
              em constante crescimento.
            </p>
            <p className="text-neutral-600 leading-relaxed">
              A PremiumSC possui uma ampla seleção de apartamentos, casas, coberturas e terrenos em {city.name},
              atendendo desde quem busca o primeiro imóvel até investidores experientes.
            </p>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
