-- Enable extensions
create extension if not exists "uuid-ossp";
create extension if not exists "postgis";

-- Cities
create table cities (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  state text not null default 'SC',
  slug text unique not null,
  image_url text,
  property_count int default 0,
  created_at timestamptz default now()
);

-- Neighborhoods
create table neighborhoods (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null,
  city_id uuid references cities(id) on delete cascade,
  created_at timestamptz default now(),
  unique(slug, city_id)
);

-- Amenities
create table amenities (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  icon text,
  category text
);

-- Agents
create table agents (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id),
  name text not null,
  email text unique not null,
  phone text,
  whatsapp text,
  creci text,
  photo_url text,
  bio text,
  active boolean default true,
  created_at timestamptz default now()
);

-- Properties
create table properties (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  title text not null,
  slug text unique not null,
  description text,
  type text not null check (type in ('apartamento','casa','terreno','comercial','cobertura','studio','flat','chacara')),
  purpose text not null check (purpose in ('venda','aluguel','lancamento')),
  status text not null default 'ativo' check (status in ('ativo','vendido','alugado','inativo','rascunho')),
  price numeric(15,2) not null,
  condo_fee numeric(10,2),
  iptu numeric(10,2),
  city_id uuid references cities(id),
  neighborhood_id uuid references neighborhoods(id),
  address text,
  address_number text,
  address_complement text,
  zip_code text,
  latitude numeric(10,8),
  longitude numeric(11,8),
  bedrooms int default 0,
  suites int default 0,
  bathrooms int default 0,
  parking_spots int default 0,
  private_area numeric(10,2),
  total_area numeric(10,2),
  floor int,
  total_floors int,
  year_built int,
  furnished boolean default false,
  pet_friendly boolean default false,
  gated_community boolean default false,
  featured boolean default false,
  launch boolean default false,
  views_count int default 0,
  agent_id uuid references agents(id),
  video_url text,
  virtual_tour_url text,
  seo_title text,
  seo_description text,
  published_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Property images
create table property_images (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid references properties(id) on delete cascade,
  url text not null,
  alt text,
  position int default 0,
  is_cover boolean default false,
  created_at timestamptz default now()
);

-- Property amenities (junction)
create table property_amenities (
  property_id uuid references properties(id) on delete cascade,
  amenity_id uuid references amenities(id) on delete cascade,
  primary key (property_id, amenity_id)
);

-- Leads
create table leads (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid references properties(id),
  agent_id uuid references agents(id),
  name text not null,
  email text,
  phone text not null,
  message text,
  source text default 'site' check (source in ('site','whatsapp','telefone','email','indicacao','portal')),
  status text default 'novo' check (status in ('novo','contato','negociando','convertido','perdido')),
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Favorites
create table favorites (
  user_id uuid references auth.users(id) on delete cascade,
  property_id uuid references properties(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, property_id)
);

-- Blog posts
create table blog_posts (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text unique not null,
  excerpt text,
  content text,
  cover_image text,
  author_id uuid references agents(id),
  published boolean default false,
  published_at timestamptz,
  seo_title text,
  seo_description text,
  created_at timestamptz default now()
);

-- Indexes
create index idx_properties_city on properties(city_id);
create index idx_properties_neighborhood on properties(neighborhood_id);
create index idx_properties_type on properties(type);
create index idx_properties_purpose on properties(purpose);
create index idx_properties_status on properties(status);
create index idx_properties_price on properties(price);
create index idx_properties_featured on properties(featured);
create index idx_properties_slug on properties(slug);
create index idx_leads_property on leads(property_id);
create index idx_leads_status on leads(status);

-- Update timestamp trigger
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger properties_updated_at before update on properties
  for each row execute function update_updated_at();
create trigger leads_updated_at before update on leads
  for each row execute function update_updated_at();

-- RLS
alter table properties enable row level security;
alter table property_images enable row level security;
alter table leads enable row level security;
alter table agents enable row level security;
alter table favorites enable row level security;

-- Public read for active properties
create policy "Public can view active properties" on properties
  for select using (status = 'ativo' or status = 'lancamento');

create policy "Public can view property images" on property_images
  for select using (true);

create policy "Public can view agents" on agents
  for select using (active = true);

-- Authenticated users can manage favorites
create policy "Users manage own favorites" on favorites
  for all using (auth.uid() = user_id);

-- Admin full access (via service role or admin check)
create policy "Admins full access properties" on properties
  for all using (auth.jwt() ->> 'role' = 'admin');

create policy "Admins full access leads" on leads
  for all using (auth.jwt() ->> 'role' = 'admin');

-- Seed cities
insert into cities (name, state, slug) values
  ('Balneário Camboriú', 'SC', 'balneario-camboriu'),
  ('Itapema', 'SC', 'itapema'),
  ('Blumenau', 'SC', 'blumenau'),
  ('Itajaí', 'SC', 'itajai'),
  ('Florianópolis', 'SC', 'florianopolis');

-- Seed amenities
insert into amenities (name, icon, category) values
  ('Piscina', 'pool', 'lazer'),
  ('Academia', 'gym', 'lazer'),
  ('Churrasqueira', 'bbq', 'lazer'),
  ('Elevador', 'elevator', 'estrutura'),
  ('Portaria 24h', 'security', 'seguranca'),
  ('Salão de Festas', 'party', 'lazer'),
  ('Playground', 'play', 'lazer'),
  ('Quadra Esportiva', 'sport', 'lazer'),
  ('Sauna', 'sauna', 'lazer'),
  ('Coworking', 'work', 'servico'),
  ('Jardim', 'garden', 'estrutura'),
  ('Varanda Gourmet', 'balcony', 'estrutura'),
  ('Ar Condicionado', 'ac', 'conforto'),
  ('Aquecimento Solar', 'solar', 'conforto'),
  ('Câmeras de Segurança', 'camera', 'seguranca'),
  ('Interfone', 'intercom', 'seguranca'),
  ('Bicicletário', 'bike', 'servico'),
  ('Pet Friendly', 'pet', 'servico');
