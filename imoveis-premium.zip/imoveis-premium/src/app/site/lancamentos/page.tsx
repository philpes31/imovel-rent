import type { Metadata } from 'next'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import WhatsAppFloat from '@/components/layout/WhatsAppFloat'
import PropertyCard from '@/components/property/PropertyCard'
import { getLaunchProperties, getCities } from '@/lib/queries'

export const metadata: Metadata = {
  title: 'Lançamentos Imobiliários em SC | PremiumSC',
  description:
    'Conheça os mais novos lançamentos imobiliários em Balneário Camboriú, Itapema e demais cidades de Santa Catarina.',
}

export const revalidate = 300

export default async function LancamentosPage() {
  const properties = await getLaunchProperties(12)

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen">
        {/* Hero */}
        <div className="relative bg-[#0A1628] py-20 px-4 overflow-hidden">
          <div
            className="absolute inset-0 opacity-10"
            style={{ backgroundImage: 'radial-gradient(circle at 70% 50%, #C9A84C 0%, transparent 60%)' }}
          />
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <span className="inline-block bg-[#C9A84C] text-[#0A1628] text-xs font-bold px-4 py-1.5 tracking-widest uppercase mb-5">
              Novidades
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl font-bold text-white mb-4">
              Lançamentos
            </h1>
            <div className="w-16 h-0.5 bg-[#C9A84C] mx-auto mb-5" />
            <p className="text-neutral-400 max-w-xl mx-auto">
              Os melhores lançamentos imobiliários de Santa Catarina. Seja o primeiro a investir nas
              melhores oportunidades.
            </p>
          </div>
        </div>

        {/* Benefits strip */}
        <div className="bg-[#C9A84C]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-wrap items-center justify-center gap-8 text-[#0A1628] text-sm font-medium">
              {[
                '✓ Condições especiais de lançamento',
                '✓ Planta para personalizar',
                '✓ Menor preço por m²',
                '✓ Valorização garantida',
              ].map(b => <span key={b}>{b}</span>)}
            </div>
          </div>
        </div>

        {/* Listings */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
          {properties.length > 0 ? (
            <>
              <p className="text-neutral-500 text-sm mb-6">{properties.length} lançamentos disponíveis</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {properties.map(p => <PropertyCard key={p.id} property={p} />)}
              </div>
            </>
          ) : (
            <div className="text-center py-24">
              <p className="font-serif text-2xl text-neutral-400">Em breve novos lançamentos</p>
              <p className="text-neutral-400 text-sm mt-2">Cadastre-se para ser avisado</p>
              <a href="/contato" className="inline-block mt-6 bg-[#0A1628] text-white px-8 py-3 text-sm font-medium hover:bg-[#1a2d4a] transition-colors">
                Quero ser avisado
              </a>
            </div>
          )}
        </div>

        {/* CTA register interest */}
        <div className="bg-neutral-100 py-14">
          <div className="max-w-2xl mx-auto px-4 text-center">
            <h2 className="font-serif text-2xl font-bold text-[#0A1628] mb-3">
              Quer saber primeiro sobre novos lançamentos?
            </h2>
            <p className="text-neutral-500 text-sm mb-6">
              Cadastre seu interesse e nossa equipe entrará em contato assim que houver novidades.
            </p>
            <a
              href={`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '5547999999999'}?text=Olá! Quero receber informações sobre lançamentos imobiliários.`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-sm font-medium transition-colors"
            >
              Cadastrar interesse via WhatsApp
            </a>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
