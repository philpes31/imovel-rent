'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'

interface Agent {
  id?: string
  name?: string
  email?: string
  phone?: string
  whatsapp?: string
  creci?: string
  bio?: string
  photo_url?: string
  active?: boolean
}

interface Props {
  agent?: Agent
}

export default function AgentForm({ agent }: Props) {
  const router = useRouter()
  const fileRef = useRef<HTMLInputElement>(null)
  const [form, setForm] = useState({
    name: agent?.name || '',
    email: agent?.email || '',
    phone: agent?.phone || '',
    whatsapp: agent?.whatsapp || '',
    creci: agent?.creci || '',
    bio: agent?.bio || '',
    active: agent?.active ?? true,
  })
  const [photo, setPhoto] = useState<File | null>(null)
  const [photoPreview, setPhotoPreview] = useState(agent?.photo_url || '')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  function handlePhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setPhoto(file)
    const reader = new FileReader()
    reader.onload = ev => setPhotoPreview(ev.target?.result as string)
    reader.readAsDataURL(file)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const fd = new FormData()
      Object.entries(form).forEach(([k, v]) => fd.append(k, String(v)))
      if (photo) fd.append('photo', photo)

      const url = agent?.id ? `/api/admin/agents/${agent.id}` : '/api/admin/agents'
      const method = agent?.id ? 'PUT' : 'POST'
      const res = await fetch(url, { method, body: fd })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Erro ao salvar')
      }
      router.push('/admin/corretores')
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const inputCls = "w-full border border-neutral-200 px-3 py-2.5 text-sm focus:outline-none focus:border-[#C9A84C]"

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 text-sm mb-5">{error}</div>
      )}

      <div className="bg-white border border-neutral-200 p-6 mb-5">
        <h3 className="font-serif font-bold text-[#0A1628] mb-5 pb-3 border-b border-neutral-100">Dados do Corretor</h3>

        {/* Photo */}
        <div className="flex items-center gap-5 mb-6">
          <div
            className="w-20 h-20 rounded-full bg-neutral-100 overflow-hidden cursor-pointer border-2 border-dashed border-neutral-300 hover:border-[#C9A84C] transition-colors flex items-center justify-center"
            onClick={() => fileRef.current?.click()}
          >
            {photoPreview ? (
              <img src={photoPreview} alt="" className="w-full h-full object-cover" />
            ) : (
              <span className="text-2xl">👤</span>
            )}
          </div>
          <div>
            <button type="button" onClick={() => fileRef.current?.click()} className="text-sm text-[#0A1628] font-medium hover:text-[#C9A84C] transition-colors">
              {photoPreview ? 'Trocar foto' : 'Adicionar foto'}
            </button>
            <p className="text-xs text-neutral-400 mt-0.5">JPG ou PNG, máx. 2MB</p>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Nome completo *</label>
            <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={inputCls} placeholder="Nome do corretor" />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">E-mail *</label>
            <input required type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className={inputCls} placeholder="corretor@email.com" />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">CRECI</label>
            <input value={form.creci} onChange={e => setForm(f => ({ ...f, creci: e.target.value }))} className={inputCls} placeholder="12345" />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Telefone</label>
            <input type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className={inputCls} placeholder="(47) 3333-3333" />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">WhatsApp</label>
            <input type="tel" value={form.whatsapp} onChange={e => setForm(f => ({ ...f, whatsapp: e.target.value }))} className={inputCls} placeholder="(47) 99999-9999" />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-neutral-600 mb-1.5 uppercase tracking-wide">Bio</label>
            <textarea rows={3} value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} className={`${inputCls} resize-none`} placeholder="Apresentação do corretor..." />
          </div>
          <div className="sm:col-span-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} className="w-4 h-4 accent-[#C9A84C]" />
              <span className="text-sm text-neutral-700">Corretor ativo (aparece no site)</span>
            </label>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <button type="button" onClick={() => router.back()} className="text-sm text-neutral-500 hover:text-neutral-800 transition-colors">
          ← Cancelar
        </button>
        <button
          type="submit"
          disabled={loading}
          className="bg-[#C9A84C] text-white px-6 py-2.5 text-sm font-medium hover:bg-[#b8963e] transition-colors disabled:opacity-50"
        >
          {loading ? 'Salvando...' : agent?.id ? 'Atualizar corretor' : 'Cadastrar corretor'}
        </button>
      </div>
    </form>
  )
}
