import Link from 'next/link'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'

export default function NotFound() {
  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="font-serif text-[120px] font-bold text-neutral-200 leading-none select-none">
            404
          </div>
          <h1 className="font-serif text-2xl font-bold text-[#0A1628] mb-3 -mt-4">
            Página não encontrada
          </h1>
          <div className="w-10 h-0.5 bg-[#C9A84C] mx-auto mb-5" />
          <p className="text-neutral-500 text-sm mb-8 leading-relaxed">
            O imóvel ou página que você procura não existe ou foi removido.
            Explore nosso catálogo completo de imóveis.
          </p>
          <div className="flex gap-3 justify-center">
            <Link
              href="/site"
              className="bg-[#0A1628] text-white px-6 py-3 text-sm font-medium hover:bg-[#1a2d4a] transition-colors"
            >
              Ir para o início
            </Link>
            <Link
              href="/site/imoveis"
              className="border border-neutral-300 text-neutral-700 px-6 py-3 text-sm font-medium hover:border-[#0A1628] transition-colors"
            >
              Ver imóveis
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
