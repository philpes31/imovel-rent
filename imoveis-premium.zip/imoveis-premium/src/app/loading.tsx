export default function Loading() {
  return (
    <div className="pt-16 min-h-screen bg-neutral-50">
      {/* Hero skeleton */}
      <div className="bg-[#0A1628] h-48 animate-pulse" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Cards skeleton */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-white border border-neutral-100">
              <div className="h-48 bg-neutral-200 animate-pulse" />
              <div className="p-5 space-y-3">
                <div className="h-5 bg-neutral-200 rounded animate-pulse w-2/3" />
                <div className="h-4 bg-neutral-100 rounded animate-pulse w-full" />
                <div className="h-4 bg-neutral-100 rounded animate-pulse w-1/2" />
                <div className="flex gap-3 pt-2">
                  <div className="h-8 bg-neutral-200 rounded animate-pulse flex-1" />
                  <div className="h-8 w-10 bg-neutral-200 rounded animate-pulse" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
