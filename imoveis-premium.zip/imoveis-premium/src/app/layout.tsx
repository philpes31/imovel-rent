import type { Metadata } from 'next'
import { Playfair_Display, DM_Sans } from 'next/font/google'
import './globals.css'
import Providers from '@/components/layout/Providers'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://imoveis.com.br'),
  title: {
    default: 'Imóveis Premium SC | Venda e Aluguel em Santa Catarina',
    template: '%s | PremiumSC',
  },
  description: 'Encontre o imóvel dos seus sonhos em Balneário Camboriú, Itapema, Blumenau, Itajaí e Florianópolis.',
  keywords: ['imóveis', 'apartamentos', 'casas', 'balneário camboriú', 'santa catarina', 'venda', 'aluguel'],
  openGraph: { type: 'website', locale: 'pt_BR', siteName: 'PremiumSC' },
  twitter: { card: 'summary_large_image' },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${playfair.variable} ${dmSans.variable}`}>
      <body className="font-sans antialiased bg-white text-neutral-900">
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  )
}
