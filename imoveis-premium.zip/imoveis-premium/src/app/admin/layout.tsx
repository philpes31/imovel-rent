import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

const NAV = [
  { href: '/admin/dashboard', label: 'Dashboard', icon: '📊' },
  { href: '/admin/imoveis', label: 'Imóveis', icon: '🏠' },
  { href: '/admin/leads', label: 'Leads', icon: '📩' },
  { href: '/admin/corretores', label: 'Corretores', icon: '👥' },
  { href: '/admin/blog', label: 'Blog', icon: '✍️' },
  { href: '/admin/relatorios', label: 'Relatórios', icon: '📈' },
]

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  return (
    <div className="min-h-screen bg-neutral-50 flex">
      <aside className="w-60 bg-[#0A1628] flex flex-col flex-shrink-0 fixed top-0 bottom-0 left-0 z-30 overflow-y-auto">
        <div className="p-5 border-b border-white/10 flex-shrink-0">
          <Link href="/site" className="flex items-center gap-2">
            <div className="w-7 h-7 bg-[#C9A84C] flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
                <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z"/>
              </svg>
            </div>
            <span className="font-serif text-white font-bold">Premium<span className="text-[#C9A84C]">SC</span></span>
          </Link>
          <p className="text-neutral-500 text-xs mt-1">Painel Admin</p>
        </div>

        <nav className="flex-1 p-3">
          {NAV.map(item => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 px-3 py-2.5 text-sm text-neutral-400 hover:text-white hover:bg-white/10 transition-colors mb-0.5 rounded-sm"
            >
              <span>{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="p-3 border-t border-white/10 flex-shrink-0">
          <Link
            href="/site"
            target="_blank"
            className="flex items-center gap-3 px-3 py-2 text-sm text-neutral-400 hover:text-white hover:bg-white/10 transition-colors rounded-sm mb-1"
          >
            <span>🌐</span> Ver site
          </Link>
          <div className="px-3 py-1.5 text-xs text-neutral-600 truncate">{user.email}</div>
          <form action="/auth/signout" method="post">
            <button
              type="submit"
              className="w-full flex items-center gap-3 px-3 py-2 text-sm text-neutral-400 hover:text-white hover:bg-white/10 transition-colors rounded-sm"
            >
              <span>🚪</span> Sair
            </button>
          </form>
        </div>
      </aside>

      <main className="flex-1 ml-60 p-8 overflow-auto min-h-screen">
        {children}
      </main>
    </div>
  )
}
