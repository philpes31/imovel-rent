'use client'

import { useState } from 'react'

interface Lead {
  id: string
  name: string
  email?: string
  phone: string
  message?: string
  source: string
  status: string
  created_at: string
  property?: { id: string; title: string; code: string }
  agent?: { name: string }
}

interface Props {
  leads: Lead[]
  totalPages: number
  currentPage: number
}

const STATUS_OPTIONS = [
  { value: 'novo', label: 'Novo', color: 'bg-blue-100 text-blue-800' },
  { value: 'contato', label: 'Em Contato', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'negociando', label: 'Negociando', color: 'bg-purple-100 text-purple-800' },
  { value: 'convertido', label: 'Convertido', color: 'bg-green-100 text-green-800' },
  { value: 'perdido', label: 'Perdido', color: 'bg-red-100 text-red-800' },
]

export default function LeadsTable({ leads, totalPages, currentPage }: Props) {
  const [statuses, setStatuses] = useState<Record<string, string>>(
    Object.fromEntries(leads.map(l => [l.id, l.status]))
  )

  async function updateStatus(id: string, status: string) {
    setStatuses(prev => ({ ...prev, [id]: status }))
    await fetch(`/api/admin/leads/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    })
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  return (
    <div className="bg-white border border-neutral-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-neutral-50 border-b border-neutral-200">
            <tr>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Contato</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Imóvel</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Origem</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Data</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Status</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-neutral-500 uppercase tracking-wide">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {leads.map(lead => {
              const currentStatus = STATUS_OPTIONS.find(s => s.value === statuses[lead.id])

              return (
                <tr key={lead.id} className="hover:bg-neutral-50 transition-colors">
                  <td className="px-4 py-3">
                    <p className="font-medium text-[#0A1628]">{lead.name}</p>
                    <div className="flex gap-3 mt-0.5">
                      <a
                        href={`tel:${lead.phone}`}
                        className="text-xs text-neutral-500 hover:text-[#0A1628] transition-colors"
                      >
                        📞 {lead.phone}
                      </a>
                      {lead.email && (
                        <a
                          href={`mailto:${lead.email}`}
                          className="text-xs text-neutral-500 hover:text-[#0A1628] transition-colors"
                        >
                          ✉ {lead.email}
                        </a>
                      )}
                    </div>
                    {lead.message && (
                      <p className="text-xs text-neutral-400 mt-1 line-clamp-1">{lead.message}</p>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {lead.property ? (
                      <div>
                        <a
                          href={`/admin/imoveis/${lead.property.id}/editar`}
                          className="text-xs font-medium text-[#0A1628] hover:text-[#C9A84C] transition-colors line-clamp-1"
                        >
                          {lead.property.title}
                        </a>
                        <p className="text-xs text-neutral-400 font-mono">{lead.property.code}</p>
                      </div>
                    ) : (
                      <span className="text-xs text-neutral-400">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs text-neutral-600 capitalize">{lead.source}</span>
                  </td>
                  <td className="px-4 py-3 text-xs text-neutral-500">
                    {formatDate(lead.created_at)}
                  </td>
                  <td className="px-4 py-3">
                    <select
                      value={statuses[lead.id]}
                      onChange={e => updateStatus(lead.id, e.target.value)}
                      className={`text-xs px-2.5 py-1 border-0 font-medium cursor-pointer focus:outline-none ${
                        currentStatus?.color || 'bg-neutral-100 text-neutral-700'
                      }`}
                    >
                      {STATUS_OPTIONS.map(s => (
                        <option key={s.value} value={s.value}>{s.label}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <a
                      href={`https://wa.me/55${lead.phone.replace(/\D/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-green-600 hover:text-green-800 font-medium transition-colors"
                    >
                      WhatsApp
                    </a>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3 border-t border-neutral-200">
          <p className="text-xs text-neutral-500">Página {currentPage} de {totalPages}</p>
          <div className="flex gap-1">
            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => i + 1).map(p => (
              <a
                key={p}
                href={`/admin/leads?page=${p}`}
                className={`w-8 h-8 flex items-center justify-center text-xs transition-colors ${
                  p === currentPage
                    ? 'bg-[#0A1628] text-white'
                    : 'border border-neutral-200 text-neutral-600 hover:border-[#0A1628]'
                }`}
              >
                {p}
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
